# Welcome and screensaver candidate

Not yet compiled or installed. Published stable 3.4.0 and Pilot 3.4.2 are unchanged.
Customer candidate: 3.5.0. Owner candidate: 3.5.1 with Pilot channel access.

Settings > Screen > Screensaver opens the new appearance page:

- Welcome at startup: a 2.4-second greeting with six softly lit petals. Touch
  dismisses it. The UI loop, networking and Bluetooth continue normally.
- Coffee motion: a static cup with three moving steam strokes at up to 6.25
  updates/second. No full-frame animation buffer or video decoder is used.
- Still background: the same coffee artwork without an animation timer update.
- Clock: keeps the previous clock, including waiting for a valid time.
- My photo: a locally saved 800x480 RGB565 image; missing/corrupt photos fall
  back to coffee artwork. Night mode and sleep timing still apply.
- Screen off: no screensaver.
- Espresso, Midnight and Cream backgrounds are saved across restarts.

Choose my photo opens a temporary local upload page. On a phone connected to
the same Wi-Fi, open the address displayed on the panel. The browser crops
the centre of a JPEG, PNG or WebP to 800x480 and converts it before sending.
No cloud service or account is used. Each decoded photo occupies 768,000 bytes
in PSRAM. Uploading can briefly require a second photo buffer, plus a retained
draw snapshot. Memory and storage failures keep the old saved photo.

The panel accepts only an exact 768,008-byte XBG1 file (8-byte header plus
RGB565 pixels). The destination is fixed; arbitrary filenames and image
decoders are not accepted. A temporary file is renamed only after a complete
upload. Uploading is allowed only while the panel's photo page is open and
the Studio is idle, and is blocked during firmware updates. Personal photos
are stored on LittleFS, outside the OTA application slots.

Existing sleep duration, clock colour and night preferences are preserved.
Existing clock-disabled devices migrate to Screen off; other devices default
to Coffee motion. New preferences use separate NVS keys.

Validation performed locally: actual browser conversion tests (centre crop,
format, colour order, payload size, oversize rejection) and four promotion
policy tests. PlatformIO configuration resolves distinct customer/owner
versions without duplicate version definitions.

Pending: C++ unit tests, firmware build, rendered UI tests, and physical-panel
tests. Local Xtensa execution fails with Illegal System DLL Relocation in the
current restricted process. Host compilation also fails to write/rename its
temporary build products. No candidate binary should be published until the
build and UI/storage tests pass.

The prepared GitHub Actions workflow is read-only with respect to repository
contents. If approved, it can build/test on a separate feature branch and
upload an artifact. It does not publish feeds or promote to Customers.

Physical checks before release: welcome/touch dismissal; idle animation and
wake touch; no idle overlay during brewing, grinding, stopwatch or OTA; night
mode; saved mode/theme across restart; photo upload/cropping and replacement;
interrupted/low-memory uploads; restart photo persistence; memory over a
several-hour Wi-Fi/BLE/brewing session; OTA from 3.4.2 and resulting version.
