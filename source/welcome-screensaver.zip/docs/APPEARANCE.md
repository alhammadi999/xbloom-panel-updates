# Welcome and screensaver candidate

Feature candidate, not promoted to a published channel. Stable 3.4.0 and Pilot
3.4.2 remain unchanged. Check the associated GitHub Actions run before installing.
Customer candidate: 3.5.0. Owner candidate: 3.5.2 with Pilot channel access.

Settings > Screen > Screensaver opens the new appearance page:

- Welcome at startup: a 2.4-second greeting with six softly lit petals. Touch
  dismisses it. The UI loop, networking and Bluetooth continue normally.
- Coffee motion: a static cup with three moving steam strokes at up to 6.25
  updates/second. No full-frame animation buffer or video decoder is used.
- Still background: the same coffee artwork without an animation timer update.
- Clock: keeps the previous clock, including waiting for a valid time.
- My photo: a locally saved 800x480 RGB565 image; missing/corrupt photos fall
  back to coffee artwork. Night mode and sleep timing still apply.
- Screen off: no screensaver.
- Espresso, Midnight and Cream backgrounds are saved across restarts.

Choose my photo opens a temporary local upload page. On a phone connected to
the same Wi-Fi, open the address displayed on the panel. The browser crops
the centre of a JPEG, PNG or WebP to 800x480 and converts it before sending.
No cloud service or account is used. Each decoded photo occupies 768,000 bytes
in PSRAM. Uploading can briefly require a second photo buffer, plus a retained
draw snapshot. Memory and storage failures keep the old saved photo.

The panel accepts only an exact 768,008-byte XBG1 file (8-byte header plus
RGB565 pixels). The destination is fixed; arbitrary filenames and image
decoders are not accepted. A temporary file is renamed only after a complete
upload. Uploading is allowed only while the panel's photo page is open and
the Studio is idle, and is blocked during firmware updates. Personal photos
are stored on LittleFS, outside the OTA application slots.

Existing sleep duration, clock colour and night preferences are preserved.
Existing clock-disabled devices migrate to Screen off; other devices default
to Coffee motion. New preferences use separate NVS keys.

Validation includes actual browser conversion tests (centre crop,
format, colour order, payload size, oversize rejection) and four promotion
policy tests. PlatformIO configuration resolves distinct customer/owner
versions without duplicate version definitions.

Native C++ storage and preference tests, rendered UI tests, and the full owner
firmware build run on GitHub Actions. A successful run is required for each
source revision. Physical-panel testing remains required. No candidate binary
should be promoted until the build, UI/storage and hardware tests pass.

GitHub Actions builds/tests on a separate feature branch and uploads artifacts.
Previews and candidate files may be committed only under the feature branch's
candidate directory. These workflows do not publish feeds or promote Customers.

Physical checks before release: welcome/touch dismissal; idle animation and
wake touch; no idle overlay during brewing, grinding, stopwatch or OTA; night
mode; saved mode/theme across restart; photo upload/cropping and replacement;
interrupted/low-memory uploads; restart photo persistence; memory over a
several-hour Wi-Fi/BLE/brewing session; OTA from 3.4.2 and resulting version.

Owner 3.5.2: fixed full backlight during idle and screensaver; actual screen-off and night-off remain unchanged. Hardware sound confirmation is pending.
