# Studio settings (Pilot 3.5.12)

Sources: HomoLand/xbloom-studio-brew protocol.py, telemetry.py and client.py, inspected 2026-11-20; owner photo of 3.5.11 showing radius 640 and vibration 1100 with type 7 / marker 194 (C2), baseline 0.

C2 acceptance is limited to CRC-valid 16-byte 11506/11508 replies. Activity/identity remain C1. A zero radius baseline is not inferred. The user saves L3 in the official app, reconnects and explicitly captures a fresh radius read as the reference. Valid 560..840 references persist against the BLE peer identity; native nonzero baselines take priority.

Mode uses 11511 (0 or 0x56783291), brightness 8103 (1,8,15); all writes retain fresh read and readback checks. A/B/C uses three validated 11510 frames, requires confirmed Pro idle, waits for slots-saved activity 0x25, and restores prior Auto mode. No brew start is sent; bypass recipes are excluded. Existing device presets cannot be read from this panel. No automatic re-send of partial batches.

Maintenance is a guide operated with Studio knobs, not remote activation. Source: https://tbdxsupport.zendesk.com/hc/en-us/articles/25198881250075-Cleaning-and-Maintenance . No service opcode is guessed. Device identity is read from 40521, and usage days are omitted because the available counter is not verified as days.

Hardware validation remains necessary for settings writes, A/B/C storage and L3 reference capture. Simulator results are not device evidence.
