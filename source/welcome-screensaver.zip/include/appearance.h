#pragma once
namespace appearance {
void begin(); // UI task, after all normal screens have been built
void tick();  // UI task only; animations stop while hidden
void open_settings();
void show_saver(bool on);
bool welcome_visible();
bool photo_page_visible();
}
