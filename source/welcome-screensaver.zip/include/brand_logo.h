#pragma once
#include <lvgl.h>
namespace brand {
const lv_image_dsc_t &welcome_logo();
const lv_image_dsc_t &saver_logo();
}
