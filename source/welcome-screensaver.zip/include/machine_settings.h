#pragma once
#include "xbloom_protocol.h"

namespace machine {
enum Field { Weight, Temperature, Water, Radius, Vibration, Count };
struct AdvancedReply {
  bool seen = false;
  uint8_t type = 0, marker = 0;
  uint32_t raw = 0;
};
struct Settings {
  int16_t value[Count] = {-1, -1, -1, -1, -1};
  int16_t radius_base = -1;
  AdvancedReply radius_reply, vibration_reply;
  uint32_t radius_base_raw = 0;
  bool radius_base_seen = false;
};
inline bool allowed(const Settings &s, int field, int v) {
  switch (field) {
    case Weight: return v >= 0 && v <= 2;
    case Temperature: case Water: return v == 0 || v == 1;
    case Radius: {
      int delta = v - s.radius_base;
      return s.radius_base >= 560 && s.radius_base <= 840 && delta >= -160 &&
             delta <= 160 && delta % 80 == 0 && v >= 400 && v <= 1000;
    }
    case Vibration: return v >= 1000 && v <= 1500 && v % 100 == 0;
    default: return false;
  }
}
inline uint32_t read_le32(const uint8_t *p) {
  return uint32_t(p[0]) | uint32_t(p[1]) << 8 | uint32_t(p[2]) << 16 | uint32_t(p[3]) << 24;
}
inline bool valid_envelope(const xb::Bytes &f) {
  return f.size() >= 12 && f[0] == 0x58 && f[1] == 2 &&
         read_le32(f.data()+5) == f.size() && xb::crc16(f.data(), f.size()-2) ==
         uint16_t(f[f.size()-2] | f.back() << 8);
}
inline bool valid_report(const xb::Bytes &f) {
  return valid_envelope(f) && f[2] == 7 && f[9] == 0xc1;
}
inline bool is_settings_report(uint16_t code) {
  return code == 40521 || code == 11506 || code == 11508;
}
// Report layout and read/write commands from the published Studio/J15 protocol.
inline bool decode(const xb::Bytes &f, Settings &s) {
  const int code = xb::frame_code(f);
  if ((code == 11506 || code == 11508) && f.size() >= 16 && valid_envelope(f)) {
    auto &reply = code == 11506 ? s.radius_reply : s.vibration_reply;
    // Retain evidence separately; unknown packet formats never enable writes.
    reply.seen = true; reply.type = f[2]; reply.marker = f[9];
    reply.raw = read_le32(f.data()+10);
  }
  if (!valid_report(f)) return false;
  const uint8_t *p = f.data()+10;
  if (code == 40521 && f.size() >= 54) {
    s.value[Weight] = p[41] <= 2 ? p[41] : -1;
    s.value[Temperature] = p[40] <= 1 ? p[40] : -1;
    s.value[Water] = p[36] <= 1 ? p[36] : -1;
    s.radius_base = -1;
    s.radius_base_seen = f.size() >= 71;
    s.radius_base_raw = 0;
    if (f.size() >= 71) {
      uint32_t base = read_le32(p+55);
      s.radius_base_raw = base;
      if (base >= 560 && base <= 840) s.radius_base = int(base);
    }
    // A radius reply can arrive before the heartbeat carrying its baseline.
    if (s.radius_reply.seen && s.radius_reply.type == 7 && s.radius_reply.marker == 0xc1) {
      uint32_t v = s.radius_reply.raw;
      s.value[Radius] = v <= 32767 && allowed(s, Radius, int(v)) ? int(v) : -1;
    }
    return true;
  }
  if ((code == 11506 || code == 11508) && f.size() >= 16) {
    int field = code == 11506 ? Radius : Vibration;
    uint32_t v = read_le32(p);
    s.value[field] = v <= 32767 && allowed(s, field, int(v)) ? int(v) : -1;
    return true;
  }
  return false;
}
inline uint16_t report_for(int field) {
  return field == Radius ? 11506 : field == Vibration ? 11508 : 40521;
}
inline xb::Bytes query(uint16_t report) {
  if (report == 40521) {
    // Match xbloom-py's read_status_snapshot: nudge the periodic info report
    // with the connection handshake. 8022 is a state-gated HOME command.
    const uint32_t hello[] = {185, 1};
    return xb::build_frame(xb::CMD_HANDSHAKE, hello, 2);
  }
  if (report == 11506 || report == 11508)
    return xb::build_frame(report, nullptr, 0, nullptr, 0, 2);
  return {};
}
inline xb::Bytes write_frame(const Settings &s, int field, int value) {
  if (!allowed(s, field, value)) return {};
  const uint16_t codes[] = {8005, 8010, 4508, 11507, 11509};
  uint32_t v = value;
  return xb::build_frame(codes[field], &v, 1, nullptr, 0, field >= Radius ? 2 : 1);
}
} // namespace machine
