#pragma once
#include "xbloom_protocol.h"

namespace machine {
enum Field { Weight, Temperature, Water, Radius, Vibration, Count };
struct Settings {
  int16_t value[Count] = {-1, -1, -1, -1, -1};
  int16_t radius_base = -1;
};
inline bool allowed(const Settings &s, int field, int v) {
  switch (field) {
    case Weight: return v >= 0 && v <= 2;
    case Temperature: case Water: return v == 0 || v == 1;
    case Radius: {
      int delta = v - s.radius_base;
      return s.radius_base >= 560 && s.radius_base <= 840 && delta >= -160 &&
             delta <= 160 && delta % 80 == 0 && v >= 400 && v <= 1000;
    }
    case Vibration: return v >= 1000 && v <= 1500 && v % 100 == 0;
    default: return false;
  }
}
inline uint32_t read_le32(const uint8_t *p) {
  return uint32_t(p[0]) | uint32_t(p[1]) << 8 | uint32_t(p[2]) << 16 | uint32_t(p[3]) << 24;
}
inline bool valid_report(const xb::Bytes &f) {
  return f.size() >= 12 && f[0] == 0x58 && f[1] == 2 && f[2] == 7 && f[9] == 0xc1 &&
         read_le32(f.data()+5) == f.size() && xb::crc16(f.data(), f.size()-2) ==
         uint16_t(f[f.size()-2] | f.back() << 8);
}
// Report layout and read/write commands from the published Studio/J15 protocol.
inline bool decode(const xb::Bytes &f, Settings &s) {
  if (!valid_report(f)) return false;
  const uint8_t *p = f.data()+10;
  int code = xb::frame_code(f);
  if (code == 40521 && f.size() >= 54) {
    s.value[Weight] = p[41] <= 2 ? p[41] : -1;
    s.value[Temperature] = p[40] <= 1 ? p[40] : -1;
    s.value[Water] = p[36] <= 1 ? p[36] : -1;
    s.radius_base = -1;
    if (f.size() >= 71) {
      uint32_t base = read_le32(p+55);
      if (base >= 560 && base <= 840) s.radius_base = int(base);
    }
    return true;
  }
  if ((code == 11506 || code == 11508) && f.size() >= 16) {
    int field = code == 11506 ? Radius : Vibration;
    uint32_t v = read_le32(p);
    s.value[field] = v <= 32767 && allowed(s, field, int(v)) ? int(v) : -1;
    return true;
  }
  return false;
}
inline uint16_t report_for(int field) {
  return field == Radius ? 11506 : field == Vibration ? 11508 : 40521;
}
inline xb::Bytes query(uint16_t report) {
  return report == 40521 ? xb::build_frame(8022) : xb::build_frame(report, nullptr, 0, nullptr, 0, 2);
}
inline xb::Bytes write_frame(const Settings &s, int field, int value) {
  if (!allowed(s, field, value)) return {};
  const uint16_t codes[] = {8005, 8010, 4508, 11507, 11509};
  uint32_t v = value;
  return xb::build_frame(codes[field], &v, 1, nullptr, 0, field >= Radius ? 2 : 1);
}
} // namespace machine
