#pragma once
#include "xbloom_protocol.h"

namespace machine {
enum Field { Weight, Temperature, Water, Radius, Vibration, Display, Mode, Count };
struct AdvancedReply {
  bool seen = false;
  uint8_t type = 0, marker = 0;
  uint32_t raw = 0;
  uint32_t frame_size = 16;
};
struct Settings {
  int16_t value[Count] = {-1, -1, -1, -1, -1, -1, -1};
  int16_t radius_base = -1;
  AdvancedReply radius_reply, vibration_reply;
  uint32_t radius_base_raw = 0;
  bool radius_base_seen = false;
  char serial[14] = {}, model[7] = {}, firmware[11] = {};
};
inline bool advanced_format(const AdvancedReply &r) {
  // The owner's V12 Studio returns C2 for type-2 query replies (11506/11508).
  // C1 remains supported. This exception never applies to activity/identity.
  return r.seen && r.type == 7 &&
         ((r.marker == 0xc1 && r.frame_size >= 16) || (r.marker == 0xc2 && r.frame_size == 16));
}
inline bool allowed(const Settings &s, int field, int v) {
  switch (field) {
    case Weight: return v >= 0 && v <= 2;
    case Temperature: case Water: return v == 0 || v == 1;
    case Mode: return v == 0 || v == 1;
    case Display: return v == 1 || v == 8 || v == 15;
    case Radius: {
      int delta = v - s.radius_base;
      return s.radius_base >= 560 && s.radius_base <= 840 && delta >= -160 &&
             delta <= 160 && delta % 80 == 0 && v >= 400 && v <= 1000;
    }
    case Vibration: return v >= 1000 && v <= 1500 && v % 100 == 0;
    default: return false;
  }
}
inline uint32_t read_le32(const uint8_t *p) {
  return uint32_t(p[0]) | uint32_t(p[1]) << 8 | uint32_t(p[2]) << 16 | uint32_t(p[3]) << 24;
}
inline bool valid_envelope(const xb::Bytes &f) {
  return f.size() >= 12 && f[0] == 0x58 && f[1] == 2 &&
         read_le32(f.data()+5) == f.size() && xb::crc16(f.data(), f.size()-2) ==
         uint16_t(f[f.size()-2] | f.back() << 8);
}
inline bool valid_report(const xb::Bytes &f) {
  return valid_envelope(f) && f[2] == 7 && f[9] == 0xc1;
}
inline bool is_settings_report(uint16_t code) {
  return code == 40521 || code == 11506 || code == 11508;
}
// Report layout and read/write commands from the published Studio/J15 protocol.
inline bool decode(const xb::Bytes &f, Settings &s) {
  const int code = xb::frame_code(f);
  if ((code == 11506 || code == 11508) && f.size() >= 16 && valid_envelope(f)) {
    s.value[code == 11506 ? Radius : Vibration] = -1;
    auto &reply = code == 11506 ? s.radius_reply : s.vibration_reply;
    // Retain evidence separately; unknown packet formats never enable writes.
    reply.seen = true; reply.type = f[2]; reply.marker = f[9];
    reply.raw = read_le32(f.data()+10);
    reply.frame_size = f.size();
  }
  if ((code == 11506 || code == 11508) && f.size() == 16 && valid_envelope(f) &&
      f[2] == 7 && (f[9] == 0xc1 || f[9] == 0xc2)) {
    int field = code == 11506 ? Radius : Vibration;
    uint32_t v = read_le32(f.data()+10);
    s.value[field] = v <= 32767 && allowed(s, field, int(v)) ? int(v) : -1;
    return true;
  }
  if (!valid_report(f)) return false;
  const uint8_t *p = f.data()+10;
  if (code == 40521 && f.size() >= 54) {
    s.value[Weight] = p[41] <= 2 ? p[41] : -1;
    s.value[Temperature] = p[40] <= 1 ? p[40] : -1;
    s.value[Water] = p[36] <= 1 ? p[36] : -1;
    s.value[Display] = allowed(s, Display, p[38]) ? p[38] : -1;
    s.value[Mode] = -1;
    if (f.size() >= 67) {
      uint32_t mode = read_le32(p+51);
      s.value[Mode] = mode == 0 ? 0 : mode == 0x56783291 ? 1 : -1;
    }
    auto copy_ascii = [](char *out, const uint8_t *src, int len) {
      for (int i=0;i<len;++i) out[i] = src[i] >= 32 && src[i] <= 126 ? char(src[i]) : 0;
      out[len] = 0;
    };
    copy_ascii(s.serial,p,13); copy_ascii(s.model,p+13,6); copy_ascii(s.firmware,p+19,10);
    s.radius_base = -1;
    s.radius_base_seen = f.size() >= 71;
    s.radius_base_raw = 0;
    if (f.size() >= 71) {
      uint32_t base = read_le32(p+55);
      s.radius_base_raw = base;
      if (base >= 560 && base <= 840) s.radius_base = int(base);
    }
    // A radius reply can arrive before the heartbeat carrying its baseline.
    if (advanced_format(s.radius_reply)) {
      uint32_t v = s.radius_reply.raw;
      s.value[Radius] = v <= 32767 && allowed(s, Radius, int(v)) ? int(v) : -1;
    }
    return true;
  }
  if ((code == 11506 || code == 11508) && f.size() >= 16) {
    int field = code == 11506 ? Radius : Vibration;
    uint32_t v = read_le32(p);
    s.value[field] = v <= 32767 && allowed(s, field, int(v)) ? int(v) : -1;
    return true;
  }
  return false;
}
inline uint16_t report_for(int field) {
  return field == Radius ? 11506 : field == Vibration ? 11508 : 40521;
}
inline xb::Bytes query(uint16_t report) {
  if (report == 40521) {
    // Match xbloom-py's read_status_snapshot: nudge the periodic info report
    // with the connection handshake. 8022 is a state-gated HOME command.
    const uint32_t hello[] = {185, 1};
    return xb::build_frame(xb::CMD_HANDSHAKE, hello, 2);
  }
  if (report == 11506 || report == 11508)
    return xb::build_frame(report, nullptr, 0, nullptr, 0, 2);
  return {};
}
inline xb::Bytes write_frame(const Settings &s, int field, int value) {
  if (!allowed(s, field, value)) return {};
  const uint16_t codes[] = {8005, 8010, 4508, 11507, 11509, 8103, 11511};
  uint32_t v = field == Mode && value == 1 ? 0x56783291 : value;
  return xb::build_frame(codes[field], &v, 1, nullptr, 0,
                         field == Radius || field == Vibration || field == Mode ? 2 : 1);
}
inline xb::Bytes slot_frame(const xb::Recipe &r, int slot) {
  if (slot < 0 || slot > 2 || xb::validate(r)) return {};
  auto blob = xb::encode_recipe_blob(r);
  blob.insert(blob.begin(), {uint8_t(slot), 0x12}); // scale enabled; no brew-start
  return xb::build_frame(11510, nullptr, 0, blob.data(), blob.size(), 2);
}
} // namespace machine
