#pragma once
#include "machine_settings.h"

namespace machine {
// Only these idempotent reads are retried. Writes retain their separate
// user-confirmed path and must still be verified against a fresh report.
template<class Transport> bool read_report(uint16_t report, Transport &io) {
  const auto frame = query(report);
  if (frame.empty()) return false;
  const uint32_t timeout = 3000;
  for (int attempt = 0; attempt < 2; ++attempt) {
    if (!io.connected() || !io.write(frame)) return false;
    const uint32_t started = io.now();
    while (!io.received() && io.connected() && uint32_t(io.now() - started) < timeout)
      io.pump(20);
    if (io.connected() && io.received()) return true;
  }
  return false;
}
}
