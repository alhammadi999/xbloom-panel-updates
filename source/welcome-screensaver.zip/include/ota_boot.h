#pragma once
#include <stdint.h>

namespace ota_boot {
// Confirm only after the display, touch and first UI loop have initialized.
// Failed reads/writes remain pending and retry; success requires readback.
class Confirmation {
 public:
  bool poll(uint32_t now, bool startup_ready);
  bool confirmed() const { return done_; }
 private:
  bool attempted_ = false, done_ = false;
  uint32_t last_attempt_ = 0;
};
}
