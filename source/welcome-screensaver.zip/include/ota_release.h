#pragma once
#include <stdint.h>
#include <cstdio>
#include <cstring>
#define PANEL_OTA_BOARD "crowpanel-advance-43-saud"
#define PANEL_OTA_MARKER "XBLOOM-OTA|" PANEL_OTA_BOARD "|"
namespace ota {
// Three canonical decimal components. Numeric ordering avoids treating 3.10 as older than 3.9.
inline int64_t version_number(const char *s) {
  int64_t total = 0;
  for (int part = 0; part < 3; ++part) {
    if (!s || *s < '0' || *s > '9' || (*s == '0' && s[1] >= '0' && s[1] <= '9')) return -1;
    int value = 0, digits = 0;
    while (*s >= '0' && *s <= '9') {
      if (++digits > 3) return -1;
      value = 10 * value + (*s++ - '0');
    }
    total = total * 1000 + value;
    if (part < 2 && *s++ != '.') return -1;
  }
  return *s ? -1 : total;
}
inline bool digest_valid(const char *s) {
  if (!s || strlen(s) != 64) return false;
  for (int i = 0; i < 64; ++i)
    if (!(s[i] >= '0' && s[i] <= '9') && !(s[i] >= 'a' && s[i] <= 'f')) return false;
  return true;
}
}
