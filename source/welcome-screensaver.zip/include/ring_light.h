#pragma once
#include <stdint.h>

// Two low-side XY-MOS drivers, not an addressable RGB LED.
namespace ring_light {
constexpr uint8_t PIN_A = 19; // UART1 RX -> white ring wire via driver A
constexpr uint8_t PIN_B = 20; // UART1 TX -> black ring wire via driver B
enum class Colour : uint8_t { Cool, Cream, Warm };
struct State {
  bool on = false;
  uint8_t brightness = 50;
  Colour colour = Colour::Cream;
  bool swap = false;
  bool start_fade = false;
  bool pour_pulse = false;
  bool pause_pulse = false;
  bool finish_flash = false;
  bool quiet = false;
};
enum class Activity : uint8_t { Idle, Brewing, Pouring, Paused };
enum class Option : uint8_t { StartFade, PourPulse, PausePulse, FinishFlash, Quiet, Swap };
struct Animation {
  Activity activity = Activity::Idle;
  uint32_t activity_since = 0, started = 0, finished = 0;
  bool starting = false, finishing = false;
};
struct Duty { uint16_t a, b; };
inline Colour valid_colour(uint8_t c) {
  return c <= 2 ? static_cast<Colour>(c) : Colour::Cream;
}
inline Duty mix(const State &s) {
  if (!s.on) return {0, 0};
  const unsigned level = s.brightness > 100 ? 100 : s.brightness;
  const uint16_t total = (level * 255u + 50u) / 100u;
  uint16_t cool = 0, warm = 0;
  switch (valid_colour(static_cast<uint8_t>(s.colour))) {
    case Colour::Cool: cool = total; break;
    case Colour::Warm: warm = total; break;
    case Colour::Cream: cool = total / 2; warm = total - cool; break;
  }
  return s.swap ? Duty{warm, cool} : Duty{cool, warm};
}
// Smooth triangle, 0..255..0, with flat slopes at both ends.
inline unsigned wave(uint32_t elapsed, unsigned period) {
  const unsigned phase = elapsed % period;
  const unsigned x = (phase < period / 2 ? phase : period - phase) * 510u / period;
  return (3u * x * x * 255u - 2u * x * x * x) / (255u * 255u);
}
inline Duty render(const State &s, const Animation &a, uint32_t now) {
  if (!s.on) return {0, 0};
  State output = s;
  unsigned gain = 255;
  if (s.quiet) {
    output.colour = Colour::Cream;
    if (output.brightness > 10) output.brightness = 10;
  } else if (s.finish_flash && a.finishing && uint32_t(now - a.finished) < 1600) {
    const unsigned t = uint32_t(now - a.finished) % 800;
    gain = t < 600 ? wave(t, 600) : 0;
  } else if (s.pause_pulse && a.activity == Activity::Paused) {
    gain = 26 + wave(now - a.activity_since, 3600) * 102 / 255;
  } else if (s.start_fade && a.starting && a.activity != Activity::Paused && uint32_t(now - a.started) < 2000) {
    gain = uint32_t(now - a.started) * 255 / 2000;
  } else if (s.pour_pulse && a.activity == Activity::Pouring) {
    gain = 51 + wave(now - a.activity_since, 1800) * 204 / 255;
  } else if (s.pour_pulse && a.activity == Activity::Brewing) {
    gain = 51; // Between pours: steady at 20% of the selected brightness.
  }
  Duty d = mix(output);
  d.a = d.a * gain / 255;
  d.b = d.b * gain / 255;
  return d;
}
void begin();
void tick();
const State &state();
bool ready();
bool settings_saved();
void set_on(bool value);
void set_brightness(int value);
void set_colour(Colour value);
void set_swap(bool value);
void set_option(Option option, bool value);
void start_brew();
void finish_brew();
void cancel_brew();
void set_activity(Activity activity);
#ifdef UI_SIM
Duty sim_output();
#endif
} // namespace ring_light
