#pragma once
#include <stdint.h>
namespace screen_prefs {
enum class Saver : uint8_t { Motion, Still, Clock, Photo, Off };
enum class Theme : uint8_t { Espresso, Midnight, Cream };
constexpr Saver saver(unsigned value) { return value <= unsigned(Saver::Off) ? Saver(value) : Saver::Motion; }
constexpr Theme theme(unsigned value) { return value <= unsigned(Theme::Cream) ? Theme(value) : Theme::Espresso; }
constexpr bool should_show(Saver mode, bool time_valid, bool night, bool off_at_night) {
  return mode != Saver::Off && (mode != Saver::Clock || time_valid) && !(night && off_at_night);
}
constexpr uint32_t welcome_ms = 2400;
constexpr uint32_t animation_step_ms = 160; // no more than 6.25 updates per second
}
