#pragma once
#include "spotify_remote.h"
#include <string>

namespace spotify {
struct Response { int status = 0; unsigned retry_after = 0; std::string body; };
struct Backend {
  virtual ~Backend() = default;
  virtual Response request(bool accounts, const char *method, const std::string &path,
                           const std::string &token, const std::string &body) = 0;
  virtual bool save(const std::string &client, const std::string &refresh) = 0;
};
std::string form_encode(const std::string &value);
bool valid_client(const std::string &value);
bool valid_token(const std::string &value);
class Engine {
 public:
  explicit Engine(Backend &backend) : backend_(backend) {}
  void restore(const std::string &client, const std::string &refresh);
  bool link(const std::string &client, const std::string &refresh, uint32_t now);
  void forget();
  void poll(uint32_t now, bool visible);
  void control(Command cmd, const std::string &expected_device, uint32_t now);
  const State &state() const { return state_; }
 private:
  Backend &backend_;
  State state_;
  std::string client_, refresh_, access_;
  uint32_t expires_ = 0, next_poll_ = 0, retry_at_ = 0, last_player_ = 0;
  bool limited_ = false, have_player_ = false;
  bool token(uint32_t now);
  bool allowed(uint32_t now);
  Response api(const char *method, const std::string &path, uint32_t now);
  void error(const Response &response, uint32_t now);
  void message(const char *text);
};
}
