#pragma once
#include <string>
#include <stdint.h>
#include <cstdio>

namespace spotify {
constexpr const char *LOGIN_CLIENT = "7c30d4a2f8a54099a50c400e210b4cb2";
constexpr const char *LOGIN_REDIRECT = "https://alhammadi999.github.io/xbloom-panel-updates/spotify/";
std::string form_encode(const std::string &value);
inline bool private_ip(const std::string &ip) {
  unsigned a,b,c,d; char extra;
  if (std::sscanf(ip.c_str(), "%u.%u.%u.%u%c", &a,&b,&c,&d,&extra)!=4 || a>255 || b>255 || c>255 || d>255) return false;
  const auto canonical=std::to_string(a)+"."+std::to_string(b)+"."+std::to_string(c)+"."+std::to_string(d);
  return ip==canonical && (a==10 || (a==172 && b>=16 && b<=31) || (a==192 && b==168));
}
class LoginSession {
  std::string state_, verifier_, challenge_, ip_;
  uint32_t started_=0;
 public:
  void clear() { state_.clear(); verifier_.clear(); challenge_.clear(); ip_.clear(); }
  void start(const std::string &ip, const std::string &nonce, const std::string &verifier,
             const std::string &challenge, uint32_t now) {
    clear();
    if (!private_ip(ip) || nonce.size()!=32 || nonce.find_first_not_of("0123456789abcdef")!=std::string::npos ||
        verifier.size()!=64 || challenge.size()!=43) return;
    ip_=ip; state_=ip+"~"+nonce; verifier_=verifier; challenge_=challenge; started_=now;
  }
  bool valid(const std::string &state, uint32_t now) const {
    return !state_.empty() && state==state_ && uint32_t(now-started_)<=300000;
  }
  std::string url() const { return state_.empty()? "" : "http://"+ip_+"/spotify/start?state="+state_; }
  std::string authorize(const std::string &state, uint32_t now) const {
    if (!valid(state, now)) return "";
    return "https://accounts.spotify.com/authorize?response_type=code&client_id="+std::string(LOGIN_CLIENT)+
      "&redirect_uri="+form_encode(LOGIN_REDIRECT)+"&scope=user-read-playback-state%20user-modify-playback-state"+
      "&code_challenge_method=S256&code_challenge="+challenge_+"&state="+form_encode(state_);
  }
  std::string consume(const std::string &state, uint32_t now) {
    if (!valid(state,now)) return "";
    auto result=verifier_; clear(); return result;
  }
};
}
