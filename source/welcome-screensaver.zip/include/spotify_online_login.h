#pragma once
#include <string>
#include <stdint.h>
namespace spotify {
constexpr const char *RELAY_ORIGIN = "https://threedup-spotify-link.s-alhammadi999.chatgpt.site";
inline bool login_hex(const std::string &s) { return s.size()==64 && s.find_first_not_of("0123456789abcdef")==std::string::npos; }
struct OnlineLogin {
  std::string id, secret, verifier, challenge;
  uint32_t started=0, next=0;
  bool registered=false;
  void clear(){id.clear();secret.clear();verifier.clear();challenge.clear();registered=false;}
  void start(const std::string &i,const std::string &s,const std::string &v,const std::string &c,uint32_t now){
    clear();if(!login_hex(i)||!login_hex(s)||!login_hex(v)||c.size()!=43)return;
    id=i;secret=s;verifier=v;challenge=c;started=next=now;
  }
  bool active(uint32_t now)const{return !id.empty() && uint32_t(now-started)<300000;}
  bool due(uint32_t now)const{return active(now)&&int32_t(now-next)>=0;}
  bool matches(const std::string &state,uint32_t now)const {
    const std::string prefix="r2."+id+".";
    return registered && active(now) && state.compare(0,prefix.size(),prefix)==0 && login_hex(state.substr(prefix.size()));
  }
  std::string url()const{return registered?std::string(RELAY_ORIGIN)+"/#"+id:"";}
};
}
