#pragma once
#include <stdint.h>
#include <string>
#ifndef PANEL_SPOTIFY_TRIAL
#define PANEL_SPOTIFY_TRIAL 0
#endif

namespace spotify {
enum class Command : uint8_t { None, Play, Pause, Next, Previous, Volume };
struct State {
  bool enabled = false, linked = false, playing = false, controls = false, busy = false;
  bool can_play = false, can_pause = false, can_next = false, can_previous = false;
  bool can_volume = false;
  int volume = -1;
  char login_url[192]{};
  char title[160]{}, artist[160]{}, device[80]{}, device_id[96]{};
  char message[160] = "Enable the trial to connect Spotify.";
  char pairing_code[7]{};
};
void begin();
State state();
void set_enabled(bool enabled);
void set_visible(bool visible);
void start_pairing();
void disconnect();
bool command(Command cmd, int value = -1);
// Called only by local HTTP routes; OAuth secrets stay on the panel.
std::string authorize_url(const char *state);
bool accept_code(const char *state, const char *code);
// Network task only. No HTTP or flash work runs in the LVGL/coffee UI task.
void tick(bool network_allowed);
bool accept_link(const char *pin, const char *client_id, const char *refresh_token);
}
