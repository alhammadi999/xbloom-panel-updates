#pragma once

// Customer builds are locked to the stable feed. Pilot access is opt-in at build time.
#ifndef PANEL_PILOT_ACCESS
#define PANEL_PILOT_ACCESS 0
#endif
#if PANEL_PILOT_ACCESS != 0 && PANEL_PILOT_ACCESS != 1
#error PANEL_PILOT_ACCESS must be 0 or 1
#endif
#if PANEL_PILOT_ACCESS
#define PANEL_CHANNEL_MARKER "XBLOOM-CHANNEL|owner|"
#else
#define PANEL_CHANNEL_MARKER "XBLOOM-CHANNEL|customer|"
#endif
namespace update_policy {
constexpr bool pilot_enabled = PANEL_PILOT_ACCESS == 1;
constexpr bool selected_pilot(bool requested) { return pilot_enabled && requested; }
}
