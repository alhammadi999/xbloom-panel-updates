#pragma once
#include <stddef.h>
#include <stdint.h>
#include <memory>
#include <cstring>
namespace wallpaper {
constexpr size_t width = 800, height = 480, pixel_bytes = width * height * 2, header_bytes = 8;
inline bool valid_header(const uint8_t *data, size_t size) {
  return size >= header_bytes && !memcmp(data, "XBG1", 4) &&
    data[4] == 0x20 && data[5] == 0x03 && data[6] == 0xe0 && data[7] == 0x01;
}
struct Image {
  uint8_t *pixels = nullptr;
  Image();
  ~Image();
  Image(const Image &) = delete;
  Image &operator=(const Image &) = delete;
};
void begin(); // after storage::begin, before serving uploads
std::shared_ptr<const Image> current();
bool start_upload();
bool write_upload(const uint8_t *data, size_t size);
bool finish_upload();
void abort_upload();
}
