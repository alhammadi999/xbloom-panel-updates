"""Prepare the public binary and feed in a checkout of xbloom-panel-updates."""
import argparse
import hashlib
import json
import pathlib
import re

BOARD = "crowpanel-advance-43-saud"
VERSION = r"(?:0|[1-9][0-9]{0,2})(?:\.(?:0|[1-9][0-9]{0,2})){2}"


def parts(version):
    if re.fullmatch(VERSION, version) is None:
        raise ValueError("Expected a three-part version such as 3.4.1")
    return tuple(map(int, version.split(".")))


def read_feed(folder, channel):
    return json.loads((folder / (channel + ".json")).read_text(encoding="utf-8"))


def write_feed(folder, channel, release):
    target = folder / (channel + ".json")
    data = dict(release, channel=channel)
    if target.exists():
        old = read_feed(folder, channel)
        if parts(data["version"]) < parts(old["version"]):
            raise ValueError("The channel already has a newer version")
        if data["version"] == old["version"] and data["sha256"] != old["sha256"]:
            raise ValueError("Publish changed firmware with a new version")
    temp = target.with_suffix(".json.tmp")
    temp.write_text(json.dumps(data, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
    temp.replace(target)


def image_info(image):
    marker = b"XBLOOM-OTA|" + BOARD.encode() + b"|"
    matches = set(re.findall(re.escape(marker) + b"(" + VERSION.encode() + b")\x5c|", image))
    if len(matches) != 1 or not 500000 <= len(image) <= 0x600000 or image[:1] != b"\xe9":
        raise ValueError("Expected one identified CrowPanel application image")
    if image[0x8000:0x8002] == b"\xaa\x50" or image[32:36] != b"\x32\x54\xcd\xab":
        raise ValueError("Expected an OTA app, not a combined factory image")
    return matches.pop().decode(), hashlib.sha256(image).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["pilot", "promote"])
    parser.add_argument("folder", type=pathlib.Path)
    parser.add_argument("--image", type=pathlib.Path)
    parser.add_argument("--notes")
    args = parser.parse_args()
    folder = args.folder
    folder.mkdir(parents=True, exist_ok=True)
    if args.action == "pilot":
        if not args.image or not args.notes or len(args.notes.encode()) > 155:
            parser.error("Supply --image and --notes (up to 155 UTF-8 bytes)")
        image = args.image.read_bytes()
        ver, digest = image_info(image)
        destination = folder / ("xbloom-saud-" + ver + ".bin")
        if destination.exists() and destination.read_bytes() != image:
            raise ValueError("An existing version cannot be overwritten with different bytes")
        destination.write_bytes(image)
        release = dict(schema=1, board=BOARD, version=ver, bytes=len(image), sha256=digest, notes=args.notes)
        write_feed(folder, "pilot", release)
    else:
        release = read_feed(folder, "pilot")
        parts(release["version"])
        image = (folder / ("xbloom-saud-" + release["version"] + ".bin")).read_bytes()
        ver, digest = image_info(image)
        if (release["schema"], release["board"], release["channel"], release["version"], release["sha256"], release["bytes"]) != (1, BOARD, "pilot", ver, digest, len(image)):
            raise ValueError("Pilot metadata and image do not match")
        if b"XBLOOM-CHANNEL|customer|" not in image or b"XBLOOM-CHANNEL|owner|" in image:
            raise ValueError("Customers require a customer-only image; never promote an owner build")
        write_feed(folder, "stable", release)


if __name__ == "__main__":
    main()
