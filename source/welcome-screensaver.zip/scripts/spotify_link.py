"""One-time PKCE sign-in. No password, client secret or token is saved on this PC."""
import argparse
import base64
import hashlib
import http.server
import ipaddress
import json
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser

CLIENT_ID = "7c30d4a2f8a54099a50c400e210b4cb2"
REDIRECT = "http://127.0.0.1:8842/callback"
SCOPES = "user-read-playback-state user-modify-playback-state"

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise ValueError("Unexpected redirect; connection stopped")

def request_json(url, payload=None, form=False):
    data = None if payload is None else (urllib.parse.urlencode(payload) if form else json.dumps(payload)).encode()
    req = urllib.request.Request(url, data=data)
    if data is not None:
        req.add_header("Content-Type", "application/x-www-form-urlencoded" if form else "application/json")
    opener = urllib.request.build_opener(NoRedirect)
    with opener.open(req, timeout=15) as response:
        raw = response.read(16385)
        if len(raw) > 16384:
            raise ValueError("Response too large")
        return json.loads(raw)

def pkce(verifier):
    return base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()

def panel_url(address):
    address = address.strip()
    ip = ipaddress.ip_address(address)
    if ip.version != 4 or not ip.is_private or ip.is_loopback or ip.is_unspecified or ip.is_multicast:
        raise ValueError("Enter the panel's local Wi-Fi IPv4 address shown on its Spotify page")
    return "http://" + str(ip)

def callback_result(path, expected_state):
    parsed = urllib.parse.urlsplit(path)
    if parsed.path != "/callback":
        return None
    query = urllib.parse.parse_qs(parsed.query)
    if not secrets.compare_digest(query.get("state", [""])[0], expected_state):
        raise ValueError("Sign-in state did not match; please restart linking")
    if "error" in query:
        raise ValueError("Spotify permission was declined")
    code = query.get("code", [""])[0]
    if not code or len(code) > 4096:
        raise ValueError("Missing Spotify authorization code")
    return code

def authorize(client, open_browser=True, auth_url_file=None):
    verifier = secrets.token_urlsafe(64)
    state = secrets.token_urlsafe(24)
    result = {}
    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass  # Authorization codes must never appear in request logs.
        def do_GET(self):
            try:
                code = callback_result(self.path, state)
                if code is None:
                    self.send_error(404); return
                result["code"] = code
                body = b"<h2>Spotify sign-in received</h2><p>Return to the linking helper to finish connecting your panel.</p>"
                status = 200
            except ValueError:
                body = b"<h2>Sign-in could not be verified</h2><p>Return to the helper and try again.</p>"
                status = 400
            self.send_response(status)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Referrer-Policy", "no-referrer")
            self.end_headers(); self.wfile.write(body)
    with http.server.HTTPServer(("127.0.0.1", 8842), Handler) as server:
        server.timeout = 1
        url = "https://accounts.spotify.com/authorize?" + urllib.parse.urlencode({
            "client_id": client, "response_type": "code", "redirect_uri": REDIRECT,
            "scope": SCOPES, "state": state, "code_challenge_method": "S256", "code_challenge": pkce(verifier),
        })
        if auth_url_file:
            from pathlib import Path
            Path(auth_url_file).write_text(url, encoding="utf-8")
        if open_browser:
            webbrowser.open(url)
        print("Waiting for Spotify permission in the browser...", flush=True)
        deadline = time.monotonic() + 600
        while "code" not in result and time.monotonic() < deadline:
            server.handle_request()
        if "code" not in result:
            raise ValueError("Sign-in timed out. Run the helper again")
    token = request_json("https://accounts.spotify.com/api/token", {
        "grant_type": "authorization_code", "client_id": client, "code": result["code"],
        "redirect_uri": REDIRECT, "code_verifier": verifier,
    }, form=True)
    if not token.get("refresh_token"):
        raise ValueError("Spotify did not provide an ongoing sign-in. Try again")
    return token["refresh_token"]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--client-id", default=CLIENT_ID)
    parser.add_argument("--panel")
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--auth-url-file")
    args = parser.parse_args()
    print("3Dup xBloom - Spotify trial linking")
    print("The panel must be running the Spotify trial firmware, on the same Wi-Fi.")
    base = panel_url(args.panel or input("Panel IP address: "))
    if len(args.client_id) != 32 or any(c not in "0123456789abcdefABCDEF" for c in args.client_id):
        raise ValueError("Invalid Spotify Client ID")
    status = request_json(base + "/spotify/status")
    if not status.get("enabled"):
        raise ValueError("Enable Spotify trial in the panel's Settings first")
    refresh = authorize(args.client_id, not args.no_browser, args.auth_url_file)
    print("On the panel: Settings > Spotify trial > Link account.")
    pin = input("Enter the six-digit pairing code shown on the panel: ").strip()
    if len(pin) != 6 or not pin.isdecimal():
        raise ValueError("Invalid pairing code")
    request_json(base + "/spotify/link", {"pin": pin, "client_id": args.client_id, "refresh_token": refresh})
    refresh = None
    for _ in range(20):
        time.sleep(1)
        if request_json(base + "/spotify/status").get("linked"):
            print("Connected. Play a song on your phone, then use the panel's music controls.")
            return
    raise ValueError("Panel has not confirmed linking. Check its Spotify page and try again")

if __name__ == "__main__":
    try:
        main()
    except urllib.error.HTTPError as error:
        print(f"Connection refused (HTTP {error.code}). Check the panel code, app access and Premium.")
        raise SystemExit(1)
    except Exception as error:
        print("Linking stopped:", str(error))
        raise SystemExit(1)
