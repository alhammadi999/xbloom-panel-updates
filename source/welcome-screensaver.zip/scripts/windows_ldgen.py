"""Handle long Windows ldgen commands and keep SDK child builds on the same Core."""
import os
import subprocess
import sys

Import("env")

if os.name == "nt":
    original_spawn = env["SPAWN"]

    def spawn_ldgen_direct(sh, escape, cmd, args, spawn_env):
        is_ldgen = any(
            str(arg).strip('"').replace("\\", "/").endswith("/ldgen.py")
            for arg in args
        )
        is_child_pio = (
            os.path.basename(str(cmd).strip('"')).lower() in ("pio.exe", "platformio.exe")
            and len(args) > 1 and str(args[1]).strip('"') == "run"
        )
        if is_child_pio:
            # pioarduino otherwise picks pio.exe from its tools venv, which may
            # contain a different Core/SCons version from the parent build.
            command = [subprocess.list2cmdline([sys.executable]), "-m", "platformio", *args[1:]]
            return subprocess.call(" ".join(command), env=spawn_env, shell=False)
        if is_ldgen:
            # SCons has already quoted these Windows command-line arguments.
            # Keep that quoting and launch Python without an intervening shell.
            return subprocess.call(" ".join(args), env=spawn_env, shell=False)
        return original_spawn(sh, escape, cmd, args, spawn_env)

    env.Replace(SPAWN=spawn_ldgen_direct)
