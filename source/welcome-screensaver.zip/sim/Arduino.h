#pragma once
#include <stdint.h>
#include <stdio.h>
#include <string.h>
uint32_t millis();
struct SerialStub {
  void println(const char *s) { puts(s); }
  template <typename... A> void printf(const char *f, A... a) { ::printf(f, a...); }
};
static SerialStub Serial;

#ifdef _WIN32
#include <time.h>
inline struct tm *localtime_r(const time_t *time, struct tm *result) {
  return localtime_s(result, time) == 0 ? result : nullptr;
}
inline size_t strlcpy(char *dest, const char *src, size_t size) {
  size_t n = strlen(src);
  if (size) { size_t count = n < size - 1 ? n : size - 1; memcpy(dest, src, count); dest[count] = 0; }
  return n;
}
#endif
