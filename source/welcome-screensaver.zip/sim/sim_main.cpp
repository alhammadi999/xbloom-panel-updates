// Desktop render of the UI for a layout check (no hardware). Writes PPM frames.
#include <lvgl.h>
#include <stdio.h>
#include <string.h>
#include <deque>
#include "ui.h"
#include "panel_net.h"
#include "ble_link.h"
#include "ring_light.h"
#include "appearance.h"
#include <vector>
#include <assert.h>
static uint32_t now = 100000;
uint32_t millis() { return now; }
static std::deque<UiEvent> evq;
static machine::Settings simulated_settings;
static bool reject_write = false;
static int machine_writes = 0;
namespace ble_link {
void begin() {}
bool post(const BleCmd &c) {
  if (c.type != BleCmdType::MachineRead && c.type != BleCmdType::MachineWrite) return true;
  UiEvent e;
  e.type = UiEvType::MachineSettings;
  e.i = c.request_id;
  if (c.type == BleCmdType::MachineWrite) {
    ++machine_writes;
    e.ok = !reject_write && machine::allowed(simulated_settings, c.a, c.b);
    if (e.ok) simulated_settings.value[c.a] = c.b;
    else strcpy(e.msg, "Machine did not confirm change.");
  }
  e.settings = simulated_settings;
  evq.push_back(e);
  return true;
}
bool poll(UiEvent &e) { if (evq.empty()) return false; e = evq.front(); evq.pop_front(); return true; }
bool panel_can_restart() { return true; }
LinkState state() { return LinkState::Connected; }
}
static uint16_t fb[800 * 480];
static void flush(lv_display_t *d, const lv_area_t *a, uint8_t *px) {
  for (int y = a->y1; y <= a->y2; ++y)
    memcpy(&fb[y * 800 + a->x1], px + ((y - a->y1) * (a->x2 - a->x1 + 1)) * 2, (a->x2 - a->x1 + 1) * 2);
  lv_display_flush_ready(d);
}
static void save(const char *fn) {
  FILE *f = fopen(fn, "wb"); fprintf(f, "P6 800 480 255\n");
  for (int i = 0; i < 800 * 480; ++i) { uint16_t c = fb[i];
    unsigned char rgb[3] = {(unsigned char)((c >> 11) << 3), (unsigned char)(((c >> 5) & 63) << 2), (unsigned char)((c & 31) << 3)};
    fwrite(rgb, 1, 3, f); }
  fclose(f);
}
static void run(int ms) { for (int t = 0; t < ms; t += 10) { now += 10; ui::tick(); lv_timer_handler(); } }
static void ev(UiEvType t, int i = 0, float f = 0, const char *m = "") {
  UiEvent e; e.type = t; e.i = i; e.f = f; strncpy(e.msg, m, sizeof e.msg - 1); evq.push_back(e);
}
static void frames(const char *prefix, int ms, int every) {
  char fn[128];
  for (int t = 0, k = 0; t <= ms; t += every, ++k) { run(every); snprintf(fn, sizeof fn, "%s_%03d.ppm", prefix, k); save(fn); }
}
int main(int argc, char **argv) {
  lv_init(); lv_tick_set_cb(millis);
  static uint8_t buf[800 * 480 * 2];
  lv_display_t *d = lv_display_create(800, 480);
  lv_display_set_color_format(d, LV_COLOR_FORMAT_RGB565);
  lv_display_set_flush_cb(d, flush);
  lv_display_set_buffers(d, buf, nullptr, sizeof buf, LV_DISPLAY_RENDER_MODE_PARTIAL);
  ui::begin(); now += 1500; // simulate Bluetooth setup before the first rendered UI frame
  ui::tick(); run(300); save("0_connecting.ppm");
  if (argc > 1 && !strcmp(argv[1], "appearance-test")) {
    assert(appearance::welcome_visible());
    auto *greeting = lv_obj_get_child(lv_layer_top(), -1);
    lv_obj_send_event(greeting, LV_EVENT_PRESSED, nullptr);
    assert(appearance::welcome_visible()); // the initial 300 ms tap is ignored
    run(1690); // 1990 ms after startup
    lv_obj_send_event(greeting, LV_EVENT_PRESSED, nullptr);
    assert(appearance::welcome_visible());
    run(10); // 2000 ms: first permitted skip
    lv_obj_send_event(greeting, LV_EVENT_PRESSED, nullptr);
    assert(!appearance::welcome_visible());
    appearance::open_settings();
    auto find_label = [](auto &&self, lv_obj_t *object, const char *value) -> lv_obj_t * {
      if (lv_obj_check_type(object, &lv_label_class) && !strcmp(lv_label_get_text(object), value)) return object;
      for (uint32_t i=0; i<lv_obj_get_child_count(object); ++i)
        if (auto *found = self(self, lv_obj_get_child(object, i), value)) return found;
      return nullptr;
    };
    auto *replay = find_label(find_label, lv_screen_active(), "Welcome preview"); assert(replay);
    lv_obj_send_event(lv_obj_get_parent(replay), LV_EVENT_CLICKED, nullptr);
    ui::tick(); // start the replay clock on the next UI tick, as on the device
    assert(appearance::welcome_visible());
    run(1990); lv_obj_send_event(greeting, LV_EVENT_PRESSED, nullptr); assert(appearance::welcome_visible());
    run(3000); assert(appearance::welcome_visible()); // 4990 ms, not yet expired
    run(10); assert(!appearance::welcome_visible()); // exactly 5000 ms
    run(200); save("appearance-settings.ppm");
    net::set_pref_saver(screen_prefs::Saver::Still);
    appearance::show_saver(true); run(300); save("appearance-still.ppm");
    std::vector<uint16_t> before(fb, fb + 800*480);
    run(1000); assert(!memcmp(before.data(), fb, sizeof fb));
    net::set_pref_saver(screen_prefs::Saver::Motion); run(300);
    before.assign(fb, fb + 800*480); run(800); assert(memcmp(before.data(), fb, sizeof fb));
    save("appearance-motion.ppm");
    net::set_pref_background(screen_prefs::Theme::Cream); run(200); save("appearance-cream.ppm");
    appearance::show_saver(false); run(200);
    puts("PASS five-second welcome, two-second touch gate including replay, still frame stability, steam and backgrounds");
    return 0;
  }
  run(screen_prefs::welcome_ms); // finish welcome before existing preview tests
  if (argc > 1 && !strcmp(argv[1], "ota-test")) {
    ev(UiEvType::Link,3,0,"XBLOOM Studio"); run(300);
    ui::sim_show(12,0); run(350);
    assert(net::feed().state == net::FeedState::Current);
    assert(net::feed().last_checked[0]);
    auto label_present = [](auto &&self, lv_obj_t *obj, const char *needle) -> bool {
      if (lv_obj_check_type(obj,&lv_label_class) && strstr(lv_label_get_text(obj),needle)) return true;
      for (uint32_t i=0;i<lv_obj_get_child_count(obj);++i)
        if (self(self,lv_obj_get_child(obj,i),needle)) return true;
      return false;
    };
    assert(label_present(label_present,lv_screen_active(),"Last checked   2026-11-02 09:25"));
    save("update-customers.ppm");
    net::select_pilot(true); run(350);
    assert(net::feed().state == net::FeedState::Available);
    assert(net::update_state() == net::Upd::Idle);
    assert(!net::install_online("3.4.2",false));
    assert(!net::install_online("3.4.1",true));
    assert(net::install_online("3.4.2",true));
    puts("PASS customer feed, pilot offer, no automatic install, channel and version confirmation");
    return 0;
  }
  if (argc > 1 && !strcmp(argv[1], "machine-test")) {
    simulated_settings = {{1, 1, 0, 720, 1200}, 720};
    ev(UiEvType::Link, 3, 0, "XBLOOM Studio"); run(200);
    ui::sim_show(30, 0); run(400);
    auto find_text = [](auto &&self, lv_obj_t *parent, const char *label) -> lv_obj_t * {
      if (lv_obj_check_type(parent, &lv_label_class) && !strcmp(lv_label_get_text(parent), label))
        return lv_obj_get_parent(parent);
      for (uint32_t i = 0; i < lv_obj_get_child_count(parent); ++i)
        if (lv_obj_t *found = self(self, lv_obj_get_child(parent, i), label)) return found;
      return nullptr;
    };
    lv_obj_t *temp_row = find_text(find_text, lv_screen_active(), "Temperature unit");
    assert(temp_row);
    lv_obj_t *temp = lv_obj_get_child(temp_row, -1);
    assert(lv_obj_check_type(temp, &lv_dropdown_class));
    assert(lv_dropdown_get_selected(temp) == 1 && !machine_writes);
    save("machine-settings.ppm");
    auto apply = [&](int selection) {
      lv_dropdown_set_selected(temp, selection);
      lv_obj_send_event(temp, LV_EVENT_VALUE_CHANGED, nullptr);
      lv_obj_t *button = find_text(find_text, lv_layer_top(), "Apply");
      assert(button);
      lv_obj_send_event(button, LV_EVENT_CLICKED, nullptr);
      run(100);
    };
    apply(0); assert(machine_writes == 1 && lv_dropdown_get_selected(temp) == 0);
    reject_write = true;
    apply(1); assert(machine_writes == 2 && lv_dropdown_get_selected(temp) == 0);
    ev(UiEvType::Link, 0); run(100);
    assert(lv_obj_has_state(temp, LV_STATE_DISABLED));
    puts("PASS machine settings read, confirmed write, rejected write and disconnect");
    return 0;
  }
  if (argc > 1 && !strcmp(argv[1], "light-test")) {
    using namespace ring_light;
    ev(UiEvType::Link, 3, 0, "XBLOOM 381"); run(300);
    assert(!state().on && sim_output().a == 0);
    set_brightness(100); set_colour(Colour::Cool); set_on(true);
    set_option(Option::StartFade, true); set_option(Option::PourPulse, true);
    set_option(Option::PausePulse, true); set_option(Option::FinishFlash, true);
    ui::sim_show(21, 0); run(100);
    assert(sim_output().a > 0 && sim_output().a < 30);
    run(2100); assert(sim_output().a == 51);
    ev(UiEvType::Water, 0, 20); run(850); assert(sim_output().a > 200);
    ev(UiEvType::BrewPaused); run(250);
    assert(sim_output().a >= 26 && sim_output().a <= 128);
    run(1700); assert(sim_output().a >= 110 && sim_output().a <= 128);
    ev(UiEvType::BrewResumed); run(400); assert(sim_output().a == 51);
    ev(UiEvType::BrewDone); run(300); assert(sim_output().a > 245);
    run(1200); assert(sim_output().a == 0);
    run(200); assert(sim_output().a == 255);
    ui::sim_show(21, 0); ev(UiEvType::BrewAbandoned); run(300);
    assert(sim_output().a == 255);
    ui::sim_show(21, 0); ev(UiEvType::Link, 0); run(300);
    assert(sim_output().a == 255);
    set_on(false); ev(UiEvType::BrewDone); run(300); assert(sim_output().a == 0);
    puts("PASS: UI brew events drive start, pour, pause, finish, cancellation and disconnect correctly");
    return 0;
  }
  if (argc > 1 && !strcmp(argv[1], "light")) {
    ev(UiEvType::Link, 3, 0, "XBLOOM 381"); run(500);
    ui::sim_show(9, 0); run(500); save("light-settings.ppm");
    ui::sim_show(28, 0); run(500); save("light-controls.ppm");
    ui::sim_show(29, 0); run(500); save("light-behaviour.ppm");
    return 0;
  }
  if (argc > 1 && !strcmp(argv[1], "settings")) {
    ev(UiEvType::Link, 3, 0, "XBLOOM 381"); run(500);
    ui::sim_show(9, 0); run(800); save("st_settings.ppm");
    ui::sim_show(27, 0); run(800); save("st_dropdown.ppm");
    ui::sim_show(13, 0); run(400); save("st_clock.ppm");
    return 0;
  }
  if (argc > 1 && !strcmp(argv[1], "detail")) {
    ev(UiEvType::Link, 3, 0, "XBLOOM 381"); run(500);
    ui::sim_show(1, 0); run(800); save("d0_recipes.ppm");
    ui::sim_show(2, 0); run(800); save("d1_detail.ppm");
    ui::sim_show(7, 0); run(600); save("d2_ready.ppm"); ui::sim_show(8, 0);
    ui::sim_show(21, 0);
    for (int k = 0; k < 25; ++k) { ev(UiEvType::Water, 0, 0); run(40); }
    save("d3_brewing_start.ppm");
    return 0;
  }
  if (argc > 1 && !strcmp(argv[1], "anim")) {
    ev(UiEvType::Link, 3, 0, "XBLOOM 381"); run(500);
    ui::sim_show(21, 0);
    {  // a compressed brew: 3 pours (60 / 80 / 80 ml) with pauses between them
      char fn[64]; int k = 0;
      auto water_at = [](float s) -> float {
        if (s < 0.6f) return 0; if (s < 2.6f) return (s - 0.6f) / 2 * 60; if (s < 3.6f) return 60;
        if (s < 5.6f) return 60 + (s - 3.6f) / 2 * 80; if (s < 6.4f) return 140;
        if (s < 8.4f) return 140 + (s - 6.4f) / 2 * 80; return 220; };
      for (float s = 0; s <= 9.2f; s += 0.04f, ++k) {
        const float w = water_at(s);
        ev(UiEvType::Water, 0, w); ev(UiEvType::Weight, 0, w * 0.64f + 22 * (s > 0.8f));
        if (s > 0.55f && s < 0.6f) ev(UiEvType::PourIndex, 0);
        if (s > 3.55f && s < 3.6f) ev(UiEvType::PourIndex, 1);
        if (s > 6.35f && s < 6.4f) ev(UiEvType::PourIndex, 2);
        run(40); snprintf(fn, sizeof fn, "brew_%03d.ppm", k); save(fn);
      }
    }
    ui::sim_show(26, 0); ui::sim_show(25, 0); run(400); save("stats.ppm");
    ui::sim_show(22, 0); frames("finish", 3600, 40);
    ui::sim_show(0, 0); ui::sim_show(24, 0); run(200); save("clock_blue.ppm");
    ui::sim_show(23, 0); run(200); save("clock_white.ppm");
    return 0;
  }
  ev(UiEvType::Link, 3, 0, "XBLOOM 381"); run(1500); save("1_home.ppm");
  ui::sim_show(1, 0); run(1500); save("2_recipes.ppm");
  ui::sim_show(2, 0); run(1500); save("3_detail_mad.ppm");
  ui::sim_show(7, 0); run(600); save("3b_modal.ppm"); ui::sim_show(8, 0);
  ui::sim_show(2, 2); run(1500); save("4_detail_starter.ppm");
  ui::sim_show(3, 1); ev(UiEvType::Weight, 0, 88.4f); run(1500); save("5_detail_brewing.ppm");
  ui::sim_show(4, 0); run(1500); save("6_grinder.ppm");
  ui::sim_show(5, 0); run(1500); save("7_brewer.ppm");
  ev(UiEvType::Weight, 0, 0.0f); ui::sim_show(6, 0); run(1500); save("8_scale.ppm");
  ui::sim_show(9, 0); run(1500); save("9_settings.ppm");
  ui::sim_show(10, 0); run(1500); save("10_wifi.ppm");
  ui::sim_show(11, 0); run(1500); save("11_password.ppm");
  ui::sim_show(12, 0); run(1500); save("12_update.ppm");
  ui::sim_show(13, 0); run(1500); save("13_clock.ppm");
  ui::sim_show(14, 0); ui::sim_show(0, 0); run(1500); save("14_home_synced.ppm");
  ui::sim_show(18, 0); run(1500); save("15_created.ppm");
  ui::sim_show(17, 0); run(1500); save("16_shared.ppm");
  ui::sim_show(2, 0); run(1500); save("17_detail_heart.ppm");
  ui::sim_show(15, 0); run(1500); save("18_editor.ppm");
  ui::sim_show(19, 0); run(600); save("19_confirm.ppm"); ui::sim_show(20, 0);
  ui::sim_show(16, 0); run(1500); save("20_account.ppm");
}
