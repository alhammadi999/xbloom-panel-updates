#include "spotify_remote.h"
#include <cstring>
namespace spotify {
static State view;
void begin() {}
State state() { return view; }
void set_enabled(bool on) { view.enabled = on; if (!on) view.controls = false; }
void set_visible(bool) {}
void start_pairing() { if (view.enabled && !view.linked) (strcpy(view.pairing_code, "123456"), strcpy(view.login_url, "http://192.168.0.128/spotify/start?state=192.168.0.128~0123456789abcdef0123456789abcdef")); }
void disconnect() { view = State{}; view.enabled = true; }
bool command(Command cmd, int value) {
  if (!view.enabled || !view.controls) return false;
  if (cmd == Command::Volume) { if (!view.can_volume || value<0 || value>100) return false; view.volume=value; }
  if (cmd == Command::Play) view.playing = true;
  if (cmd == Command::Pause) view.playing = false;
  return true;
}
void tick(bool) {}
bool accept_link(const char *, const char *, const char *) { return false; }
void sim_playback() {
  view = State{};
  view.enabled = view.linked = view.controls = view.playing = true;
  view.can_play = view.can_pause = view.can_next = view.can_previous = true;
  view.can_volume = true; view.volume = 35;
  strcpy(view.title, "Your favourite song"); strcpy(view.artist, "Artist name");
  strcpy(view.device, "My phone"); strcpy(view.device_id, "simulated-phone");
  strcpy(view.message, "Audio plays on your phone's connected speaker.");
}
}
