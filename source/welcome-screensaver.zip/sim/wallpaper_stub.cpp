#include "wallpaper.h"
#include <cstdlib>
namespace wallpaper {
Image::Image() { pixels = static_cast<uint8_t *>(malloc(pixel_bytes)); }
Image::~Image() { free(pixels); }
void begin() {}
std::shared_ptr<const Image> current() { return {}; }
bool start_upload() { return false; }
bool write_upload(const uint8_t *, size_t) { return false; }
bool finish_upload() { return false; }
void abort_upload() {}
}
