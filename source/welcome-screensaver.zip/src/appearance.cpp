#include "appearance.h"
#include "panel_net.h"
#include "wallpaper.h"
#include "ui_theme.h"
#include "ui.h"
#include <Arduino.h>
#include <lvgl.h>
#include <cmath>
#include <initializer_list>

namespace appearance {
namespace {
using screen_prefs::Saver;
using screen_prefs::Theme;
struct Palette { uint32_t background, foreground, muted, accent, cup; };
Palette palette(Theme theme) {
  if (theme == Theme::Midnight) return {0x0C151E, 0xE1EDF5, 0x94AEBE, 0x91BBD6, 0xDBE4E9};
  if (theme == Theme::Cream) return {0xE6D9C3, 0x392C20, 0x6A5844, 0x795A35, 0xF6EEDF};
  return {0x15110E, 0xF2E9DC, 0xB2A18B, 0xC8A475, 0xE4D4BB};
}
lv_obj_t *welcome, *welcome_dot, *petals[6], *idle, *cup_group, *steam[3], *idle_brand, *idle_title, *idle_sub, *idle_hint, *photo;
lv_obj_t *settings, *previous, *mode_dd, *theme_dd, *welcome_switch, *preview, *preview_label, *preview_photo, *upload_page, *upload_address;
lv_point_precise_t petal_points[6][17];
lv_point_precise_t steam_points[3][9];
lv_image_dsc_t photo_descriptor = {};
lv_image_dsc_t preview_descriptor = {};
std::shared_ptr<const wallpaper::Image> held_photo;
std::shared_ptr<const wallpaper::Image> preview_hold;
uint32_t welcome_started = 0, last_animation = 0;
bool showing = false;
int applied_mode = -1, applied_theme = -1;

lv_obj_t *rect(lv_obj_t *parent, int x, int y, int w, int h, uint32_t colour, int radius = 0, bool filled = true) {
  auto *obj = lv_obj_create(parent);
  lv_obj_remove_style_all(obj);
  lv_obj_set_pos(obj, x, y); lv_obj_set_size(obj, w, h);
  lv_obj_set_style_radius(obj, radius, 0);
  lv_obj_set_style_bg_color(obj, lv_color_hex(colour), 0);
  lv_obj_set_style_bg_opa(obj, filled ? LV_OPA_COVER : LV_OPA_TRANSP, 0);
  lv_obj_remove_flag(obj, LV_OBJ_FLAG_SCROLLABLE | LV_OBJ_FLAG_CLICKABLE);
  return obj;
}
lv_obj_t *label(lv_obj_t *parent, const char *text, const lv_font_t *font, uint32_t colour, int x, int y) {
  auto *obj = lv_label_create(parent);
  lv_label_set_text(obj, text); lv_obj_set_pos(obj, x, y);
  lv_obj_set_style_text_font(obj, font, 0); lv_obj_set_style_text_color(obj, lv_color_hex(colour), 0);
  return obj;
}
void visible(lv_obj_t *obj, bool on) { if (on) lv_obj_remove_flag(obj, LV_OBJ_FLAG_HIDDEN); else lv_obj_add_flag(obj, LV_OBJ_FLAG_HIDDEN); }
lv_obj_t *button(lv_obj_t *parent, const char *text, int x, int y, int w, lv_event_cb_t callback) {
  auto *obj = rect(parent, x, y, w, 44, 0x292522, 18);
  lv_obj_add_flag(obj, LV_OBJ_FLAG_CLICKABLE);
  auto *title = label(obj, text, &inter_16, 0xF2E9DC, 0, 0); lv_obj_center(title);
  lv_obj_add_event_cb(obj, callback, LV_EVENT_CLICKED, nullptr);
  return obj;
}
void dismiss_welcome() { if (welcome) visible(welcome, false); }
bool visible_welcome() { return welcome && !lv_obj_has_flag(welcome, LV_OBJ_FLAG_HIDDEN); }
void build_welcome() {
  welcome = rect(lv_layer_top(), 0, 0, 800, 480, 0x12100E);
  lv_obj_add_flag(welcome, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_add_event_cb(welcome, [](lv_event_t *) { dismiss_welcome(); }, LV_EVENT_PRESSED, nullptr);
  label(welcome, "STUDIO COMPANION", &inter_14, 0xA99984, 48, 32);
  constexpr double pi = 3.141592653589793;
  for (int p = 0; p < 6; ++p) {
    const double angle = p * pi / 3;
    for (int j = 0; j <= 16; ++j) {
      double t = j * 2 * pi / 16, x = 11 * sin(t), y = -23 * (1 - cos(t));
      petal_points[p][j] = {lv_value_precise_t(56 + x*cos(angle) - y*sin(angle)), lv_value_precise_t(56 + x*sin(angle) + y*cos(angle))};
    }
    petals[p] = lv_line_create(welcome);
    lv_line_set_points(petals[p], petal_points[p], 17);
    lv_obj_set_pos(petals[p], 344, 74);
    lv_obj_set_style_line_width(petals[p], 2, 0);
    lv_obj_set_style_line_color(petals[p], lv_color_hex(0xC8A475), 0);
  }
  rect(welcome, 396, 126, 8, 8, 0xC8A475, LV_RADIUS_CIRCLE);
  auto *brand = label(welcome, "xBloom", &inter_64b, 0xF2E9DC, 0, 208); lv_obj_align(brand, LV_ALIGN_TOP_MID, 0, 202);
  auto *studio = label(welcome, "S T U D I O", &inter_14, 0xC8A475, 0, 277); lv_obj_align(studio, LV_ALIGN_TOP_MID, 0, 279);
  auto *tagline = label(welcome, "A little ritual. A better day.", &inter_20, 0xB2A18B, 0, 324); lv_obj_align(tagline, LV_ALIGN_TOP_MID, 0, 326);
  auto *footer = label(welcome, "Your coffee experience starts here", &inter_14, 0xA99984, 0, 421); lv_obj_align(footer, LV_ALIGN_TOP_MID, 8, 421);
  welcome_dot = rect(welcome, 252, 426, 5, 5, 0xC8A475, LV_RADIUS_CIRCLE);
  visible(welcome, false);
}
void build_idle() {
  idle = rect(lv_layer_top(), 0, 0, 800, 480, 0x15110E);
  photo = lv_image_create(idle); visible(photo, false);
  idle_brand = label(idle, "xBloom   STUDIO", &inter_20, 0xF2E9DC, 48, 34);
  cup_group = rect(idle, 286, 88, 230, 210, 0, 0, false);
  auto *handle = rect(cup_group, 151, 96, 39, 48, 0xE4D4BB, 22, false);
  lv_obj_set_style_border_width(handle, 9, 0); lv_obj_set_style_border_color(handle, lv_color_hex(0xE4D4BB), 0);
  rect(cup_group, 37, 163, 157, 16, 0xC0AC90, LV_RADIUS_CIRCLE);
  auto *cup = rect(cup_group, 54, 88, 112, 78, 0xE4D4BB, 32);
  lv_obj_set_style_bg_grad_color(cup, lv_color_hex(0xBAA68A), 0); lv_obj_set_style_bg_grad_dir(cup, LV_GRAD_DIR_HOR, 0);
  auto *surface = rect(cup_group, 54, 82, 112, 20, 0x392115, LV_RADIUS_CIRCLE);
  lv_obj_set_style_border_width(surface, 4, 0); lv_obj_set_style_border_color(surface, lv_color_hex(0xE4D4BB), 0);
  for (int i = 0; i < 3; ++i) {
    for (int p = 0; p < 9; ++p) steam_points[i][p] = {lv_value_precise_t(6 + 5*sin(p * 0.78)), lv_value_precise_t(p*5)};
    steam[i] = lv_line_create(cup_group); lv_line_set_points(steam[i], steam_points[i], 9);
    lv_obj_set_pos(steam[i], 75 + i*25, 22); lv_obj_set_style_line_width(steam[i], 2, 0);
    lv_obj_set_style_line_color(steam[i], lv_color_hex(0xC8A475), 0);
  }
  idle_title = label(idle, "Take a moment.", &inter_34b, 0xF2E9DC, 0, 320); lv_obj_align(idle_title, LV_ALIGN_TOP_MID, 0, 314);
  idle_sub = label(idle, "Good things take a little brewing.", &inter_16, 0xB2A18B, 0, 368); lv_obj_align(idle_sub, LV_ALIGN_TOP_MID, 0, 368);
  idle_hint = label(idle, "Touch to wake", &inter_14, 0xB2A18B, 48, 432);
  visible(idle, false);
}
void refresh_idle() {
  const auto mode = net::pref_saver(); const auto theme = net::pref_background();
  auto image = mode == Saver::Photo ? wallpaper::current() : std::shared_ptr<const wallpaper::Image>{};
  if (applied_mode == int(mode) && applied_theme == int(theme) && image == held_photo) return;
  applied_mode = int(mode); applied_theme = int(theme);
  const auto colours = palette(theme);
  lv_obj_set_style_bg_color(idle, lv_color_hex(colours.background), 0);
  for (auto *obj : {idle_brand, idle_title}) lv_obj_set_style_text_color(obj, lv_color_hex(colours.foreground), 0);
  for (auto *obj : {idle_sub, idle_hint}) lv_obj_set_style_text_color(obj, lv_color_hex(colours.muted), 0);
  visible(photo, false);
  if (image != held_photo) {
    lv_image_set_src(photo, nullptr); lv_image_cache_drop(&photo_descriptor);
    held_photo = std::move(image);
    if (held_photo) {
      photo_descriptor = {};
      photo_descriptor.header.magic = LV_IMAGE_HEADER_MAGIC;
      photo_descriptor.header.cf = LV_COLOR_FORMAT_RGB565;
      photo_descriptor.header.w = 800; photo_descriptor.header.h = 480; photo_descriptor.header.stride = 1600;
      photo_descriptor.data_size = wallpaper::pixel_bytes; photo_descriptor.data = held_photo->pixels;
      lv_image_set_src(photo, &photo_descriptor); lv_obj_set_pos(photo, 0, 0);
    }
  }
  const bool custom = mode == Saver::Photo && held_photo;
  const bool clock = mode == Saver::Clock, off = mode == Saver::Off;
  visible(photo, custom); visible(cup_group, !custom && !clock && !off);
  visible(idle_title, !custom && !off); visible(idle_sub, !custom && !clock && !off);
  visible(idle_brand, !custom && !off); visible(idle_hint, !custom); // leave personal photos unobscured
  lv_obj_set_style_text_font(idle_title, clock ? &inter_64b : &inter_34b, 0);
  char clock_text[16] = "--:--";
  struct tm local;
  if (clock && net::local_time(&local)) strftime(clock_text, sizeof clock_text, "%H:%M", &local);
  lv_label_set_text(idle_title, clock ? clock_text : "Take a moment.");
  lv_obj_align(idle_title, LV_ALIGN_TOP_MID, 0, clock ? 195 : 314);
  lv_label_set_text(idle_sub, mode == Saver::Photo && !custom ? "Choose a photo in Screensaver settings." : "Good things take a little brewing.");
  lv_obj_align(idle_sub, LV_ALIGN_TOP_MID, 0, 368);
  if (off) lv_obj_set_style_bg_color(idle, lv_color_hex(0), 0);
  for (int i = 0; i < 3; ++i) { lv_obj_set_y(steam[i], 22); lv_obj_set_style_opa(steam[i], 110, 0); }
}
void refresh_preview() {
  const auto colours = palette(net::pref_background());
  lv_obj_set_style_bg_color(preview, lv_color_hex(colours.background), 0);
  lv_obj_set_style_text_color(preview_label, lv_color_hex(colours.foreground), 0);
  const auto mode = net::pref_saver();
  auto image = mode == Saver::Photo ? wallpaper::current() : std::shared_ptr<const wallpaper::Image>{};
  visible(preview_photo, false);
  if (image != preview_hold) {
    lv_image_set_src(preview_photo, nullptr); lv_image_cache_drop(&preview_descriptor);
    preview_hold = std::move(image);
    if (preview_hold) {
      preview_descriptor = {};
      preview_descriptor.header.magic = LV_IMAGE_HEADER_MAGIC; preview_descriptor.header.cf = LV_COLOR_FORMAT_RGB565;
      preview_descriptor.header.w = 800; preview_descriptor.header.h = 480; preview_descriptor.header.stride = 1600;
      preview_descriptor.data_size = wallpaper::pixel_bytes; preview_descriptor.data = preview_hold->pixels;
      lv_image_set_src(preview_photo, &preview_descriptor); lv_image_set_scale(preview_photo, 111); lv_obj_center(preview_photo);
    }
  }
  visible(preview_photo, bool(preview_hold)); visible(preview_label, !preview_hold);
  if (mode == Saver::Off) lv_obj_set_style_bg_color(preview, lv_color_hex(0), 0);
  const char *message = mode == Saver::Clock ? "Clock" : mode == Saver::Off ? "Screen off" : mode == Saver::Photo ? (wallpaper::current() ? "My photo saved" : "Add your photo") : "Take a moment.";
  lv_label_set_text(preview_label, message); lv_obj_center(preview_label);
  lv_dropdown_set_selected(mode_dd, unsigned(mode)); lv_dropdown_set_selected(theme_dd, unsigned(net::pref_background()));
}
lv_obj_t *dropdown(lv_obj_t *parent, const char *options, int x, int y, lv_event_cb_t changed) {
  auto *obj = lv_dropdown_create(parent); lv_dropdown_set_options_static(obj, options);
  lv_obj_set_pos(obj, x, y); lv_obj_set_size(obj, 354, 43);
  lv_obj_set_style_text_font(obj, &inter_16, 0);
  lv_obj_set_style_bg_color(obj, lv_color_hex(0x242424), 0); lv_obj_set_style_text_color(obj, lv_color_hex(0xF2E9DC), 0);
  auto *list = lv_dropdown_get_list(obj); lv_obj_set_style_bg_color(list, lv_color_hex(0x242424), 0); lv_obj_set_style_text_color(list, lv_color_hex(0xF2E9DC), 0);
  lv_obj_add_event_cb(obj, changed, LV_EVENT_VALUE_CHANGED, nullptr); return obj;
}
void close_settings() { net::appearance_page(false); lv_screen_load(previous); }
void open_upload() {
  net::appearance_page(true);
  char text[240];
  if (net::state() == net::Wifi::Connected)
    snprintf(text, sizeof text, "On the same Wi-Fi, open:\nhttp://%s/wallpaper\n\nChoose a photo on your phone.\nIt is resized to fit and saved on this panel.", net::ip());
  else snprintf(text, sizeof text, "Connect the panel to Wi-Fi first.\nThen return here to add your photo.");
  lv_label_set_text(upload_address, text); lv_screen_load(upload_page);
}
void build_settings() {
  settings = rect(nullptr, 0, 0, 800, 480, 0x080808);
  button(settings, "< Back", 24, 44, 106, [](lv_event_t *) { close_settings(); });
  label(settings, "Screensaver", &inter_26b, 0xF2E9DC, 150, 52);
  preview = rect(settings, 24, 110, 348, 248, 0x15110E, 16);
  preview_photo = lv_image_create(preview); visible(preview_photo, false);
  preview_label = label(preview, "Take a moment.", &inter_26b, 0xF2E9DC, 0, 0); lv_obj_center(preview_label);
  label(settings, "When idle", &inter_16, 0xAEAEB2, 398, 106);
  mode_dd = dropdown(settings, "Coffee motion\nStill background\nClock\nMy photo\nScreen off", 398, 132, [](lv_event_t *event) {
    net::set_pref_saver(screen_prefs::saver(lv_dropdown_get_selected(static_cast<lv_obj_t *>(lv_event_get_target(event))))); refresh_preview();
  });
  label(settings, "Background", &inter_16, 0xAEAEB2, 398, 192);
  theme_dd = dropdown(settings, "Espresso\nMidnight\nCream", 398, 218, [](lv_event_t *event) {
    net::set_pref_background(screen_prefs::theme(lv_dropdown_get_selected(static_cast<lv_obj_t *>(lv_event_get_target(event))))); refresh_preview();
  });
  button(settings, "Choose my photo", 398, 282, 354, [](lv_event_t *) { open_upload(); });
  label(settings, "Welcome at startup", &inter_16, 0xF2E9DC, 398, 351);
  welcome_switch = lv_switch_create(settings); lv_obj_set_pos(welcome_switch, 694, 345); lv_obj_set_size(welcome_switch, 56, 32);
  lv_obj_add_event_cb(welcome_switch, [](lv_event_t *event) { net::set_pref_welcome(lv_obj_has_state(static_cast<lv_obj_t *>(lv_event_get_target(event)), LV_STATE_CHECKED)); }, LV_EVENT_VALUE_CHANGED, nullptr);
  button(settings, "Preview", 24, 386, 166, [](lv_event_t *) { showing = true; refresh_idle(); visible(idle, true); lv_obj_move_foreground(idle); });
  button(settings, "Welcome preview", 206, 386, 166, [](lv_event_t *) { welcome_started = millis(); visible(welcome, true); lv_obj_move_foreground(welcome); });
  label(settings, "Sleep time and night mode follow Screen settings.", &inter_14, 0x8E8E93, 398, 413);
  // A preview is dismissed on its first touch, without activating underlying settings.
  lv_obj_add_flag(idle, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_add_event_cb(idle, [](lv_event_t *) { show_saver(false); }, LV_EVENT_PRESSED, nullptr);
  upload_page = rect(nullptr, 0, 0, 800, 480, 0x080808);
  button(upload_page, "< Back", 24, 44, 106, [](lv_event_t *) { net::appearance_page(false); refresh_preview(); lv_screen_load(settings); });
  label(upload_page, "Your background", &inter_26b, 0xF2E9DC, 150, 52);
  upload_address = label(upload_page, "", &inter_20, 0xD8C4A5, 48, 130); lv_obj_set_width(upload_address, 704);
  label(upload_page, "Uploads are enabled only while this page is open.", &inter_16, 0x8E8E93, 48, 400);
}
}
void begin() {
  build_idle(); build_welcome(); build_settings();
  if (net::pref_welcome()) { welcome_started = millis(); visible(welcome, true); lv_obj_move_foreground(welcome); }
}
void open_settings() {
  if (ui::busy()) return;
  previous = lv_screen_active(); refresh_preview();
  if (net::pref_welcome()) lv_obj_add_state(welcome_switch, LV_STATE_CHECKED); else lv_obj_remove_state(welcome_switch, LV_STATE_CHECKED);
  lv_screen_load(settings);
}
void show_saver(bool on) {
  showing = on;
  if (on) { refresh_idle(); lv_obj_move_foreground(idle); }
  visible(idle, on);
  if (!on && held_photo) {
    lv_image_set_src(photo, nullptr); lv_image_cache_drop(&photo_descriptor); held_photo.reset();
    applied_mode = -1;
  }
}
bool welcome_visible() { return visible_welcome(); }
bool photo_page_visible() { return upload_page && lv_screen_active() == upload_page; }
void tick() {
  const uint32_t now = millis();
  if (net::take_appearance_wake()) { show_saver(false); lv_display_trigger_activity(nullptr); refresh_preview(); }
  const bool intro = visible_welcome();
  if (intro && uint32_t(now - welcome_started) >= screen_prefs::welcome_ms) dismiss_welcome();
  if (lv_screen_active() != upload_page) net::appearance_page(false);
  if (lv_screen_active() != settings && lv_screen_active() != upload_page && preview_hold) {
    lv_image_set_src(preview_photo, nullptr); lv_image_cache_drop(&preview_descriptor); preview_hold.reset();
  }
  if (showing) refresh_idle();
  if (uint32_t(now - last_animation) < screen_prefs::animation_step_ms) return;
  last_animation = now;
  if (intro) {
    for (int i = 0; i < 6; ++i) {
      const int opacity = int(150 + 95*sin((now-welcome_started)*0.0025 - i*0.35));
      lv_obj_set_style_line_opa(petals[i], opacity, 0);
    }
    lv_obj_set_style_opa(welcome_dot, int(150 + 95*sin((now-welcome_started)*0.003)), 0);
  }
  if (showing && net::pref_saver() == Saver::Motion && !intro) {
    for (int i = 0; i < 3; ++i) {
      const double phase = now * 0.0018 + i*1.6;
      lv_obj_set_y(steam[i], 22 + int(5*sin(phase)));
      lv_obj_set_style_opa(steam[i], int(105 + 65*sin(phase)), 0);
    }
  }
}
}
