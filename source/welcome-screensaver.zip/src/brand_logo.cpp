#include "brand_logo.h"
#include "brand_logo_data.inc"
namespace brand {
const lv_image_dsc_t &welcome_logo() {
  static const lv_image_dsc_t image = [] {
    lv_image_dsc_t value = {};
    value.header.magic = LV_IMAGE_HEADER_MAGIC; value.header.cf = LV_COLOR_FORMAT_RGB565;
    value.header.w = 480; value.header.h = 218; value.header.stride = 960;
    value.data_size = sizeof logo_welcome_pixels; value.data = logo_welcome_pixels;
    return value;
  }();
  return image;
}
const lv_image_dsc_t &saver_logo() {
  static const lv_image_dsc_t image = [] {
    lv_image_dsc_t value = {};
    value.header.magic = LV_IMAGE_HEADER_MAGIC; value.header.cf = LV_COLOR_FORMAT_RGB565;
    value.header.w = 132; value.header.h = 60; value.header.stride = 264;
    value.data_size = sizeof logo_saver_pixels; value.data = logo_saver_pixels;
    return value;
  }();
  return image;
}
}
