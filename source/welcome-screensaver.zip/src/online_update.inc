// Runs on the network task. The panel only downloads from the owner's HTTPS origin.
constexpr char FEED_ROOT[] = "https://raw.githubusercontent.com/alhammadi999/xbloom-panel-updates/main/";
net::Feed online_feed;
struct Release {
  char digest[65] = {};
  size_t bytes = 0;
} online_release;
bool check_queued = false, install_queued = false, online_installing = false;
uint32_t next_check = 0;
bool was_online = false;

class FeedRequest {
 public:
  esp_http_client_handle_t http = nullptr;
  int64_t length = -1;
  bool open(const String &url) {
    esp_http_client_config_t cfg = {};
    cfg.url = url.c_str();
    cfg.crt_bundle_attach = esp_crt_bundle_attach;
    cfg.disable_auto_redirect = true;
    cfg.timeout_ms = 6000;
    cfg.buffer_size = 4096;
    http = esp_http_client_init(&cfg);
    if (!http) return false;
    esp_http_client_set_header(http, "Accept-Encoding", "identity");
    if (esp_http_client_open(http, 0) != ESP_OK) return false;
    length = esp_http_client_fetch_headers(http);
    return length >= 0 && esp_http_client_get_status_code(http) == 200;
  }
  ~FeedRequest() { if (http) esp_http_client_cleanup(http); }
};

const char *read_feed(bool pilot, net::Feed &result, Release &release) {
  pilot = update_policy::selected_pilot(pilot);
  result.pilot = pilot;
  FeedRequest req;
  const char *channel = pilot ? "pilot" : "stable";
  if (!req.open(String(FEED_ROOT) + channel + ".json")) return "Cannot reach update service. Try again.";
  char body[1025];
  if (req.length > sizeof(body)-1) return "Update information too large.";
  int used = 0;
  uint32_t start = millis();
  while (used < int(sizeof(body)-1) && millis()-start < 15000) {
    int n = esp_http_client_read(req.http, body+used, sizeof(body)-1-used);
    if (n < 0) return "Update check interrupted.";
    if (!n) break;
    used += n;
    if (esp_http_client_is_complete_data_received(req.http)) break;
  }
  if (!esp_http_client_is_complete_data_received(req.http)) return "Incomplete update information.";
  JsonDocument doc;
  if (deserializeJson(doc, body, used)) return "Invalid update information.";
  const char *ver = doc["version"] | "";
  const char *hash = doc["sha256"] | "";
  const char *notes = doc["notes"] | "";
  const auto *slot = esp_ota_get_next_update_partition(nullptr);
  if (doc["schema"] != 1 || strcmp(doc["board"] | "", PANEL_OTA_BOARD) ||
      strcmp(doc["channel"] | "", channel) || ota::version_number(ver) < 0 ||
      !ota::digest_valid(hash) || !doc["bytes"].is<uint32_t>() || !slot ||
      doc["bytes"].as<uint32_t>() < 500000 || doc["bytes"].as<uint32_t>() > slot->size)
    return "Incompatible update information.";
  release.bytes = doc["bytes"].as<uint32_t>();
  strlcpy(release.digest, hash, sizeof release.digest);
  strlcpy(result.version, ver, sizeof result.version);
  strlcpy(result.notes, notes, sizeof result.notes);
  result.state = ota::version_number(ver) > ota::version_number(FW_VERSION)
               ? net::FeedState::Available : net::FeedState::Current;
  return nullptr;
}

const char *fetch_image(const Release &release, const char *version) {
  if (!ble_link::panel_can_restart()) return "Wait for the Studio to return home.";
  FeedRequest req;
  if (!req.open(String(FEED_ROOT) + "xbloom-saud-" + version + ".bin")) return "Download failed. Check Wi-Fi and retry.";
  if (req.length > 0 && size_t(req.length) != release.bytes) return "Incorrect image size.";
  const size_t chunk = 4096;
  char marker[96];
  snprintf(marker, sizeof marker, PANEL_OTA_MARKER "%s|", version);
  const size_t marker_len = strlen(marker);
  std::unique_ptr<uint8_t[]> buf(new(std::nothrow) uint8_t[chunk + sizeof marker]);
  if (!buf || !Update.begin(release.bytes, U_FLASH)) return "Unable to open update slot.";
  mbedtls_sha256_context sha;
  mbedtls_sha256_init(&sha);
  const char *error = mbedtls_sha256_starts(&sha, 0) == 0 ? nullptr : "Hash initialization failed.";
  size_t count = 0, tail = 0;
  bool identified = false;
  uint32_t started = millis();
  while (!error && count < release.bytes) {
    if (!ble_link::panel_can_restart()) { error = "Studio became busy. Update cancelled."; break; }
    if (millis()-started > 300000) { error = "Download timed out."; break; }
    int n = esp_http_client_read(req.http, (char*)buf.get()+tail, std::min(chunk,release.bytes-count));
    if (n <= 0) { error = "Download interrupted. Retry when connected."; break; }
    uint8_t *data = buf.get()+tail;
    if (!count && data[0] != 0xe9) { error = "Invalid firmware image."; break; }
    if (mbedtls_sha256_update(&sha,data,n) || Update.write(data,n) != size_t(n)) { error = "Image write failed."; break; }
    if (!identified) {
      identified = memmem(buf.get(), tail+n, marker, marker_len) != nullptr;
      const size_t keep = std::min(marker_len-1,tail+size_t(n));
      memmove(buf.get(),buf.get()+tail+n-keep,keep);
      tail = keep;
    }
    count += n;
    g_upd_pct = int(count*99/release.bytes);
    delay(1);
  }
  if (!error && req.length == 0 && !esp_http_client_is_complete_data_received(req.http)) {
    char extra;
    if (esp_http_client_read(req.http, &extra, 1) != 0 || !esp_http_client_is_complete_data_received(req.http))
      error = "Unexpected firmware length.";
  }
  uint8_t hash[32];
  char hex[65] = {};
  if (!error && mbedtls_sha256_finish(&sha,hash) == 0)
    for (int i=0;i<32;++i) snprintf(hex+2*i,3,"%02x",unsigned(hash[i]));
  mbedtls_sha256_free(&sha);
  if (!error && strcmp(hex,release.digest)) error = "Firmware checksum mismatch. Installation cancelled.";
  if (!error && !identified) error = "Firmware version mismatch. Installation cancelled.";
  if (!error && !ble_link::panel_can_restart()) error = "Studio is busy. Try again later.";
  if (!error && !Update.end()) error = "Firmware image rejected.";
  if (error) Update.abort();
  return error;
}

void online_tick() {
  bool connected = WiFi.status() == WL_CONNECTED;
  if (connected && !was_online) next_check = millis()+3000;
  was_online = connected;
  bool install;
  net::Feed result;
  Release release;
  {
    Lock l;
    install = install_queued;
    if (install) {
      install_queued = false;
      online_installing = true;
      result = online_feed;
      release = online_release;
    } else {
      if (!connected || !net::time_valid() || g_upd == net::Upd::Receiving) return;
      if (!check_queued && int32_t(millis()-next_check) < 0) return;
      check_queued = false;
      result.pilot = online_feed.pilot;
      online_feed.state = net::FeedState::Checking;
    }
  }
  if (install) {
    const char *err = connected ? fetch_image(release,result.version) : "Wi-Fi disconnected.";
    if (err) { set_err(err); g_upd = net::Upd::Failed; }
    else { g_upd_pct = 100; g_upd = net::Upd::Done; delay(800); ESP.restart(); }
    Lock l;
    online_installing = false;
  } else {
    const char *err = read_feed(result.pilot,result,release);
    Lock l;
    if (online_feed.pilot != result.pilot) return;
    if (err) { result.state = net::FeedState::Failed; strlcpy(result.notes,err,sizeof result.notes); }
    if (err) strlcpy(result.last_checked,online_feed.last_checked,sizeof result.last_checked);
    else {
      struct tm local;
      if (net::local_time(&local))
        strftime(result.last_checked,sizeof result.last_checked,"%Y-%m-%d %H:%M",&local);
    }
    online_feed = result;
    online_release = release;
    next_check = millis() + (err ? 300000UL : 21600000UL);
  }
}
