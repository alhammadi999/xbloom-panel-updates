#include "ota_boot.h"
#include <esp_ota_ops.h>
#include <stdio.h>

namespace ota_boot {
bool Confirmation::poll(uint32_t now, bool startup_ready) {
  if (done_ || !startup_ready) return done_;
  if (attempted_ && uint32_t(now - last_attempt_) < 1000) return false;
  attempted_ = true;
  last_attempt_ = now;
  const esp_partition_t *running = esp_ota_get_running_partition();
  const esp_partition_t *boot = esp_ota_get_boot_partition();
  if (!running || !boot || running->address != boot->address) {
    // Never validate a different image or overwrite a newly selected update.
    printf("[update] confirmation deferred: running/boot partition mismatch\n");
    return false;
  }
  if (running->subtype == ESP_PARTITION_SUBTYPE_APP_FACTORY) {
    done_ = true; // A factory app has no OTA state to validate.
    return true;
  }
  esp_ota_img_states_t state = ESP_OTA_IMG_UNDEFINED;
  esp_err_t err = esp_ota_get_state_partition(running, &state);
  if (err != ESP_OK) {
    printf("[update] confirmation read failed: %d; retrying\n", int(err));
    return false;
  }
  if (state == ESP_OTA_IMG_VALID) {
    done_ = true;
    printf("[update] running image already confirmed at 0x%lx\n", (unsigned long)running->address);
    return true;
  }
  if (state != ESP_OTA_IMG_PENDING_VERIFY && state != ESP_OTA_IMG_NEW && state != ESP_OTA_IMG_UNDEFINED) {
    printf("[update] unexpected running image state: %d; not confirming\n", int(state));
    return false;
  }
  // NEW is possible with an older bootloader; don't leave a healthy image
  // unconfirmed just because that bootloader did not advance its state.
  err = esp_ota_mark_app_valid_cancel_rollback();
  if (err != ESP_OK) {
    printf("[update] confirmation write failed: %d; retrying\n", int(err));
    return false;
  }
  err = esp_ota_get_state_partition(running, &state);
  if (err != ESP_OK || state != ESP_OTA_IMG_VALID) {
    printf("[update] confirmation not persisted: error=%d state=%d; retrying\n", int(err), int(state));
    return false;
  }
  done_ = true;
  printf("[update] new version confirmed and read back at 0x%lx\n", (unsigned long)running->address);
  return true;
}
}
