#include "ring_light.h"
#include <Arduino.h>
#ifndef UI_SIM
#include <Preferences.h>
#endif

namespace ring_light {
namespace {
// Keep PWM at 20 kHz to reduce audible switching noise during dimming/mixing.
constexpr uint32_t PWM_HZ = 20000;
State current;
Animation animation;
Duty previous{0, 0};
uint32_t last_frame = 0;
bool available = false, saved = true, dirty = false;
uint32_t changed_ms = 0;
#ifndef UI_SIM
Preferences prefs;
bool prefs_open = false;
void stop_outputs() {
  ledcDetach(PIN_A);
  ledcDetach(PIN_B);
  pinMode(PIN_A, OUTPUT); digitalWrite(PIN_A, LOW);
  pinMode(PIN_B, OUTPUT); digitalWrite(PIN_B, LOW);
  available = false;
  current.on = false;
}
#endif
void apply() {
  if (!available) { current.on = false; return; }
#ifndef UI_SIM
  const Duty duty = render(current, animation, millis());
  bool ok = true;
  // Decrease first to keep the summed duty budget bounded during colour changes.
  if (duty.a < previous.a) ok = ledcWrite(PIN_A, duty.a) && ok;
  if (duty.b < previous.b) ok = ledcWrite(PIN_B, duty.b) && ok;
  if (ok && duty.a > previous.a) ok = ledcWrite(PIN_A, duty.a);
  if (ok && duty.b > previous.b) ok = ledcWrite(PIN_B, duty.b);
  previous = duty;
  if (!ok) { stop_outputs(); Serial.println("[ring] PWM failed; light disabled"); }
#endif
}
void remember() { dirty = true; saved = false; changed_ms = millis(); }
}

void begin() {
  current = State{}; // On/off is intentionally never restored.
  dirty = false; saved = true;
  animation = Animation{}; previous = {0, 0}; last_frame = millis();
#ifndef UI_SIM
  pinMode(PIN_A, OUTPUT); digitalWrite(PIN_A, LOW);
  pinMode(PIN_B, OUTPUT); digitalWrite(PIN_B, LOW);
  prefs_open = prefs.begin("ring_light", false);
  if (prefs_open) {
    const uint8_t b = prefs.getUChar("brightness", 50);
    current.brightness = b > 100 ? 100 : b;
    current.colour = valid_colour(prefs.getUChar("colour", 1));
    current.swap = prefs.getBool("swap", false);
    current.start_fade = prefs.getBool("start", false);
    current.pour_pulse = prefs.getBool("pour", false);
    current.pause_pulse = prefs.getBool("pause", false);
    current.finish_flash = prefs.getBool("finish", false);
    current.quiet = prefs.getBool("quiet", false);
  } else saved = false;
  const bool a = ledcAttach(PIN_A, PWM_HZ, 8);
  const bool b = ledcAttach(PIN_B, PWM_HZ, 8);
  available = a && b;
  if (available) available = ledcWrite(PIN_A, 0) && ledcWrite(PIN_B, 0);
  if (!available) stop_outputs();
#else
  available = true;
#endif
  apply();
}
void tick() {
  const uint32_t now = millis();
  if (animation.starting && uint32_t(now - animation.started) >= 2000) animation.starting = false;
  if (animation.finishing && uint32_t(now - animation.finished) >= 1600) animation.finishing = false;
  if (uint32_t(now - last_frame) >= 20) { last_frame = now; apply(); }
  if (!dirty || uint32_t(millis() - changed_ms) < 1500) return;
  dirty = false;
#ifndef UI_SIM
  saved = prefs_open;
  if (prefs_open) {
    const bool a = prefs.putUChar("brightness", current.brightness) == 1;
    const bool b = prefs.putUChar("colour", static_cast<uint8_t>(current.colour)) == 1;
    const bool c = prefs.putBool("swap", current.swap) == 1;
    const bool d = prefs.putBool("start", current.start_fade) == 1;
    const bool e = prefs.putBool("pour", current.pour_pulse) == 1;
    const bool f = prefs.putBool("pause", current.pause_pulse) == 1;
    const bool g = prefs.putBool("finish", current.finish_flash) == 1;
    const bool h = prefs.putBool("quiet", current.quiet) == 1;
    saved = a && b && c && d && e && f && g && h;
  }
  if (!saved) Serial.println("[ring] settings could not be saved");
#else
  saved = true;
#endif
}
const State &state() { return current; }
bool ready() { return available; }
bool settings_saved() { return saved; }
void set_on(bool value) {
  current.on = value && available;
  if (!current.on) { animation.starting = false; animation.finishing = false; }
  apply();
}
void set_brightness(int value) {
  const uint8_t b = value < 0 ? 0 : value > 100 ? 100 : value;
  if (current.brightness == b) return;
  current.brightness = b; apply(); remember();
}
void set_colour(Colour value) {
  const Colour c = valid_colour(static_cast<uint8_t>(value));
  if (current.colour == c) return;
  current.colour = c; apply(); remember();
}
void set_swap(bool value) {
  if (current.swap == value) return;
  current.swap = value; apply(); remember();
}
void set_option(Option option, bool value) {
  bool *setting = nullptr;
  switch (option) {
    case Option::StartFade: setting = &current.start_fade; break;
    case Option::PourPulse: setting = &current.pour_pulse; break;
    case Option::PausePulse: setting = &current.pause_pulse; break;
    case Option::FinishFlash: setting = &current.finish_flash; break;
    case Option::Quiet: setting = &current.quiet; break;
    case Option::Swap: set_swap(value); return;
  }
  if (!setting || *setting == value) return;
  *setting = value; apply(); remember();
}
void set_activity(Activity activity) {
  if (animation.activity == activity) return;
  animation.activity = activity; animation.activity_since = millis(); apply();
}
void start_brew() {
  animation = Animation{};
  animation.started = millis();
  animation.starting = current.on && current.start_fade;
  set_activity(Activity::Brewing); apply();
}
void finish_brew() {
  animation = Animation{};
  animation.finished = millis();
  animation.finishing = current.on && current.finish_flash;
  apply();
}
void cancel_brew() { animation = Animation{}; apply(); }
#ifdef UI_SIM
Duty sim_output() { return render(current, animation, millis()); }
#endif
} // namespace ring_light
