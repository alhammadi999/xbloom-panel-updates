#include "spotify_engine.h"
#if PANEL_SPOTIFY_TRIAL
#include <ArduinoJson.h>
#include <algorithm>
#include <stdio.h>
#include <string.h>

namespace spotify {
namespace {
template<size_t N> void copy(char (&out)[N], const char *in) {
  snprintf(out, N, "%s", in ? in : "");
}
bool due(uint32_t now, uint32_t deadline) { return int32_t(now - deadline) >= 0; }
}
std::string form_encode(const std::string &value) {
  static const char hex[] = "0123456789ABCDEF";
  std::string out;
  for (unsigned char c : value) {
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
        (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~') out += c;
    else { out += '%'; out += hex[c >> 4]; out += hex[c & 15]; }
  }
  return out;
}
bool valid_client(const std::string &s) {
  return s.size() == 32 && s.find_first_not_of("0123456789abcdefABCDEF") == std::string::npos;
}
bool valid_token(const std::string &s) {
  return !s.empty() && s.size() <= 2048 &&
    std::all_of(s.begin(), s.end(), [](unsigned char c) { return c >= 33 && c <= 126; });
}
void Engine::message(const char *text) { copy(state_.message, text); }
void Engine::restore(const std::string &client, const std::string &refresh) {
  client_ = valid_client(client) ? client : "";
  refresh_ = valid_token(refresh) && !client_.empty() ? refresh : "";
  access_.clear(); expires_ = next_poll_ = retry_at_ = 0;
  limited_ = have_player_ = false; state_ = State{};
  state_.linked = !refresh_.empty();
  message(state_.linked ? "Open Spotify on your phone and start a song." : "Connect your Spotify account.");
}
bool Engine::allowed(uint32_t now) {
  if (limited_ && !due(now, retry_at_)) return false;
  limited_ = false; return true;
}
void Engine::error(const Response &r, uint32_t now) {
  state_.controls = false;
  if (r.status == 429) {
    const unsigned seconds = std::max(1u, std::min(r.retry_after ? r.retry_after : 30u, 3600u));
    limited_ = true; retry_at_ = now + seconds * 1000u;
    message("Spotify asked us to wait. Retrying later.");
  } else if (r.status == 401) message("Spotify session expired. Reconnect your account.");
  else if (r.status == 403) message("Spotify denied control. Check Premium and app access.");
  else if (r.status == 404) message("Open Spotify on your phone and start a song.");
  else message("Cannot reach Spotify. Check Wi-Fi and try again.");
}
bool Engine::token(uint32_t now) {
  if (!allowed(now) || refresh_.empty()) return false;
  if (!access_.empty() && !due(now + 60000u, expires_)) return true;
  Response r = backend_.request(true, "POST", "/api/token", "",
    "grant_type=refresh_token&client_id=" + form_encode(client_) + "&refresh_token=" + form_encode(refresh_));
  if (r.status != 200) {
    if (r.status == 400 || r.status == 401) {
      access_.clear(); message("Spotify sign-in expired. Disconnect and link again.");
      state_.controls = false; limited_ = true; retry_at_ = now + 60000u;
    } else error(r, now);
    return false;
  }
  JsonDocument doc;
  if (deserializeJson(doc, r.body) || !doc["access_token"].is<const char *>() ||
      !valid_token(doc["access_token"].as<std::string>()) || !doc["expires_in"].is<unsigned>()) {
    message("Spotify returned an invalid sign-in response."); state_.controls = false; return false;
  }
  access_ = doc["access_token"].as<std::string>();
  expires_ = now + std::min(doc["expires_in"].as<unsigned>(), 86400u) * 1000u;
  if (doc["refresh_token"].is<const char *>()) {
    const std::string rotated = doc["refresh_token"].as<std::string>();
    if (!valid_token(rotated)) { message("Invalid Spotify refresh response."); return false; }
    if (rotated != refresh_) {
      refresh_ = rotated;
      if (!backend_.save(client_, refresh_)) {
        message("Spotify sign-in could not be saved. Link again.");
        state_.linked = false; access_.clear(); refresh_.clear(); return false;
      }
    }
  }
  return true;
}
bool Engine::link(const std::string &client, const std::string &refresh, uint32_t now) {
  if (!valid_client(client) || !valid_token(refresh)) { message("Invalid Spotify connection details."); return false; }
  restore(client, refresh);
  if (!token(now) || !backend_.save(client_, refresh_)) {
    state_.linked = false; access_.clear(); refresh_.clear();
    message("Could not save or verify Spotify. Try linking again."); return false;
  }
  state_.linked = true; message("Connected. Start a song on your phone."); next_poll_ = now; return true;
}
void Engine::forget() {
  const bool ok = backend_.save("", "");
  if (!ok) { message("Could not remove saved sign-in. Try disconnecting again."); return; }
  restore("", "");
}
Response Engine::api(const char *method, const std::string &path, uint32_t now) {
  if (!token(now)) return {};
  Response r = backend_.request(false, method, path, access_, "");
  if (r.status == 401) {
    access_.clear();
    if (token(now)) r = backend_.request(false, method, path, access_, "");
  }
  if (r.status != 200 && r.status != 204) error(r, now);
  return r;
}
void Engine::poll(uint32_t now, bool visible) {
  if (!visible || !state_.linked || !allowed(now) || !due(now, next_poll_)) return;
  next_poll_ = now + 4000;
  Response r = api("GET", "/v1/me/player", now);
  if (r.status == 204) {
    state_.controls = state_.playing = false; state_.title[0] = state_.artist[0] = state_.device_id[0] = 0;
    state_.device[0] = 0; have_player_ = false; message("Open Spotify on your phone and start a song."); return;
  }
  if (r.status != 200) return;
  JsonDocument filter, doc;
  filter["is_playing"] = true;
  filter["device"]["id"] = filter["device"]["name"] = filter["device"]["is_restricted"] = true;
  filter["item"]["name"] = true; filter["item"]["artists"][0]["name"] = true;
  filter["item"]["show"]["name"] = true; filter["actions"]["disallows"] = true;
  if (deserializeJson(doc, r.body, DeserializationOption::Filter(filter)) || !doc["is_playing"].is<bool>()) {
    state_.controls = false; message("Could not read Spotify playback."); return;
  }
  copy(state_.title, doc["item"]["name"] | "Nothing playing");
  copy(state_.artist, doc["item"]["artists"][0]["name"] | (doc["item"]["show"]["name"] | ""));
  copy(state_.device, doc["device"]["name"] | "Phone");
  copy(state_.device_id, doc["device"]["id"] | "");
  state_.playing = doc["is_playing"] | false;
  state_.controls = state_.device_id[0] && !(doc["device"]["is_restricted"] | true);
  auto d = doc["actions"]["disallows"];
  state_.can_play = state_.controls && !(d["resuming"] | false);
  state_.can_pause = state_.controls && !(d["pausing"] | false);
  state_.can_next = state_.controls && !(d["skipping_next"] | false);
  state_.can_previous = state_.controls && !(d["skipping_prev"] | false);
  have_player_ = true; last_player_ = now;
  message(state_.controls ? "Audio plays on your phone's connected speaker." : "This Spotify device does not allow remote control.");
}
void Engine::control(Command cmd, const std::string &expected_device, uint32_t now) {
  if (!allowed(now) || !state_.linked || !state_.controls || !have_player_ ||
      uint32_t(now - last_player_) > 15000 || expected_device != state_.device_id) return;
  const char *path = nullptr, *method = "PUT";
  if (cmd == Command::Play && state_.can_play) path = "play";
  if (cmd == Command::Pause && state_.can_pause) path = "pause";
  if (cmd == Command::Next && state_.can_next) { path = "next"; method = "POST"; }
  if (cmd == Command::Previous && state_.can_previous) { path = "previous"; method = "POST"; }
  if (!path) return;
  Response r = api(method, std::string("/v1/me/player/") + path + "?device_id=" + form_encode(expected_device), now);
  // Do not replay a failed/uncertain skip; let the user decide whether to retry.
  if (r.status == 204 || r.status == 200) {
    if (cmd == Command::Play) state_.playing = true;
    if (cmd == Command::Pause) state_.playing = false;
    next_poll_ = now; message("Command sent to Spotify.");
  }
}
}
#endif
