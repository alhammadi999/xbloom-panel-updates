#include "spotify_remote.h"
#if PANEL_SPOTIFY_TRIAL && !defined(UI_SIM)
#include "spotify_engine.h"
#include "spotify_login.h"
#include "spotify_online_login.h"
#include "panel_net.h"
#include <mbedtls/sha256.h>
#include <mbedtls/base64.h>
#include <Arduino.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#include <esp_crt_bundle.h>
#include <esp_http_client.h>
#include <esp_random.h>
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>
#include <algorithm>
#include <string.h>

namespace spotify {
namespace {
Preferences prefs;
SemaphoreHandle_t mutex;
State view;
bool enabled = false, visible = false, save_enabled = false, forget_requested = false;
uint32_t generation = 0, pairing_started = 0, queued_at = 0;
unsigned pairing_failures = 0;
Command queued = Command::None;
std::string queued_device, pending_client, pending_refresh;
bool pending_link = false;
LoginSession login;
OnlineLogin online_login;
char login_message[160]{};
std::string pending_code, pending_verifier;
int queued_value = -1;
std::string random_hex(size_t bytes) {
  static const char hex[] = "0123456789abcdef";
  std::string result;
  for (size_t i=0; i<bytes; ++i) { auto b=esp_random() & 255; result += hex[b>>4]; result += hex[b&15]; }
  return result;
}
std::string challenge(const std::string &verifier) {
  unsigned char hash[32], encoded[48]; size_t len=0;
  if (mbedtls_sha256((const unsigned char *)verifier.data(), verifier.size(), hash, 0)) return "";
  if (mbedtls_base64_encode(encoded, sizeof encoded, &len, hash, sizeof hash)) return "";
  std::string s((char *)encoded, len);
  std::replace(s.begin(), s.end(), '+', '-'); std::replace(s.begin(), s.end(), '/', '_');
  while (!s.empty() && s.back()=='=') s.pop_back(); return s;
}
struct Lock { Lock() { xSemaphoreTake(mutex, portMAX_DELAY); } ~Lock() { xSemaphoreGive(mutex); } };
class EspBackend : public Backend {
 public:
  bool save(const std::string &client, const std::string &refresh) override {
    if (client.empty()) {
      if (!prefs.isKey("account")) return true;
      return prefs.remove("account");
    }
    JsonDocument doc; doc["client"] = client; doc["refresh"] = refresh;
    std::string json; serializeJson(doc, json);
    return prefs.putString("account", json.c_str()) == json.size();
  }
  Response request(bool accounts, const char *method, const std::string &path,
                   const std::string &token, const std::string &body) override {
    return send(std::string(accounts ? "https://accounts.spotify.com" : "https://api.spotify.com") + path, accounts, method, token, body);
  }
  Response relay(const char *method, const std::string &path, const std::string &secret, const std::string &body) {
    return send(std::string(RELAY_ORIGIN)+path, false, method, secret, body);
  }
  Response send(const std::string &url, bool accounts, const char *method, const std::string &token, const std::string &body) {
    Response response;
    esp_http_client_config_t cfg{};
    cfg.url = url.c_str(); cfg.timeout_ms = 4500; cfg.crt_bundle_attach = esp_crt_bundle_attach;
    cfg.buffer_size = 2048; cfg.buffer_size_tx = 3072;
    cfg.disable_auto_redirect = true;
    cfg.method = !strcmp(method, "GET") ? HTTP_METHOD_GET : !strcmp(method, "POST") ? HTTP_METHOD_POST : HTTP_METHOD_PUT;
    cfg.user_data = &response;
    cfg.event_handler = [](esp_http_client_event_t *event) -> esp_err_t {
      if (event->event_id == HTTP_EVENT_ON_HEADER && event->header_key && !strcasecmp(event->header_key, "Retry-After"))
        static_cast<Response *>(event->user_data)->retry_after = strtoul(event->header_value, nullptr, 10);
      return ESP_OK;
    };
    auto http = esp_http_client_init(&cfg);
    if (!http) return response;
    const std::string auth = "Bearer " + token;
    if (!accounts && !token.empty()) esp_http_client_set_header(http, "Authorization", auth.c_str());
    esp_http_client_set_header(http, "Content-Type", accounts ? "application/x-www-form-urlencoded" : "application/json");
    if (esp_http_client_open(http, body.size()) == ESP_OK) {
      bool sent = body.empty() || esp_http_client_write(http, body.data(), body.size()) == int(body.size());
      if (sent && esp_http_client_fetch_headers(http) >= 0) {
        response.status = esp_http_client_get_status_code(http);
        char buffer[512]; int n;
        const uint32_t started = millis();
        while ((n = esp_http_client_read(http, buffer, sizeof buffer)) > 0) {
          if (response.body.size() + n > 16384 || uint32_t(millis() - started) > 6000) {
            response.status = 0; response.body.clear(); break;
          }
          response.body.append(buffer, n);
        }
        if (n < 0) response.status = 0;
      }
    }
    esp_http_client_close(http); esp_http_client_cleanup(http);
    return response;
  }
} backend;
Engine engine(backend);
}
void begin() {
  mutex = xSemaphoreCreateMutex(); prefs.begin("spotify_trial", false);
  enabled = prefs.getBool("enabled", false);
  JsonDocument doc;
  deserializeJson(doc, prefs.getString("account", "{}"));
  engine.restore(doc["client"] | "", doc["refresh"] | "");
  view = engine.state(); view.enabled = enabled;
}
State state() { Lock lock; return view; }
void set_enabled(bool on) {
  Lock lock; enabled = on; view.enabled = on; save_enabled = true; ++generation;
  queued = Command::None; view.controls = false;
  if (!on) { online_login.clear(); login_message[0]=0; login.clear(); view.login_url[0] = 0; pending_code.clear(); pending_verifier.clear(); view.pairing_code[0] = 0; pending_link = false; pending_refresh.clear(); pending_client.clear(); }
}
void set_visible(bool value) { Lock lock; visible = value; }
void start_pairing() {
  Lock lock;
  if (!enabled || view.linked || view.busy) return;
  ++generation; login.clear(); view.pairing_code[0]=view.login_url[0]=0;
  const auto verifier=random_hex(32);
  online_login.start(random_hex(32),random_hex(32),verifier,challenge(verifier),millis());
  snprintf(login_message,sizeof login_message,"Preparing your secure login QR...");
  view.busy=true;
}
void disconnect() {
  Lock lock; forget_requested = true; ++generation; queued = Command::None;
  view.controls = view.linked = false; view.pairing_code[0] = 0;
  pending_link = false; pending_client.clear(); pending_refresh.clear();
  online_login.clear(); login_message[0]=0; login.clear(); view.login_url[0] = 0; pending_code.clear(); pending_verifier.clear();
}
bool command(Command cmd, int value) {
  Lock lock;
  if (!enabled || !visible || !view.linked || !view.controls || view.busy || queued != Command::None) return false;
  if (cmd == Command::Volume && (!view.can_volume || value < 0 || value > 100)) return false;
  queued_value = value; queued = cmd; queued_device = view.device_id; queued_at = millis(); view.busy = true; return true;
}
std::string authorize_url(const char *state) {
  Lock lock;
  if (!enabled || view.linked || pending_link) return "";
  return login.authorize(state, millis());
}
bool accept_code(const char *state, const char *code) {
  Lock lock;
  if (!enabled || view.linked || pending_link || !valid_token(code)) return false;
  auto verifier = login.consume(state, millis());
  if (verifier.empty()) return false;
  pending_code = code; pending_verifier = verifier; pending_link = true;
  view.login_url[0] = view.pairing_code[0] = 0; view.busy = true; ++generation;
  return true;
}
bool accept_link(const char *pin, const char *client, const char *refresh) {
  Lock lock;
  if (!enabled || view.linked || !view.pairing_code[0] || uint32_t(millis() - pairing_started) > 300000 ||
      pairing_failures >= 5 || pending_link) return false;
  if (strcmp(pin, view.pairing_code)) { ++pairing_failures; return false; }
  if (!valid_client(client) || !valid_token(refresh)) return false;
  login.clear(); view.login_url[0] = 0;
  pending_client = client; pending_refresh = refresh; pending_link = true;
  view.pairing_code[0] = 0; view.busy = true; ++generation;
  return true;
}
void tick(bool network_allowed) {
  bool on, active, save_flag, forget, link;
  Command cmd; uint32_t gen, requested_at;
  std::string client, refresh, device, code, verifier; int value;
  {
    Lock lock;
    if (view.pairing_code[0] && uint32_t(millis() - pairing_started) > 300000) { view.pairing_code[0] = view.login_url[0] = 0; login.clear(); }
    if(!online_login.id.empty() && !online_login.active(millis())){online_login.clear();view.login_url[0]=0;snprintf(login_message,sizeof login_message,"Login expired. Tap Login with Spotify for a new QR.");}
    on = enabled; active = visible; gen = generation;
    save_flag = save_enabled; save_enabled = false;
    forget = forget_requested; forget_requested = false;
    // Keep a link job until the network is available. Never queue playback offline.
    link = pending_link && network_allowed && on;
    if (link) { client.swap(pending_client); refresh.swap(pending_refresh); code.swap(pending_code); verifier.swap(pending_verifier); pending_link = false; }
    value = queued_value; cmd = queued; device.swap(queued_device); requested_at = queued_at; queued = Command::None;
  }
  if (save_flag) prefs.putBool("enabled", on);
  if (forget) engine.forget();
  if (network_allowed && on) {
    if (link) { if (!code.empty()) engine.exchange_code(code, verifier, millis()); else engine.link(client, refresh, millis()); }
    OnlineLogin job;
    { Lock lock; if (generation==gen && online_login.due(millis())) { job=online_login; online_login.next=millis()+3000; } }
    if (!job.id.empty()) {
      Response response;
      if (!job.registered) {
        unsigned char hash[32]; std::string poll_hash;
        if (!mbedtls_sha256((const unsigned char *)job.secret.data(),job.secret.size(),hash,0)) {
          const char hex[]="0123456789abcdef";for(auto b:hash){poll_hash+=hex[b>>4];poll_hash+=hex[b&15];}
          JsonDocument request; request["id"]=job.id;request["poll_hash"]=poll_hash;request["challenge"]=job.challenge;
          std::string payload;serializeJson(request,payload);response=backend.relay("POST","/api/pair","",payload);
        }
        Lock lock;
        if(generation==gen && online_login.id==job.id) {
          if(response.status==200||response.status==201){online_login.registered=true;snprintf(view.login_url,sizeof view.login_url,"%s",online_login.url().c_str());snprintf(login_message,sizeof login_message,"Scan the QR with your phone. Any internet connection works.");}
          else {online_login.next=millis()+(response.status==429?60000:8000);snprintf(login_message,sizeof login_message,"Cannot prepare login yet. Check internet; retrying...");}
        }
      } else {
        response=backend.relay("GET","/api/poll?id="+job.id,job.secret,"");
        JsonDocument reply;
        const bool ready=response.status==200 && !deserializeJson(reply,response.body) && reply["status"]=="ready" &&
          reply["code"].is<const char *>() && valid_token(reply["code"].as<std::string>()) &&
          reply["state"].is<const char *>() && job.matches(reply["state"].as<std::string>(),millis());
        bool use_code=false;
        { Lock lock;
          if(generation==gen && online_login.id==job.id) {
            if(ready){use_code=true;online_login.clear();view.login_url[0]=0;login_message[0]=0;view.busy=true;}
            else if(response.status==410){online_login.clear();view.login_url[0]=0;snprintf(login_message,sizeof login_message,"Login expired. Tap Login with Spotify for a new QR.");}
            else if(response.status==429)online_login.next=millis()+5000;
          }
        }
        if(use_code){
          engine.exchange_code(reply["code"].as<std::string>(),job.verifier,millis());
          backend.relay("POST","/api/ack?id="+job.id,job.secret,"");
        }
      }
    }
    if (active && cmd != Command::None && uint32_t(millis() - requested_at) <= 5000) {
      bool still_current; { Lock lock; still_current = generation == gen && enabled; }
      if (still_current) engine.control(cmd, device, millis(), value);
    }
    engine.poll(millis(), active);
  }
  {
    Lock lock;
    if (generation != gen) return;
    char url[192]; memcpy(url, view.login_url, sizeof url);
    char code[7]; memcpy(code, view.pairing_code, sizeof code);
    view = engine.state(); memcpy(view.pairing_code, code, sizeof code);
    memcpy(view.login_url, url, sizeof url);
    view.enabled = enabled; view.busy = pending_link || (!online_login.id.empty() && !online_login.registered);
    if(enabled && login_message[0] && !view.linked)snprintf(view.message,sizeof view.message,"%s",login_message);
    if (!enabled) { view.controls = false; snprintf(view.message, sizeof view.message, "Trial is off. Coffee controls work as usual."); }
    else if (!network_allowed) { view.controls = false; snprintf(view.message, sizeof view.message, "Waiting for Wi-Fi or other panel activity to finish."); }
  }
}
}
#endif
