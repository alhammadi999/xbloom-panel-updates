#include "spotify_remote.h"
#if PANEL_SPOTIFY_TRIAL && !defined(UI_SIM)
#include "spotify_engine.h"
#include <Arduino.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#include <esp_crt_bundle.h>
#include <esp_http_client.h>
#include <esp_random.h>
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>
#include <algorithm>
#include <string.h>

namespace spotify {
namespace {
Preferences prefs;
SemaphoreHandle_t mutex;
State view;
bool enabled = false, visible = false, save_enabled = false, forget_requested = false;
uint32_t generation = 0, pairing_started = 0, queued_at = 0;
unsigned pairing_failures = 0;
Command queued = Command::None;
std::string queued_device, pending_client, pending_refresh;
bool pending_link = false;
struct Lock { Lock() { xSemaphoreTake(mutex, portMAX_DELAY); } ~Lock() { xSemaphoreGive(mutex); } };
class EspBackend : public Backend {
 public:
  bool save(const std::string &client, const std::string &refresh) override {
    if (client.empty()) {
      if (!prefs.isKey("account")) return true;
      return prefs.remove("account");
    }
    JsonDocument doc; doc["client"] = client; doc["refresh"] = refresh;
    std::string json; serializeJson(doc, json);
    return prefs.putString("account", json.c_str()) == json.size();
  }
  Response request(bool accounts, const char *method, const std::string &path,
                   const std::string &token, const std::string &body) override {
    Response response;
    const std::string url = std::string(accounts ? "https://accounts.spotify.com" : "https://api.spotify.com") + path;
    esp_http_client_config_t cfg{};
    cfg.url = url.c_str(); cfg.timeout_ms = 4500; cfg.crt_bundle_attach = esp_crt_bundle_attach;
    cfg.buffer_size = 2048; cfg.buffer_size_tx = 3072;
    cfg.disable_auto_redirect = true;
    cfg.method = !strcmp(method, "GET") ? HTTP_METHOD_GET : !strcmp(method, "POST") ? HTTP_METHOD_POST : HTTP_METHOD_PUT;
    cfg.user_data = &response;
    cfg.event_handler = [](esp_http_client_event_t *event) -> esp_err_t {
      if (event->event_id == HTTP_EVENT_ON_HEADER && event->header_key && !strcasecmp(event->header_key, "Retry-After"))
        static_cast<Response *>(event->user_data)->retry_after = strtoul(event->header_value, nullptr, 10);
      return ESP_OK;
    };
    auto http = esp_http_client_init(&cfg);
    if (!http) return response;
    const std::string auth = "Bearer " + token;
    if (!accounts) esp_http_client_set_header(http, "Authorization", auth.c_str());
    esp_http_client_set_header(http, "Content-Type", accounts ? "application/x-www-form-urlencoded" : "application/json");
    if (esp_http_client_open(http, body.size()) == ESP_OK) {
      bool sent = body.empty() || esp_http_client_write(http, body.data(), body.size()) == int(body.size());
      if (sent && esp_http_client_fetch_headers(http) >= 0) {
        response.status = esp_http_client_get_status_code(http);
        char buffer[512]; int n;
        const uint32_t started = millis();
        while ((n = esp_http_client_read(http, buffer, sizeof buffer)) > 0) {
          if (response.body.size() + n > 16384 || uint32_t(millis() - started) > 6000) {
            response.status = 0; response.body.clear(); break;
          }
          response.body.append(buffer, n);
        }
        if (n < 0) response.status = 0;
      }
    }
    esp_http_client_close(http); esp_http_client_cleanup(http);
    return response;
  }
} backend;
Engine engine(backend);
}
void begin() {
  mutex = xSemaphoreCreateMutex(); prefs.begin("spotify_trial", false);
  enabled = prefs.getBool("enabled", false);
  JsonDocument doc;
  deserializeJson(doc, prefs.getString("account", "{}"));
  engine.restore(doc["client"] | "", doc["refresh"] | "");
  view = engine.state(); view.enabled = enabled;
}
State state() { Lock lock; return view; }
void set_enabled(bool on) {
  Lock lock; enabled = on; view.enabled = on; save_enabled = true; ++generation;
  queued = Command::None; view.controls = false;
  if (!on) { view.pairing_code[0] = 0; pending_link = false; pending_refresh.clear(); pending_client.clear(); }
}
void set_visible(bool value) { Lock lock; visible = value; }
void start_pairing() {
  Lock lock;
  if (!enabled || view.linked) return;
  snprintf(view.pairing_code, sizeof view.pairing_code, "%06lu", (unsigned long)(esp_random() % 900000u + 100000u));
  pairing_started = millis(); pairing_failures = 0;
}
void disconnect() {
  Lock lock; forget_requested = true; ++generation; queued = Command::None;
  view.controls = view.linked = false; view.pairing_code[0] = 0;
  pending_link = false; pending_client.clear(); pending_refresh.clear();
}
bool command(Command cmd) {
  Lock lock;
  if (!enabled || !visible || !view.linked || !view.controls || view.busy || queued != Command::None) return false;
  queued = cmd; queued_device = view.device_id; queued_at = millis(); view.busy = true; return true;
}
bool accept_link(const char *pin, const char *client, const char *refresh) {
  Lock lock;
  if (!enabled || view.linked || !view.pairing_code[0] || uint32_t(millis() - pairing_started) > 300000 ||
      pairing_failures >= 5 || pending_link) return false;
  if (strcmp(pin, view.pairing_code)) { ++pairing_failures; return false; }
  if (!valid_client(client) || !valid_token(refresh)) return false;
  pending_client = client; pending_refresh = refresh; pending_link = true;
  view.pairing_code[0] = 0; view.busy = true; ++generation;
  return true;
}
void tick(bool network_allowed) {
  bool on, active, save_flag, forget, link;
  Command cmd; uint32_t gen, requested_at;
  std::string client, refresh, device;
  {
    Lock lock;
    if (view.pairing_code[0] && uint32_t(millis() - pairing_started) > 300000) view.pairing_code[0] = 0;
    on = enabled; active = visible; gen = generation;
    save_flag = save_enabled; save_enabled = false;
    forget = forget_requested; forget_requested = false;
    // Keep a link job until the network is available. Never queue playback offline.
    link = pending_link && network_allowed && on;
    if (link) { client.swap(pending_client); refresh.swap(pending_refresh); pending_link = false; }
    cmd = queued; device.swap(queued_device); requested_at = queued_at; queued = Command::None;
  }
  if (save_flag) prefs.putBool("enabled", on);
  if (forget) engine.forget();
  if (network_allowed && on) {
    if (link) engine.link(client, refresh, millis());
    if (active && cmd != Command::None && uint32_t(millis() - requested_at) <= 5000) {
      bool still_current; { Lock lock; still_current = generation == gen && enabled; }
      if (still_current) engine.control(cmd, device, millis());
    }
    engine.poll(millis(), active);
  }
  {
    Lock lock;
    if (generation != gen) return;
    char code[7]; memcpy(code, view.pairing_code, sizeof code);
    view = engine.state(); memcpy(view.pairing_code, code, sizeof code);
    view.enabled = enabled; view.busy = pending_link;
    if (!enabled) { view.controls = false; snprintf(view.message, sizeof view.message, "Trial is off. Coffee controls work as usual."); }
    else if (!network_allowed) { view.controls = false; snprintf(view.message, sizeof view.message, "Waiting for Wi-Fi or other panel activity to finish."); }
  }
}
}
#endif
