// Included inside ui.cpp after the common settings widgets.
void confirm(const char *, const char *, const char *, void (*)());
void set_unit(int u, bool send);
lv_obj_t *machine_page, *machine_status, *machine_inputs[machine::Count];
machine::Settings displayed_settings;
const char *const machine_labels[] = {"Scale unit", "Temperature unit", "Water source", "Pour radius", "Vibration strength"};
const char *const machine_options[] = {"ml\ng\noz", "Fahrenheit\nCelsius", "Tank\nDirect line",
  "-2 steps\n-1 step\nFactory radius\n+1 step\n+2 steps", "1 (lowest)\n2\n3\n4\n5\n6 (highest)"};
int32_t machine_request = 0;
bool machine_waiting = false;
uint32_t machine_started = 0;
int chosen_field = -1, chosen_value = -1;

int option_value(int field, int index) {
  if (field == machine::Radius) return displayed_settings.radius_base + (index - 2) * 80;
  if (field == machine::Vibration) return 1000 + index * 100;
  return index;
}
void paint_machine_fields() {
  for (int i = 0; i < machine::Count; ++i) {
    int value = displayed_settings.value[i];
    lv_obj_t *input = machine_inputs[i];
    bool known = machine::allowed(displayed_settings, i, value);
    if (known) {
      int index = i == machine::Radius ? (value - displayed_settings.radius_base) / 80 + 2 :
                  i == machine::Vibration ? (value - 1000) / 100 : value;
      lv_dropdown_set_selected(input, index);
    }
    const char *missing = "Unavailable";
    if (i == machine::Radius || i == machine::Vibration) {
      const auto &reply = i == machine::Radius ? displayed_settings.radius_reply : displayed_settings.vibration_reply;
      missing = !reply.seen ? "No reply" :
        reply.type != 7 || reply.marker != 0xc1 ? "Unknown reply" :
        i == machine::Radius && displayed_settings.radius_base < 0 ? "No baseline" : "Unknown value";
    }
    lv_dropdown_set_text(input, known ? nullptr : machine_waiting ? "Reading..." : missing);
    if (known && !machine_waiting && link == LinkState::Connected) lv_obj_remove_state(input, LV_STATE_DISABLED);
    else lv_obj_add_state(input, LV_STATE_DISABLED);
  }
}
void request_machine_settings(bool save) {
  if (machine_waiting) return;
  if (link != LinkState::Connected || ui::busy()) {
    set_text(machine_status, link != LinkState::Connected ? "Connect the Studio, then tap Refresh." : "Finish the active task, then refresh.");
    return;
  }
  BleCmd cmd;
  cmd.type = save ? BleCmdType::MachineWrite : BleCmdType::MachineRead;
  cmd.request_id = ++machine_request;
  cmd.queued_at = millis();
  if (save) {
    if (chosen_field < 0 || !machine::allowed(displayed_settings, chosen_field, chosen_value)) return;
    cmd.a = chosen_field;
    cmd.b = chosen_value;
    cmd.x = displayed_settings.value[chosen_field];
  } else displayed_settings = {};
  machine_waiting = ble_link::post(cmd);
  machine_started = millis();
  set_text(machine_status, !machine_waiting ? "Queue busy. Tap Refresh." :
           save ? "Saving and checking the Studio..." : "Reading from the Studio...");
  paint_machine_fields();
}
void machine_choice(lv_event_t *e) {
  if (machine_waiting || link != LinkState::Connected) return;
  auto *input = (lv_obj_t *)lv_event_get_target(e);
  for (int i = 0; i < machine::Count; ++i) {
    if (input != machine_inputs[i]) continue;
    chosen_field = i;
    chosen_value = option_value(i, lv_dropdown_get_selected(input));
    char label[48], body[160];
    lv_dropdown_get_selected_str(input, label, sizeof label);
    paint_machine_fields(); // Keep the confirmed value until readback.
    if (chosen_value == displayed_settings.value[i]) return;
    snprintf(body, sizeof body, "%s: %s.%s", machine_labels[i], label,
             i == machine::Water && chosen_value == 1 ? " Connect the water line first." : "");
    confirm("Apply to Studio?", body, "Apply", [] { request_machine_settings(true); });
    return;
  }
}
void open_machine_settings(lv_event_t *) {
  load(machine_page, Anim::PushLeft);
  if (machine_waiting) return;
  displayed_settings = {};
  paint_machine_fields();
  request_machine_settings(false);
}
void build_machine_settings() {
  machine_page = new_screen(BG);
  sub_header(machine_page, "Machine settings", back_to_settings);
  pill(machine_page, W-M-142, SB+4, 142, 46, "Refresh", SURFACE, TEXT, [](lv_event_t *) { request_machine_settings(false); });
  lv_obj_t *card = section(machine_page, "XBLOOM STUDIO", M, 96, W-2*M, machine::Count, 54);
  for (int i = 0; i < machine::Count; ++i) {
    lv_obj_t *line = row(card, i, 54, machine_labels[i], nullptr, nullptr);
    machine_inputs[i] = dropdown(line, machine_options[i], machine_choice);
    lv_obj_set_width(machine_inputs[i], 186);
  }
  machine_status = text(machine_page, "", &inter_16, hex(MUTED));
  lv_obj_set_pos(machine_status, M+4, 412);
  lv_obj_set_width(machine_status, W-2*M-8);
  paint_machine_fields();
}
void machine_reply(const UiEvent &e) {
  if (e.i != machine_request || !machine_waiting || link != LinkState::Connected) return;
  machine_waiting = false;
  displayed_settings = e.settings;
  paint_machine_fields();
  if (displayed_settings.value[machine::Weight] >= 0)
    set_unit((displayed_settings.value[machine::Weight] + 2) % 3, false);
  set_text(machine_status, e.ok ? "Values read from your Studio." : e.msg);
  if (!e.ok && !strncmp(e.msg, "Partial settings.", 17)) {
    char base[24], radius[48], vibration[48], details[160];
    auto describe = [](const machine::AdvancedReply &r, char *out, size_t size) {
      if (!r.seen) snprintf(out, size, "no reply");
      else if (r.type != 7 || r.marker != 0xc1) snprintf(out, size, "%lu [type %u/%u]", (unsigned long)r.raw, r.type, r.marker);
      else snprintf(out, size, "%lu", (unsigned long)r.raw);
    };
    if (displayed_settings.radius_base_seen) snprintf(base,sizeof base,"%lu",(unsigned long)displayed_settings.radius_base_raw);
    else snprintf(base,sizeof base,"not reported");
    describe(displayed_settings.radius_reply, radius, sizeof radius);
    describe(displayed_settings.vibration_reply, vibration, sizeof vibration);
    snprintf(details,sizeof details,"Read details - Radius: %s; base: %s; vibration: %s",radius,base,vibration);
    set_text(machine_status, details);
  }
}
void clear_machine_read(const char *status) {
  ++machine_request;
  machine_waiting = false;
  chosen_field = -1;
  displayed_settings = {};
  if (machine_page) {
    paint_machine_fields();
    set_text(machine_status, status);
  }
}
