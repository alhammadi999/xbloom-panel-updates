// Included inside ui.cpp's private namespace, after its shared UI helpers.
lv_obj_t *scr_ring_light, *st_ring_val, *rl_power, *rl_slider, *rl_value;
lv_obj_t *rl_colours[3], *rl_swap, *rl_note, *rl_effects_value;
lv_obj_t *scr_ring_behaviour, *rl_options[5];

void refresh_ring_light() {
  const auto &s = ring_light::state();
  if (st_ring_val) set_text(st_ring_val, s.on ? "On" : "Off");
  if (!scr_ring_light) return;
  if (s.on) lv_obj_add_state(rl_power, LV_STATE_CHECKED);
  else lv_obj_remove_state(rl_power, LV_STATE_CHECKED);
  if (ring_light::ready()) lv_obj_remove_state(rl_power, LV_STATE_DISABLED);
  else lv_obj_add_state(rl_power, LV_STATE_DISABLED);
  lv_slider_set_value(rl_slider, s.brightness, LV_ANIM_OFF);
  char value[8];
  snprintf(value, sizeof value, "%u%%", unsigned(s.brightness));
  set_text(rl_value, value);
  for (int i = 0; i < 3; ++i) {
    const bool selected = i == int(s.colour);
    lv_obj_set_style_bg_color(rl_colours[i], hex(selected ? TEXT : 0x1C1C1E), 0);
    set_text_color(lv_obj_get_child(rl_colours[i], 0), hex(selected ? BG : TEXT), 0);
  }
  if (s.swap) lv_obj_add_state(rl_swap, LV_STATE_CHECKED);
  else lv_obj_remove_state(rl_swap, LV_STATE_CHECKED);
  const bool options[] = {s.start_fade, s.pour_pulse, s.pause_pulse, s.finish_flash, s.quiet};
  int count = 0;
  for (int i = 0; i < 5; ++i) {
    if (options[i]) lv_obj_add_state(rl_options[i], LV_STATE_CHECKED);
    else lv_obj_remove_state(rl_options[i], LV_STATE_CHECKED);
    if (i < 4 && options[i]) ++count;
  }
  char effects[24];
  snprintf(effects, sizeof effects, "%d selected", count);
  set_text(rl_effects_value, s.quiet ? "Quiet mode" : count ? effects : "Steady");
  set_text(rl_note, !ring_light::ready() ? "Light unavailable. PWM could not start."
                   : !ring_light::settings_saved() ? "Settings not saved yet."
                   : s.quiet ? "Quiet mode: cream, up to 10% brightness. Effects paused."
                   : "Starts off after restart. Colour and brightness are saved.");
}

void open_ring_light(lv_event_t *) {
  refresh_ring_light();
  load(scr_ring_light, Anim::PushLeft);
}

void open_ring_behaviour(lv_event_t *) {
  refresh_ring_light(); load(scr_ring_behaviour, Anim::PushLeft);
}
void build_ring_behaviour() {
  scr_ring_behaviour = new_screen(BG);
  sub_header(scr_ring_behaviour, "Light behaviour", [](lv_event_t *) {
    refresh_ring_light(); load(scr_ring_light, Anim::PopRight);
  });
  const char *labels[] = {"Fade in at brew start", "Pulse while pouring", "Slow pulse when paused",
                          "Two flashes when finished", "Quiet mode (up to 10%)"};
  lv_obj_t *card = box(scr_ring_behaviour, M, 96, W - 2 * M, 260, 0x1C1C1E, R_SM);
  for (int i = 0; i < 5; ++i) {
    rl_options[i] = toggle(row(card, i, 52, labels[i], nullptr, nullptr), false, [](lv_event_t *e) {
      auto *target = (lv_obj_t *)lv_event_get_target(e);
      for (int j = 0; j < 5; ++j) if (target == rl_options[j]) {
        ring_light::set_option(static_cast<ring_light::Option>(j), lv_obj_has_state(target, LV_STATE_CHECKED));
        break;
      }
      refresh_ring_light();
    });
  }
  lv_obj_t *wiring = box(scr_ring_behaviour, M, 376, W - 2 * M, 52, 0x1C1C1E, R_SM);
  rl_swap = toggle(row(wiring, 0, 52, "Swap warm / cool", nullptr, nullptr), false, [](lv_event_t *e) {
    ring_light::set_swap(lv_obj_has_state((lv_obj_t *)lv_event_get_target(e), LV_STATE_CHECKED));
    refresh_ring_light();
  });
  lv_obj_set_pos(text(scr_ring_behaviour, "Quiet mode overrides effects. Power must be on.", &inter_14, hex(MUTED)), M + 4, 444);
}

void build_ring_light() {
  scr_ring_light = new_screen(BG);
  sub_header(scr_ring_light, "Ring light", back_to_settings);
  const int width = W - 2 * M;
  lv_obj_t *power = box(scr_ring_light, M, 96, width, 56, 0x1C1C1E, R_SM);
  lv_obj_t *r = row(power, 0, 56, "Power", nullptr, nullptr);
  rl_power = toggle(r, false, [](lv_event_t *e) {
    ring_light::set_on(lv_obj_has_state((lv_obj_t *)lv_event_get_target(e), LV_STATE_CHECKED));
    refresh_ring_light();
  });

  lv_obj_t *bright = box(scr_ring_light, M, 168, width, 100, 0x1C1C1E, R_SM);
  lv_obj_set_pos(text(bright, "Brightness", &inter_20, hex(TEXT)), 16, 12);
  rl_value = text(bright, "50%", &inter_20b, hex(TEXT));
  lv_obj_align(rl_value, LV_ALIGN_TOP_RIGHT, -16, 12);
  rl_slider = lv_slider_create(bright);
  lv_obj_set_pos(rl_slider, 24, 66);
  lv_obj_set_size(rl_slider, width - 48, 8);
  lv_slider_set_range(rl_slider, 0, 100);
  lv_obj_set_ext_click_area(rl_slider, 18);
  lv_obj_set_style_bg_color(rl_slider, hex(0x39393D), LV_PART_MAIN);
  lv_obj_set_style_bg_color(rl_slider, hex(TEXT), LV_PART_INDICATOR);
  lv_obj_set_style_bg_color(rl_slider, hex(TEXT), LV_PART_KNOB);
  lv_obj_add_event_cb(rl_slider, [](lv_event_t *e) {
    ring_light::set_brightness(lv_slider_get_value((lv_obj_t *)lv_event_get_target(e)));
    refresh_ring_light();
  }, LV_EVENT_VALUE_CHANGED, nullptr);

  lv_obj_set_pos(text(scr_ring_light, "COLOUR", &inter_14, hex(MUTED)), M + 4, 284);
  const char *names[] = {"Cool white", "Cream", "Warm white"};
  const int bw = (width - 2 * G) / 3;
  for (int i = 0; i < 3; ++i) {
    rl_colours[i] = box(scr_ring_light, M + i * (bw + G), 308, bw, 52, 0x1C1C1E, R_SM);
    lv_obj_center(text(rl_colours[i], names[i], &inter_20b, hex(TEXT)));
    pressable(rl_colours[i]);
    on_click(rl_colours[i], [](lv_event_t *e) {
      ring_light::set_colour(static_cast<ring_light::Colour>((intptr_t)lv_event_get_user_data(e)));
      refresh_ring_light();
    }, (void *)(intptr_t)i);
  }
  lv_obj_t *effects = box(scr_ring_light, M, 376, width, 52, 0x1C1C1E, R_SM);
  row(effects, 0, 52, "Effects & setup", &rl_effects_value, open_ring_behaviour);
  rl_note = text(scr_ring_light, "", &inter_14, hex(MUTED));
  lv_obj_set_pos(rl_note, M + 4, 444);
  build_ring_behaviour();
  refresh_ring_light();
}
