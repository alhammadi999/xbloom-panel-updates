#if PANEL_SPOTIFY_TRIAL
lv_obj_t *scr_spotify, *sp_title, *sp_artist, *sp_device, *sp_note;
lv_obj_t *sp_previous, *sp_play, *sp_next, *sp_link, *sp_disconnect, *sp_enabled;
void refresh_spotify() {
  const auto s = spotify::state();
  if (s.enabled) lv_obj_add_state(sp_enabled, LV_STATE_CHECKED);
  else lv_obj_remove_state(sp_enabled, LV_STATE_CHECKED);
  auto enable_button = [](lv_obj_t *object, bool on) {
    if (on) lv_obj_remove_state(object, LV_STATE_DISABLED);
    else lv_obj_add_state(object, LV_STATE_DISABLED);
    set_opa(object, on ? LV_OPA_COVER : LV_OPA_30);
  };
  const bool control = s.enabled && s.linked && s.controls && !s.busy;
  enable_button(sp_previous, control && s.can_previous);
  enable_button(sp_play, control && (s.playing ? s.can_pause : s.can_play));
  enable_button(sp_next, control && s.can_next);
  set_text(lv_obj_get_child(sp_play, 0), s.playing ? "Pause" : "Play");
  show(sp_link, s.enabled && !s.linked);
  show(sp_disconnect, s.linked);
  enable_button(sp_link, !s.busy && net::state() == net::Wifi::Connected);
  if (s.pairing_code[0]) {
    char line[128];
    set_text(sp_title, "Connect from your computer");
    snprintf(line, sizeof line, "Panel address: %s", net::ip()); set_text(sp_artist, line);
    snprintf(line, sizeof line, "Pairing code: %s", s.pairing_code); set_text(sp_device, line);
    set_text(sp_note, "Use the Spotify linking helper. This code expires in 5 minutes.");
  } else {
    set_text(sp_title, !s.enabled ? "Spotify remote is off" : s.title[0] ? s.title : "Your music, on your phone");
    set_text(sp_artist, s.enabled && s.linked ? s.artist : "Sound stays on your phone's connected speaker.");
    set_text(sp_device, s.enabled && s.linked ? s.device : "Spotify Premium required");
    set_text(sp_note, s.busy ? "Connecting to Spotify..." : s.message);
  }
}
void open_spotify(lv_event_t *) {
  spotify::set_visible(true); refresh_spotify(); load(scr_spotify, Anim::PushLeft);
}
void build_spotify() {
  scr_spotify = new_screen(BG);
  sub_header(scr_spotify, "Spotify trial", [](lv_event_t *) {
    spotify::set_visible(false); back_to_settings(nullptr);
  });
  lv_obj_t *power = group(scr_spotify, W - 190, 42, 160, 40);
  lv_obj_set_pos(text(power, "Enable", &inter_16, hex(SUB)), 0, 10);
  sp_enabled = toggle(power, spotify::state().enabled, [](lv_event_t *e) {
    spotify::set_enabled(lv_obj_has_state((lv_obj_t *)lv_event_get_target(e), LV_STATE_CHECKED)); refresh_spotify();
  });
  lv_obj_align(sp_enabled, LV_ALIGN_RIGHT_MID, 0, 0);
  auto *card = box(scr_spotify, M, 96, W - 2*M, 264, 0x1C1C1E, R);
  sp_title = text(card, "", &inter_26b, hex(TEXT)); lv_obj_set_pos(sp_title, 24, 24);
  sp_artist = text(card, "", &inter_20, hex(SUB)); lv_obj_set_pos(sp_artist, 24, 66);
  sp_device = text(card, "", &inter_16, hex(MUTED)); lv_obj_set_pos(sp_device, 24, 100);
  for (auto *label : {sp_title, sp_artist, sp_device}) {
    lv_obj_set_width(label, W - 2*M - 48); lv_label_set_long_mode(label, LV_LABEL_LONG_DOT);
  }
  sp_previous = pill(card, 24, 142, 180, 50, "Previous", SURFACE, TEXT, [](lv_event_t *) { spotify::command(spotify::Command::Previous); });
  sp_play = pill(card, 220, 142, 200, 50, "Play", 0x1DB954, 0x000000, [](lv_event_t *) {
    spotify::command(spotify::state().playing ? spotify::Command::Pause : spotify::Command::Play);
  });
  sp_next = pill(card, 436, 142, 180, 50, "Next", SURFACE, TEXT, [](lv_event_t *) { spotify::command(spotify::Command::Next); });
  sp_note = text(card, "", &inter_14, hex(MUTED)); lv_obj_set_pos(sp_note, 24, 210);
  lv_obj_set_width(sp_note, W - 2*M - 48); lv_label_set_long_mode(sp_note, LV_LABEL_LONG_WRAP);
  sp_link = pill(scr_spotify, M, 382, 220, 48, "Link account", TEXT, BG, [](lv_event_t *) { spotify::start_pairing(); refresh_spotify(); });
  sp_disconnect = pill(scr_spotify, M, 382, 220, 48, "Disconnect account", SURFACE, TEXT, [](lv_event_t *) { spotify::disconnect(); refresh_spotify(); });
  refresh_spotify();
}
#endif
