#if PANEL_SPOTIFY_TRIAL
#include "spotify_logo.inc"
lv_obj_t *scr_spotify, *sp_title, *sp_artist, *sp_device, *sp_note;
lv_obj_t *sp_previous, *sp_play, *sp_next, *sp_link, *sp_disconnect, *sp_enabled;
lv_obj_t *sp_volume, *sp_minus, *sp_plus, *sp_volume_text, *sp_qr, *sp_scan, *sp_scan_note;
lv_obj_t *sp_art, *sp_status, *sp_bars[4];
bool sp_dragging = false;
char sp_qr_url[192]{};
void refresh_spotify() {
  const auto s = spotify::state();
  if (s.enabled) lv_obj_add_state(sp_enabled, LV_STATE_CHECKED);
  else lv_obj_remove_state(sp_enabled, LV_STATE_CHECKED);
  auto enable_button = [](lv_obj_t *object, bool on) {
    if (on) lv_obj_remove_state(object, LV_STATE_DISABLED);
    else lv_obj_add_state(object, LV_STATE_DISABLED);
    set_opa(object, on ? LV_OPA_COVER : LV_OPA_30);
  };
  const bool pairing = s.login_url[0];
  const bool control = s.enabled && s.linked && s.controls && !s.busy;
  enable_button(sp_previous, control && s.can_previous);
  enable_button(sp_play, control && (s.playing ? s.can_pause : s.can_play));
  enable_button(sp_next, control && s.can_next);
  for(auto *o : {sp_volume, sp_minus, sp_plus}) enable_button(o, control && s.can_volume);
  set_text(lv_obj_get_child(sp_play, 0), s.playing ? LV_SYMBOL_PAUSE : LV_SYMBOL_PLAY);
  show(sp_link, s.enabled && !s.linked); show(sp_disconnect, s.linked);
  enable_button(sp_link, !s.busy && net::state() == net::Wifi::Connected);
  for(auto *o : {sp_title, sp_artist, sp_device, sp_previous, sp_play, sp_next, sp_volume, sp_minus, sp_plus, sp_volume_text, sp_art, sp_status}) show(o, !pairing);
  for(auto *o : {sp_qr, sp_scan, sp_scan_note}) show(o, pairing);
  set_text(sp_status, !s.linked ? "PHONE REMOTE" : s.playing ? "NOW PLAYING" : "PAUSED");
  lv_obj_set_style_text_color(sp_status, hex(s.playing && s.enabled ? 0x1ED760 : MUTED), 0);
  for (int i=0;i<4;++i) {
    int height = s.playing && s.enabled && s.controls ? 8 + ((lv_tick_get()/400 + i*3)%5)*5 : 8;
    lv_obj_set_height(sp_bars[i], height); lv_obj_set_y(sp_bars[i], 116-height);
  }
  if (pairing) {
    if (strcmp(sp_qr_url, s.login_url)) {
      snprintf(sp_qr_url, sizeof sp_qr_url, "%s", s.login_url);
      lv_qrcode_update(sp_qr, sp_qr_url, strlen(sp_qr_url));
    }
    set_text(sp_note, "QR expires in 5 minutes. Tap Login again for a new QR.");
  } else {
    sp_qr_url[0] = 0;
    set_text(sp_title, !s.enabled ? "Spotify remote is off" : s.title[0] ? s.title : "Your music, on your phone");
    set_text(sp_artist, s.enabled && s.linked ? s.artist : "Sound stays on your phone's connected speaker.");
    set_text(sp_device, s.enabled && s.linked ? s.device : "Spotify Premium required");
    set_text(sp_note, s.busy ? "Connecting to Spotify..." : s.message);
    if (!sp_dragging) {
      lv_slider_set_value(sp_volume, s.volume < 0 ? 0 : s.volume, LV_ANIM_OFF);
      char value[96];
      if (s.can_volume && s.controls) snprintf(value, sizeof value, "Volume  %d%%", s.volume);
      else snprintf(value, sizeof value, "%s", s.linked ? "Volume: use your phone for this device" : "Volume");
      set_text(sp_volume_text, value);
    }
  }
}
void open_spotify(lv_event_t *) {
  spotify::set_visible(true); refresh_spotify(); load(scr_spotify, Anim::PushLeft);
}
void build_spotify() {
  scr_spotify = new_screen(BG);
  sub_header(scr_spotify, "", [](lv_event_t *) { spotify::set_visible(false); back_to_apps(nullptr); });
  auto *logo = lv_image_create(scr_spotify); lv_image_set_src(logo, &spotify_logo_image); lv_obj_set_pos(logo, 76, 43);
  auto *trial = box(scr_spotify, 264, 50, 68, 26, 0x17271D, 8);
  lv_obj_center(text(trial, "TRIAL", &inter_14, hex(0x8DB79B)));
  lv_obj_t *power = group(scr_spotify, W - 190, 42, 160, 40);
  lv_obj_set_pos(text(power, "Enable", &inter_16, hex(SUB)), 0, 10);
  sp_enabled = toggle(power, spotify::state().enabled, [](lv_event_t *e) {
    spotify::set_enabled(lv_obj_has_state((lv_obj_t *)lv_event_get_target(e), LV_STATE_CHECKED)); refresh_spotify();
  });
  lv_obj_align(sp_enabled, LV_ALIGN_RIGHT_MID, 0, 0);
  auto *card = box(scr_spotify, M, 96, W - 2*M, 300, 0x151A17, R);
  lv_obj_set_style_border_width(card, 1, 0); lv_obj_set_style_border_color(card, hex(0x293B30), 0);
  sp_title = text(card, "", &inter_26b, hex(TEXT)); lv_obj_set_pos(sp_title, 200, 36);
  sp_artist = text(card, "", &inter_20, hex(SUB)); lv_obj_set_pos(sp_artist, 200, 73);
  sp_device = text(card, "", &inter_16, hex(MUTED)); lv_obj_set_pos(sp_device, 200, 102);
  for (auto *label : {sp_title, sp_artist, sp_device}) {
    lv_obj_set_width(label, 520); lv_label_set_long_mode(label, LV_LABEL_LONG_SCROLL_CIRCULAR);
  }
  sp_art = box(card, 24, 24, 144, 144, 0x20382A, 16);
  auto *music=text(sp_art, LV_SYMBOL_AUDIO, &lv_font_montserrat_48, hex(0xB2E6C2)); lv_obj_set_pos(music, 49, 24);
  for(int i=0;i<4;++i) sp_bars[i]=box(sp_art, 48+i*14, 108, 8, 8, 0x1ED760, 4);
  sp_status=text(card, "PHONE REMOTE", &inter_14, hex(0x1ED760)); lv_obj_set_pos(sp_status, 200, 14);
  sp_previous=round_button(card, 200, 132, 44, LV_SYMBOL_PREV, &lv_font_montserrat_20, nullptr, [](lv_event_t *) { spotify::command(spotify::Command::Previous); });
  sp_play=round_button(card, 260, 126, 56, LV_SYMBOL_PLAY, &lv_font_montserrat_28, nullptr, [](lv_event_t *) { spotify::command(spotify::state().playing ? spotify::Command::Pause : spotify::Command::Play); });
  lv_obj_set_style_bg_color(sp_play, hex(0x1ED760), 0); lv_obj_set_style_text_color(lv_obj_get_child(sp_play,0), hex(0),0);
  sp_next=round_button(card, 332, 132, 44, LV_SYMBOL_NEXT, &lv_font_montserrat_20, nullptr, [](lv_event_t *) { spotify::command(spotify::Command::Next); });
  sp_volume_text = text(card, "Volume", &inter_16, hex(SUB)); lv_obj_set_pos(sp_volume_text, 24, 188);
  sp_minus = pill(card, 24, 216, 56, 36, "-", SURFACE, TEXT, [](lv_event_t *) {
    spotify::command(spotify::Command::Volume, std::max(0, spotify::state().volume - 5));
  });
  sp_plus = pill(card, 664, 216, 56, 36, "+", SURFACE, TEXT, [](lv_event_t *) {
    spotify::command(spotify::Command::Volume, std::min(100, spotify::state().volume + 5));
  });
  sp_volume = lv_slider_create(card); lv_obj_set_pos(sp_volume, 112, 229); lv_obj_set_size(sp_volume, 520, 8);
  lv_slider_set_range(sp_volume, 0, 100);
  lv_obj_set_style_bg_color(sp_volume, hex(0x1ED760), LV_PART_INDICATOR);
  lv_obj_set_style_bg_color(sp_volume, hex(TEXT), LV_PART_KNOB);
  lv_obj_add_event_cb(sp_volume, [](lv_event_t *e) {
    const auto event = lv_event_get_code(e);
    if (event == LV_EVENT_PRESSED) sp_dragging = true;
    if (event == LV_EVENT_VALUE_CHANGED) {
      char value[32]; snprintf(value, sizeof value, "Volume  %d%%", (int)lv_slider_get_value(sp_volume)); set_text(sp_volume_text, value);
    }
    if (event == LV_EVENT_RELEASED) {
      spotify::command(spotify::Command::Volume, lv_slider_get_value(sp_volume)); sp_dragging = false;
    }
    if (event == LV_EVENT_PRESS_LOST) sp_dragging = false;
  }, LV_EVENT_ALL, nullptr);
  sp_note = text(card, "", &inter_14, hex(MUTED)); lv_obj_set_pos(sp_note, 24, 258);
  lv_obj_set_width(sp_note, W - 2*M - 48); lv_label_set_long_mode(sp_note, LV_LABEL_LONG_WRAP);
  sp_qr = lv_qrcode_create(card); lv_qrcode_set_size(sp_qr, 224);
  lv_qrcode_set_dark_color(sp_qr, hex(0)); lv_qrcode_set_light_color(sp_qr, hex(0xffffff));
  lv_obj_set_pos(sp_qr, 24, 16); lv_obj_set_style_border_width(sp_qr, 8, 0); lv_obj_set_style_border_color(sp_qr, hex(0xffffff), 0);
  sp_scan = text(card, "Scan with your phone", &inter_26b, hex(TEXT)); lv_obj_set_pos(sp_scan, 280, 46);
  sp_scan_note = text(card, "1. Use Wi-Fi or mobile data.\n\n2. Log in to Spotify on your phone.\n\n3. Approve to connect automatically.", &inter_16, hex(SUB));
  lv_obj_set_pos(sp_scan_note, 280, 102); lv_obj_set_width(sp_scan_note, 420);
  sp_link = pill(scr_spotify, M, 412, 250, 44, "Login with Spotify", TEXT, BG, [](lv_event_t *) { spotify::start_pairing(); refresh_spotify(); });
  sp_disconnect = pill(scr_spotify, M, 412, 250, 44, "Disconnect account", SURFACE, TEXT, [](lv_event_t *) { spotify::disconnect(); refresh_spotify(); });
  refresh_spotify();
}
#endif
