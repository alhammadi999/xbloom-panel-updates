#include "wallpaper.h"
#include <LittleFS.h>
#include <esp_heap_caps.h>
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>
#include <new>
#include <algorithm>

namespace wallpaper {
namespace {
SemaphoreHandle_t mutex = nullptr;
std::shared_ptr<const Image> displayed;
std::shared_ptr<Image> incoming;
File upload;
uint8_t header[header_bytes];
size_t received = 0;
bool uploading = false;
constexpr char saved[] = "/wallpaper.rgb";
constexpr char temporary[] = "/wallpaper.tmp";
void publish(std::shared_ptr<const Image> image) {
  xSemaphoreTake(mutex, portMAX_DELAY);
  displayed = std::move(image);
  xSemaphoreGive(mutex);
}
}
Image::Image() { pixels = static_cast<uint8_t *>(heap_caps_malloc(pixel_bytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT)); }
Image::~Image() { heap_caps_free(pixels); }
std::shared_ptr<const Image> current() {
  if (!mutex) return {};
  xSemaphoreTake(mutex, portMAX_DELAY);
  auto result = displayed;
  xSemaphoreGive(mutex);
  return result;
}
void begin() {
  mutex = xSemaphoreCreateMutex();
  if (!mutex) return;
  LittleFS.remove(temporary); // discard only an incomplete upload left by power loss
  File file = LittleFS.open(saved, "r");
  if (!file || file.size() != header_bytes + pixel_bytes) return;
  uint8_t probe[header_bytes];
  if (file.read(probe, sizeof probe) != sizeof probe || !valid_header(probe, sizeof probe)) return;
  auto image = std::shared_ptr<Image>(new(std::nothrow) Image);
  if (!image || !image->pixels || file.read(image->pixels, pixel_bytes) != pixel_bytes) return;
  publish(std::move(image));
}
void abort_upload() {
  if (upload) upload.close();
  if (uploading) LittleFS.remove(temporary);
  incoming.reset();
  uploading = false;
  received = 0;
}
bool start_upload() {
  abort_upload();
  if (!mutex || LittleFS.totalBytes() <= LittleFS.usedBytes() + pixel_bytes + header_bytes + 16384) return false;
  upload = LittleFS.open(temporary, "w");
  uploading = bool(upload);
  return uploading;
}
bool write_upload(const uint8_t *data, size_t size) {
  if (!uploading || size > header_bytes + pixel_bytes - received) { abort_upload(); return false; }
  const size_t offset = received;
  const size_t prefix = offset < header_bytes ? std::min(size, header_bytes - offset) : 0;
  if (prefix) memcpy(header + offset, data, prefix);
  if (offset + size >= header_bytes && !incoming) {
    if (!valid_header(header, sizeof header)) { abort_upload(); return false; }
    incoming = std::shared_ptr<Image>(new(std::nothrow) Image);
    if (!incoming || !incoming->pixels) { abort_upload(); return false; }
  }
  if (size > prefix) memcpy(incoming->pixels + offset + prefix - header_bytes, data + prefix, size - prefix);
  if (upload.write(data, size) != size) { abort_upload(); return false; }
  received += size;
  return true;
}
bool finish_upload() {
  if (!uploading || received != pixel_bytes + header_bytes || !incoming) { abort_upload(); return false; }
  upload.close();
  if (!LittleFS.rename(temporary, saved)) { abort_upload(); return false; }
  publish(std::move(incoming));
  uploading = false;
  received = 0;
  return true;
}
}
