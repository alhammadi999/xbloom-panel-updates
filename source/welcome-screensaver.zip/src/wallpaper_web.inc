// Local-only photo conversion. The browser crops to 800x480 and sends RGB565,
// so the panel never needs a JPEG/PNG decoder or a full RGBA image in memory.
const char WALLPAPER_PAGE[] PROGMEM = R"HTML(<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>xBloom background</title>
<style>body{color-scheme:dark;background:#15110e;color:#f2e9dc;font:16px system-ui;margin:0}main{max-width:580px;margin:auto;padding:28px 20px}h1{font-size:26px}p{color:#b2a18b}input,button{font:inherit}button{padding:13px 22px;border:0;border-radius:24px;background:#c8a475;color:#15110e;margin-top:20px}canvas{width:100%;height:auto;border-radius:12px;margin-top:24px;background:#211a14}#status{min-height:48px}</style>
</head><body><main><h1>Your background</h1><p>Choose a JPEG, PNG or WebP image. The centre is cropped to fit the panel. Your photo stays on your phone and panel.</p>
<input id="photo" type="file" accept="image/jpeg,image/png,image/webp"><canvas id="preview" width="800" height="480"></canvas>
<button id="save" disabled>Save on panel</button><p id="status" role="status"></p></main><script>
const input=document.getElementById('photo'),canvas=document.getElementById('preview'),button=document.getElementById('save'),status=document.getElementById('status');
let imageReady=false,selection=0;
input.onchange=async()=>{const request=++selection;imageReady=false;button.disabled=true;const file=input.files[0];if(!file)return;
 if(file.size>12*1024*1024){status.textContent='Choose a photo smaller than 12 MB.';return;}
 status.textContent='Preparing preview...';
 try{const image=await createImageBitmap(file);if(request!==selection){image.close();return;}if(!image.width||!image.height)throw Error();
 const scale=Math.max(800/image.width,480/image.height),w=800/scale,h=480/scale;
 const ctx=canvas.getContext('2d');ctx.fillStyle='#15110e';ctx.fillRect(0,0,800,480);ctx.drawImage(image,(image.width-w)/2,(image.height-h)/2,w,h,0,0,800,480);image.close();imageReady=true;button.disabled=false;status.textContent='Preview ready. Keep the photo page open on the panel.';
 }catch(error){status.textContent='Cannot open this image. Try a JPEG or PNG.';}};
button.onclick=async()=>{if(!imageReady)return;button.disabled=input.disabled=true;status.textContent='Saving...';
 try{const rgba=canvas.getContext('2d').getImageData(0,0,800,480).data,bytes=new Uint8Array(768008);bytes.set([88,66,71,49,32,3,224,1]);
 for(let p=0,i=8;p<rgba.length;p+=4,i+=2){const rgb=((rgba[p]>>3)<<11)|((rgba[p+1]>>2)<<5)|(rgba[p+2]>>3);bytes[i]=rgb&255;bytes[i+1]=rgb>>8;}
 const form=new FormData();form.append('photo',new Blob([bytes],{type:'application/octet-stream'}),'background.xbg');
 const response=await fetch('/wallpaper',{method:'POST',body:form});const result=await response.json();if(!response.ok||!result.ok)throw Error(result.error||'Save failed.');
 status.textContent='Saved. My photo is now selected on your panel.';
 }catch(error){status.textContent=error.message||'Connection lost. Try again.';}finally{button.disabled=false;input.disabled=false;}};
</script></body></html>)HTML";
bool wallpaper_saved = false;
const char *wallpaper_error = "No photo received.";
bool photo_allowed() {
  return g_appearance_page && g_upd != net::Upd::Receiving && g_upd != net::Upd::Done &&
    !install_queued && !online_installing && ble_link::panel_can_restart();
}
void handle_wallpaper_upload() {
  auto &upload = server.upload();
  switch (upload.status) {
    case UPLOAD_FILE_START:
      wallpaper_saved = false;
      wallpaper_error = "Open Screensaver > Choose my photo and leave the Studio idle.";
      g_wallpaper_receiving = photo_allowed() && wallpaper::start_upload();
      if (!g_wallpaper_receiving && photo_allowed()) wallpaper_error = "Not enough space or photo memory unavailable.";
      break;
    case UPLOAD_FILE_WRITE:
      if (!g_wallpaper_receiving) return;
      if (!photo_allowed() || !wallpaper::write_upload(upload.buf, upload.currentSize)) {
        wallpaper::abort_upload(); g_wallpaper_receiving = false;
        wallpaper_error = "Photo save interrupted or invalid image. Previous photo kept.";
      }
      break;
    case UPLOAD_FILE_END:
      if (!g_wallpaper_receiving) return;
      wallpaper_saved = photo_allowed() && wallpaper::finish_upload();
      g_wallpaper_receiving = false;
      if (!wallpaper_saved) { wallpaper::abort_upload(); wallpaper_error = "Incomplete photo. Previous photo kept."; }
      break;
    case UPLOAD_FILE_ABORTED:
      wallpaper::abort_upload(); g_wallpaper_receiving = false; wallpaper_saved = false;
      wallpaper_error = "Photo upload interrupted. Previous photo kept.";
      break;
  }
}
void handle_wallpaper_done() {
  if (wallpaper_saved) {
    net::set_pref_saver(screen_prefs::Saver::Photo);
    { Lock l; g_appearance_wake = true; }
    send_json(200, true);
  } else send_json(400, false, wallpaper_error);
  wallpaper_saved = false;
}
