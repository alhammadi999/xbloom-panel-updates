#include "machine_settings.h"
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <string>

static xb::Bytes bytes(std::string hex) {
  xb::Bytes result;
  for (size_t i = 0; i < hex.size(); i += 2)
    result.push_back(static_cast<uint8_t>(strtol(hex.substr(i, 2).c_str(), nullptr, 16)));
  return result;
}

int main() {
  using namespace machine;
  Settings s;
  auto info = bytes("580207499e4b000000c100000000000000000000000000000000000000000000000000000000000000000000000001000000010200000000000000000000000000d0020000000000004fa0");
  assert(decode(info, s));
  assert(s.value[Weight] == 2 && s.value[Temperature] == 1 && s.value[Water] == 1 && s.radius_base == 720);
  // Connection handshake (185, 1), never the state-changing HOME command 8022.
  const auto info_query = query(40521);
  assert(xb::frame_code(info_query) == 8100 && info_query.size() == 20);
  assert(read_le32(info_query.data()+10) == 185 && read_le32(info_query.data()+14) == 1);
  assert(xb::crc16(info_query.data(),18) == uint16_t(info_query[18] | info_query[19]<<8));
  assert(query(8022).empty());
  assert(query(11506) == bytes("580102f22c0c0000000155de"));
  assert(query(11508) == bytes("580102f42c0c000000019886"));
  assert(write_frame(s, Weight, 2) == bytes("580101451f100000000102000000ca8e"));
  assert(write_frame(s, Temperature, 0) == bytes("5801014a1f100000000100000000f0ab"));
  assert(write_frame(s, Water, 1) == bytes("5801019c111000000001010000009ced"));
  assert(write_frame(s, Radius, 640) == bytes("580102f32c100000000180020000a956"));
  assert(write_frame(s, Vibration, 1100) == bytes("580102f52c10000000014c040000ead9"));
  assert(decode(bytes("580207f22c10000000c1200300007a3e"), s) && s.value[Radius] == 800);
  assert(decode(bytes("580207f42c10000000c1b0040000c7a9"), s) && s.value[Vibration] == 1200);
  assert(!allowed(s, Radius, 400) && !allowed(s, Radius, 721) && !allowed(s, Vibration, 1101));
  assert(write_frame(s, Water, 2).empty());
  assert(decode(bytes("580207499e36000000c1000000000000000000000000000000000000000000000000000000000000000000000000010000000102dd6e"), s) && s.radius_base == -1);
  assert(write_frame(s, Radius, 720).empty());
  info.back() ^= 1;
  assert(!decode(info,s));
  assert(!decode(query(40521), s));
  assert(!decode(bytes("580207499e35000000c10000000000000000000000000000000000000000000000000000000000000000000000000100000001042a"), s));
  auto known = bytes("580207499e4b000000c100000000000000000000000000000000000000000000000000000000000000000000000001000000010200000000000000000000000000d0020000000000004fa0");
  Settings early;
  assert(decode(bytes("580207f22c10000000c1200300007a3e"), early));
  assert(early.radius_reply.seen && early.radius_reply.raw == 800 && early.value[Radius] == -1);
  assert(decode(known, early) && early.value[Radius] == 800 && early.radius_base_raw == 720);
  assert(is_settings_report(11506) && is_settings_report(11508) && !is_settings_report(11507));
  // Unknown formats are diagnostic evidence only, never writable settings.
  auto unknown = bytes("580207f42c10000000c1b0040000c7a9");
  unknown[2] = 8;
  auto crc = xb::crc16(unknown.data(), unknown.size()-2);
  unknown[unknown.size()-2]=crc&255;unknown.back()=crc>>8;
  assert(!decode(unknown, early));
  assert(early.vibration_reply.seen && early.vibration_reply.type == 8 && early.value[Vibration] == -1);
  unknown.back()^=1;Settings corrupt;
  assert(!decode(unknown,corrupt) && !corrupt.vibration_reply.seen);
  assert(decode(bytes("580207f42c10000000c1b0040000c7a9"), early));
  assert(early.value[Vibration] == 1200);
  xb::Assembler assembler;
  int reports = 0;
  auto accept = [&](const xb::Bytes &f) { assert(decode(f,s)); ++reports; };
  assembler.feed(known.data(), 17, accept);
  assert(reports == 0);
  assembler.feed(known.data()+17, known.size()-17, accept);
  assert(reports == 1 && s.radius_base == 720);
  assert(read_le32(xb::frame_brewer_start(3.0, 100, 92, 3, 1).data()+22) == 1);
  auto checksum=[](xb::Bytes &f) {
    auto crc=xb::crc16(f.data(),f.size()-2);f[f.size()-2]=crc&255;f.back()=crc>>8;
  };
  // Regression from owner's photograph: type 7/C2, radius 640, vibration 1100.
  // C2 is accepted only for exact scalar advanced reads, never generic activity.
  auto c2=bytes("580207f42c10000000c1b0040000c7a9");
  c2[9]=0xc2;c2[10]=0x4c;c2[11]=4;checksum(c2);
  assert(decode(c2,s) && s.value[Vibration]==1100 && !valid_report(c2));
  c2[9]=0xc3;checksum(c2);assert(!decode(c2,s) && s.value[Vibration]==-1);
  c2[9]=0xc2;c2.back()^=1;assert(!decode(c2,s));
  auto identity=known;identity[48]=8;identity[61]=0x91;identity[62]=0x32;identity[63]=0x78;identity[64]=0x56;
  identity[65]=identity[66]=identity[67]=identity[68]=0;checksum(identity);
  assert(decode(identity,s) && s.value[Display]==8 && s.value[Mode]==1 && s.radius_base==-1);
  c2=bytes("580207f22c10000000c1200300007a3e");c2[9]=0xc2;c2[10]=0x80;c2[11]=2;checksum(c2);
  assert(decode(c2,s) && s.radius_reply.raw==640 && s.value[Radius]==-1);
  assert(write_frame(s,Radius,640).empty()); // a zero reference is never guessed
  auto mode=write_frame(s,Mode,1);assert(xb::frame_code(mode)==11511 && mode[2]==2 && read_le32(mode.data()+10)==0x56783291);
  auto display=write_frame(s,Display,8);assert(xb::frame_code(display)==8103 && display[2]==1 && read_le32(display.data()+10)==8);
  assert(write_frame(s,Display,7).empty() && write_frame(s,Mode,2).empty());
  xb::Recipe preset;preset.n_pours=1;preset.pours[0].volume_ml=150;
  for(int i=0;i<3;++i){auto f=slot_frame(preset,i);assert(xb::frame_code(f)==11510 && f[2]==2 && f[10]==i && f[11]==0x12);}
  assert(slot_frame(preset,3).empty());preset.n_pours=0;assert(slot_frame(preset,0).empty());
  puts("PASS machine settings commands, readback, CRC, limits, legacy reports and water source");
}
