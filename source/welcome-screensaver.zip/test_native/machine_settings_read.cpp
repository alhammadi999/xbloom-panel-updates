#include "machine_settings_read.h"
#include <cassert>
#include <cstdio>
#include <vector>

struct Link {
  uint32_t clock=0, elapsed=0, reply_at=0, drop_at=0;
  bool answered=false, connected_flag=true, fail_write=false, echo_only=false;
  uint16_t expected=40521;
  std::vector<xb::Bytes> writes;
  machine::Settings settings;
  xb::Assembler assembler;
  bool connected(){return connected_flag;}
  bool received(){return answered;}
  uint32_t now(){return clock;}
  bool write(const xb::Bytes &f){writes.push_back(f);return !fail_write;}
  void pump(uint32_t ms){
    clock+=ms;elapsed+=ms;
    if(drop_at && elapsed>=drop_at)connected_flag=false;
    if(reply_at && elapsed>=reply_at){
      reply_at=0;
      xb::Bytes report(75,0);
      report[0]=0x58;report[1]=2;report[2]=7;report[3]=0x49;report[4]=0x9e;
      report[5]=75;report[9]=0xc1;report[46]=1;report[50]=1;report[51]=2;
      report[65]=0xd0;report[66]=2;
      if(echo_only){report[3]=0xa4;report[4]=0x1f;}
      if(expected==11508){
        report.resize(16);report[3]=0xf4;report[4]=0x2c;report[5]=16;
        report[10]=0xb0;report[11]=4;
      }
      auto crc=xb::crc16(report.data(),report.size()-2);report[report.size()-2]=crc&255;report.back()=crc>>8;
      auto accept=[&](const xb::Bytes &f){if(xb::frame_code(f)==expected && machine::decode(f,settings))answered=true;};
      const size_t split=10;
      assembler.feed(report.data(),split,accept);
      assert(!answered);
      assembler.feed(report.data()+split,report.size()-split,accept);
    }
  }
};
int main(){
  // A heartbeat later than the old 1.6 s deadline must still populate settings.
  Link slow;slow.reply_at=2500;
  assert(machine::read_report(40521,slow));
  assert(slow.writes.size()==1 && slow.settings.value[machine::Weight]==2);
  Link wake;wake.reply_at=3500;
  assert(machine::read_report(40521,wake) && wake.writes.size()==2);
  for(const auto &f:wake.writes)assert(xb::frame_code(f)==8100);
  // An ACK is not a settings report. No response ends at the bounded deadline.
  Link echo;echo.reply_at=100;echo.echo_only=true;
  assert(!machine::read_report(40521,echo) && echo.elapsed==6000 && echo.writes.size()==2);
  Link gone;gone.drop_at=500;
  assert(!machine::read_report(40521,gone) && gone.writes.size()==1);
  Link failed;failed.fail_write=true;
  assert(!machine::read_report(40521,failed) && failed.writes.size()==1);
  Link wrap;wrap.clock=UINT32_MAX-1000;wrap.reply_at=2500;
  assert(machine::read_report(40521,wrap));
  Link invalid;assert(!machine::read_report(8005,invalid) && invalid.writes.empty());
  Link advanced;advanced.expected=11508;advanced.reply_at=2500;
  assert(machine::read_report(11508,advanced) && advanced.settings.value[machine::Vibration]==1200);
  assert(advanced.writes.size()==1 && advanced.writes[0][2]==2);
  puts("PASS settings refresh: handshake, delayed/fragmented report, retry, echo rejection, disconnect and timer wrap");
}
