#pragma once
#include <stdint.h>
using esp_err_t = int;
constexpr esp_err_t ESP_OK = 0, ESP_FAIL = -1;
constexpr int ESP_PARTITION_SUBTYPE_APP_FACTORY = 0;
struct esp_partition_t { int subtype; uint32_t address; };
enum esp_ota_img_states_t {
  ESP_OTA_IMG_NEW, ESP_OTA_IMG_PENDING_VERIFY, ESP_OTA_IMG_VALID,
  ESP_OTA_IMG_INVALID, ESP_OTA_IMG_ABORTED, ESP_OTA_IMG_UNDEFINED = -1
};
const esp_partition_t *esp_ota_get_running_partition();
const esp_partition_t *esp_ota_get_boot_partition();
esp_err_t esp_ota_get_state_partition(const esp_partition_t *, esp_ota_img_states_t *);
esp_err_t esp_ota_mark_app_valid_cancel_rollback();
