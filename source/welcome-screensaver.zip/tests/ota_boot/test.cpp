#include <cassert>
#include <cstdio>
#include <initializer_list>
#include "esp_ota_ops.h"
#include "ota_boot.h"

esp_partition_t image{0x11, 0x610000}, old_image{0x10, 0x10000};
esp_partition_t *running = &image, *boot = &image;
esp_ota_img_states_t stored_state = ESP_OTA_IMG_PENDING_VERIFY;
int reads = 0, writes = 0, read_failure = 0, write_failures = 0;
bool discard_write = false;
const esp_partition_t *esp_ota_get_running_partition() { return running; }
const esp_partition_t *esp_ota_get_boot_partition() { return boot; }
esp_err_t esp_ota_get_state_partition(const esp_partition_t *, esp_ota_img_states_t *out) {
  if (++reads == read_failure) return ESP_FAIL;
  *out = stored_state; return ESP_OK;
}
esp_err_t esp_ota_mark_app_valid_cancel_rollback() {
  ++writes;
  if (write_failures > 0) { --write_failures; return ESP_FAIL; }
  if (!discard_write) stored_state = ESP_OTA_IMG_VALID;
  return ESP_OK;
}
void reset_fixture(esp_ota_img_states_t state = ESP_OTA_IMG_PENDING_VERIFY) {
  running = boot = &image; image.subtype = 0x11; stored_state = state;
  reads = writes = read_failure = write_failures = 0; discard_write = false;
}
// Model rollback-relevant persistent state, shared by reset and power cycle.
void reboot() {
  if (stored_state == ESP_OTA_IMG_PENDING_VERIFY) {
    stored_state = ESP_OTA_IMG_ABORTED; running = boot = &old_image;
  } else if (stored_state == ESP_OTA_IMG_NEW) {
    stored_state = ESP_OTA_IMG_PENDING_VERIFY;
  }
}
int main() {
  using ota_boot::Confirmation;
  reset_fixture(); Confirmation healthy;
  assert(!healthy.poll(60000, false) && reads == 0 && writes == 0);
  assert(healthy.poll(60001, true) && healthy.confirmed() && writes == 1 && reads == 2);
  reboot(); assert(running == &image && stored_state == ESP_OTA_IMG_VALID);
  Confirmation after_reset; assert(after_reset.poll(50, true) && writes == 1);
  reboot(); assert(running == &image); // Subsequent power cycle keeps new image.
  assert(healthy.poll(90000, true) && writes == 1 && reads == 3);

  reset_fixture(); Confirmation early;
  assert(early.poll(100, true)); // Healthy startup needs no 30-second delay.
  reboot(); assert(running == &image);
  reset_fixture(); Confirmation failed_start;
  assert(!failed_start.poll(60000, false));
  reboot(); assert(running == &old_image); // Preserve failed-start rollback.

  reset_fixture(); read_failure = 1; Confirmation bad_read;
  assert(!bad_read.poll(500, true) && writes == 0);
  assert(!bad_read.poll(1499, true) && reads == 1);
  assert(bad_read.poll(1500, true)); reboot(); assert(running == &image);

  reset_fixture(); write_failures = 2; Confirmation bad_write;
  assert(!bad_write.poll(10, true) && !bad_write.confirmed());
  assert(!bad_write.poll(1010, true));
  assert(bad_write.poll(2010, true) && writes == 3);
  reboot(); assert(running == &image);

  reset_fixture(); discard_write = true; Confirmation lost_write;
  assert(!lost_write.poll(0, true) && !lost_write.confirmed());
  discard_write = false; assert(lost_write.poll(1000, true));
  reset_fixture(); read_failure = 2; Confirmation readback_failed;
  assert(!readback_failed.poll(0, true));
  assert(readback_failed.poll(1000, true) && writes == 1);

  for (auto state : {ESP_OTA_IMG_NEW, ESP_OTA_IMG_UNDEFINED}) {
    reset_fixture(state); Confirmation legacy;
    assert(legacy.poll(0, true) && stored_state == ESP_OTA_IMG_VALID);
    reboot(); assert(running == &image);
  }
  reset_fixture(ESP_OTA_IMG_VALID); Confirmation valid;
  assert(valid.poll(0, true) && writes == 0);
  for (auto state : {ESP_OTA_IMG_INVALID, ESP_OTA_IMG_ABORTED}) {
    reset_fixture(state); Confirmation invalid;
    assert(!invalid.poll(0, true) && writes == 0);
  }
  reset_fixture(); boot = &old_image; Confirmation mismatch;
  assert(!mismatch.poll(0, true) && writes == 0 && reads == 0);
  boot = &image; assert(mismatch.poll(1000, true));
  reset_fixture(); running = nullptr; Confirmation missing;
  assert(!missing.poll(0, true) && writes == 0);
  reset_fixture(); image.subtype = ESP_PARTITION_SUBTYPE_APP_FACTORY; Confirmation factory;
  assert(factory.poll(0, true) && reads == 0 && writes == 0);
  reset_fixture(); write_failures = 1; Confirmation wrap;
  assert(!wrap.poll(UINT32_MAX - 499, true));
  assert(!wrap.poll(499, true) && writes == 1);
  assert(wrap.poll(500, true) && writes == 2);
  puts("PASS: OTA confirmation, reset/power-cycle retention, failed-boot rollback, errors/retries/readback, legacy states, no repeated writes");
}
