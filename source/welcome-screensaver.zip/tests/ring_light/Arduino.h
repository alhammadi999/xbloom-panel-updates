#pragma once
#include <stdint.h>
#define OUTPUT 1
#define LOW 0
inline uint32_t fake_now = 0;
inline unsigned pwm[64]{};
inline bool attached[64]{};
inline unsigned attached_hz[64]{}, attached_bits[64]{};
inline int fail_attach_pin = -1;
inline bool fail_write = false;
inline unsigned largest_sum = 0;
inline uint32_t millis() { return fake_now; }
inline void pinMode(int, int) {}
inline void digitalWrite(int pin, int value) { pwm[pin] = value; }
inline bool ledcAttach(int pin, int hz, int bits) {
  attached_hz[pin] = hz; attached_bits[pin] = bits;
  return attached[pin] = pin != fail_attach_pin;
}
inline bool ledcDetach(int pin) { attached[pin] = false; return true; }
inline bool ledcWrite(int pin, unsigned value) {
  if (fail_write || !attached[pin]) return false;
  pwm[pin] = value;
  if (pwm[19] + pwm[20] > largest_sum) largest_sum = pwm[19] + pwm[20];
  return true;
}
struct FakeSerial { void println(const char *) {} };
inline FakeSerial Serial;
