#pragma once
#include <string.h>
#include <stdint.h>
inline bool fail_prefs = false, fail_save = false;
inline unsigned save_calls = 0;
inline uint8_t stored_brightness = 50, stored_colour = 1;
inline bool stored_flags[7]{};
inline int flag_index(const char *key) {
  const char *keys[] = {"swap", "start", "pour", "pause", "finish", "quiet", "on"};
  for (int i = 0; i < 7; ++i) if (!strcmp(key, keys[i])) return i;
  return -1;
}
class Preferences {
 public:
  bool begin(const char *, bool) { return !fail_prefs; }
  uint8_t getUChar(const char *key, uint8_t) { return !strcmp(key, "brightness") ? stored_brightness : stored_colour; }
  bool getBool(const char *key, bool def) { int i = flag_index(key); return i >= 0 ? stored_flags[i] : def; }
  unsigned putUChar(const char *key, uint8_t value) {
    ++save_calls; if (fail_save) return 0;
    if (!strcmp(key, "brightness")) stored_brightness = value; else stored_colour = value;
    return 1;
  }
  unsigned putBool(const char *key, bool value) {
    ++save_calls; if (fail_save) return 0;
    int i = flag_index(key); if (i >= 0) stored_flags[i] = value; return 1;
  }
};
