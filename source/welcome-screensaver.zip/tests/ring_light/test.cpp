#include <assert.h>
#include <stdio.h>
#include "Arduino.h"
#include "Preferences.h"
#include "ring_light.h"
using namespace ring_light;

int main() {
  State s;
  assert(mix(s).a == 0 && mix(s).b == 0);
  s.on = true; s.brightness = 100;
  s.colour = Colour::Cool; assert(mix(s).a == 255 && mix(s).b == 0);
  s.colour = Colour::Warm; assert(mix(s).a == 0 && mix(s).b == 255);
  s.colour = Colour::Cream; assert(mix(s).a + mix(s).b == 255);
  for (unsigned level = 0; level <= 255; ++level) {
    for (unsigned colour = 0; colour < 4; ++colour) {
      s.brightness = level; s.colour = static_cast<Colour>(colour); s.swap = false;
      auto d = mix(s); assert(d.a + d.b <= 255);
      s.swap = true; auto swapped = mix(s);
      assert(swapped.a == d.b && swapped.b == d.a);
    }
  }
  s = State{}; s.on = true; s.brightness = 100; s.colour = Colour::Cool;
  Animation a; a.starting = true; a.started = 100; a.activity = Activity::Brewing;
  s.start_fade = true;
  assert(render(s, a, 100).a == 0);
  assert(render(s, a, 1100).a >= 126 && render(s, a, 1100).a <= 128);
  assert(render(s, a, 2100).a == 255);
  a.starting = false; a.activity = Activity::Pouring; a.activity_since = 0; s.pour_pulse = true;
  assert(render(s, a, 0).a == 51 && render(s, a, 900).a == 255);
  a.activity = Activity::Paused; s.pause_pulse = true;
  assert(render(s, a, 0).a == 26 && render(s, a, 1800).a == 128);
  a.activity = Activity::Idle; a.finishing = true; a.finished = 0; s.finish_flash = true;
  assert(render(s, a, 300).a == 255 && render(s, a, 700).a == 0);
  assert(render(s, a, 1100).a == 255 && render(s, a, 1500).a == 0);
  assert(render(s, a, 1600).a == 255);
  s.quiet = true;
  auto quiet = render(s, a, 300); assert(quiet.a + quiet.b <= 26 && quiet.a && quiet.b);
  s.on = false; assert(render(s, a, 300).a == 0 && render(s, a, 300).b == 0);
  s.on = true; s.quiet = false; a.finishing = false; a.starting = true;
  a.started = UINT32_MAX - 999; assert(render(s, a, 0).a >= 126 && render(s, a, 0).a <= 128);

  // Exercise the real hardware adapter against fake GPIO and NVS APIs.
  stored_brightness = 255; stored_colour = 255;
  begin(); assert(ready() && !state().on && state().brightness == 100);
  assert(attached_hz[19] == 20000 && attached_hz[20] == 20000);
  assert(attached_bits[19] == 8 && attached_bits[20] == 8);
  assert(state().colour == Colour::Cream && pwm[19] == 0 && pwm[20] == 0);
  set_brightness(-10); set_on(true); assert(pwm[19] + pwm[20] == 0);
  set_brightness(200); set_colour(Colour::Cool); assert(pwm[19] == 255 && pwm[20] == 0);
  largest_sum = 0; set_colour(Colour::Warm); set_swap(true);
  assert(largest_sum <= 255 && pwm[19] == 255 && pwm[20] == 0);
  set_option(Option::PourPulse, true); set_option(Option::FinishFlash, true);
  set_option(Option::Quiet, true); assert(pwm[19] + pwm[20] <= 26);
  unsigned before = save_calls;
  fake_now += 1499; tick(); assert(save_calls == before);
  ++fake_now; tick(); assert(settings_saved() && save_calls == before + 8);
  begin(); assert(state().on && state().pour_pulse && state().quiet && state().finish_flash);
  set_option(Option::Quiet, false); set_on(true); start_brew();
  set_activity(Activity::Pouring); fake_now += 900; tick(); assert(pwm[19] + pwm[20] == 255);
  cancel_brew(); assert(pwm[19] + pwm[20] == 255);
  finish_brew(); fake_now += 700; tick(); assert(pwm[19] + pwm[20] == 0);
  fake_now += 900; tick(); assert(pwm[19] + pwm[20] == 255);
  set_on(false); finish_brew(); fake_now += 300; tick(); assert(pwm[19] + pwm[20] == 0);
  fail_write = true; set_on(true); assert(!ready() && !state().on && pwm[19] + pwm[20] == 0);
  fail_write = false; fail_attach_pin = 20; begin(); set_on(true);
  assert(!ready() && !state().on && pwm[19] + pwm[20] == 0);
  fail_attach_pin = -1; fail_prefs = true; begin(); assert(!settings_saved());
  fail_prefs = false; begin(); fail_save = true; set_brightness(17); fake_now += 1500; tick();
  assert(!settings_saved());
  fail_save = false;
  // Reboot immediately after each toggle: no tick or debounce delay.
  set_on(false); begin(); assert(!state().on && pwm[19] + pwm[20] == 0);
  before = save_calls;
  set_on(true); assert(save_calls == before + 1 && settings_saved());
  begin(); assert(state().on && pwm[19] + pwm[20] > 0);
  assert(state().brightness == 100 && state().colour == Colour::Warm && state().swap);
  before = save_calls;
  set_on(true); tick(); assert(save_calls == before); // No repeated flash writes.
  start_brew(); cancel_brew(); finish_brew();
  fake_now += 2000; tick(); begin(); assert(state().on);
  set_on(false); begin(); assert(!state().on && pwm[19] + pwm[20] == 0);
  // A save failure stays visible even if other settings save successfully.
  fail_save = true; set_on(true); assert(!settings_saved());
  fail_save = false; set_brightness(43);
  fake_now += 1499; tick(); assert(!settings_saved());
  ++fake_now; tick(); assert(settings_saved());
  begin(); assert(state().on && state().brightness == 43);
  // PWM faults disable outputs without overwriting the user's saved ON choice.
  before = save_calls;
  fail_attach_pin = 20; begin(); assert(!ready() && !state().on);
  assert(save_calls == before && pwm[19] + pwm[20] == 0);
  fail_attach_pin = -1; begin(); assert(ready() && state().on);
  fail_write = true; set_brightness(44); assert(!ready() && !state().on);
  fail_write = false; begin(); assert(ready() && state().on);
  // OFF also retries failed storage writes and survives restart.
  fail_save = true; set_on(false); assert(!settings_saved());
  fail_save = false; fake_now += 1500; tick(); begin(); assert(!state().on);
  puts("PASS: light effects, immediate ON/OFF persistence, reboot, save retry, PWM failures");
}
