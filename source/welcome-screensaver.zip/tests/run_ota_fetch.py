"""Run the real fetch function with fake hardware APIs; supply a C++ compiler."""
from pathlib import Path
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parents[1]
source = (root / "src/online_update.inc").read_text()
fetch = source[source.index("const char *fetch_image("):source.index("void online_tick()")]
harness = (root / "tests/test_ota_fetch.cpp").read_text().replace("// PRODUCTION_FETCH", fetch)
with tempfile.TemporaryDirectory() as name:
    folder = Path(name)
    cpp = folder / "ota.cpp"
    exe = folder / "ota.exe"
    cpp.write_text(harness)
    subprocess.run([*sys.argv[1:], "-std=c++17", "-I" + str(root / "include"), str(cpp), "-o", str(exe)], check=True)
    subprocess.run([str(exe)], check=True)
