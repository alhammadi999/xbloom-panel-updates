from pathlib import Path
import os
import runpy
import subprocess
import sys
import unittest
from unittest.mock import patch


class FakeEnv(dict):
    def Replace(self, **values):
        self.update(values)


class SpawnTests(unittest.TestCase):
    def setUp(self):
        self.fallback = lambda *args: 23
        self.env = FakeEnv(SPAWN=self.fallback)
        runpy.run_path(str(Path(__file__).resolve().parents[1] / "scripts/windows_ldgen.py"), init_globals={"env": self.env, "Import": lambda _: None})

    def test_child_keeps_pinned_core(self):
        program = '"C:\\tools venv\\Scripts\\pio.exe"' if os.name == "nt" else '"/tmp/tools venv/bin/pio"'
        with patch.object(subprocess, "call", return_value=0) as launch:
            self.assertEqual(self.env["SPAWN"](None,None,program,[program,"run","-e",'"crowpanel-advance-43-pilot"'],os.environ.copy()),0)
            command = launch.call_args.args[0]
            if os.name == "nt":
                self.assertTrue(command.startswith(subprocess.list2cmdline([sys.executable]) + " -m platformio run "))
            else:
                self.assertEqual(command,[sys.executable,"-m","platformio","run","-e","crowpanel-advance-43-pilot"])
            self.assertFalse(launch.call_args.kwargs["shell"])

    def test_other_commands_unchanged(self):
        self.assertEqual(self.env["SPAWN"](None,None,"other",["other"],{}),23)


if __name__ == "__main__":
    unittest.main()
