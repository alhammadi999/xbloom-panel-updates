import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("release", ROOT / "scripts/prepare_panel_release.py")
release = importlib.util.module_from_spec(spec)
spec.loader.exec_module(release)


class CustomerPromotionTests(unittest.TestCase):
    def promote(self, markers):
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            image = markers
            digest = hashlib.sha256(image).hexdigest()
            feed = dict(schema=1, board=release.BOARD, channel="pilot", version="3.4.3", sha256=digest, bytes=len(image))
            (folder / "pilot.json").write_text(json.dumps(feed))
            (folder / "xbloom-saud-3.4.3.bin").write_bytes(image)
            stable = folder / "stable.json"
            stable.write_text('{"version":"3.4.0","sha256":"original"}')
            before = stable.read_bytes()
            with patch.object(release, "image_info", return_value=("3.4.3", digest)), patch.object(sys, "argv", ["release", "promote", name]):
                try:
                    release.main()
                except ValueError:
                    self.assertEqual(stable.read_bytes(), before)
                    raise
            return json.loads(stable.read_text())

    def test_customer_can_be_promoted(self):
        self.assertEqual(self.promote(b"XBLOOM-CHANNEL|customer|")["version"], "3.4.3")

    def test_owner_cannot_be_promoted(self):
        with self.assertRaisesRegex(ValueError, "customer-only"):
            self.promote(b"XBLOOM-CHANNEL|owner|")

    def test_legacy_unclassified_image_cannot_be_promoted(self):
        with self.assertRaisesRegex(ValueError, "customer-only"):
            self.promote(b"old unclassified firmware")

    def test_conflicting_identity_cannot_be_promoted(self):
        with self.assertRaisesRegex(ValueError, "customer-only"):
            self.promote(b"XBLOOM-CHANNEL|customer|XBLOOM-CHANNEL|owner|")


if __name__ == "__main__":
    unittest.main()
