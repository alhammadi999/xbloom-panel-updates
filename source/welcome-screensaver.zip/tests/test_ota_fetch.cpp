// Host harness: the runner inserts the production fetch_image function below.
// Network, flash and SHA APIs are fakes; real image hashing is tested separately.
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <memory>
#include <string>
#include <vector>
#include "ota_release.h"
using String = std::string;
constexpr char FEED_ROOT[] = "https://example.invalid/";
constexpr int U_FLASH = 0;
struct Release { char digest[65] = {}; size_t bytes = 0; };
std::vector<uint8_t> image;
size_t cursor = 0, written = 0;
bool busy = false, aborted = false, finalized = false;
bool write_ok = true, end_ok = true, download_ok = true;
uint32_t ticks = 0;
int g_upd_pct = 0;
uint32_t millis() { return ticks; }
void delay(int n) { ticks += n; }
namespace ble_link { bool panel_can_restart() { return !busy; } }
struct FeedRequest {
  void *http = nullptr;
  int64_t length = 0;
  bool open(const String &) { length = image.size(); return download_ok; }
};
int esp_http_client_read(void *, char *out, size_t n) {
  n = std::min(n, image.size() - cursor);
  memcpy(out, image.data() + cursor, n);
  cursor += n;
  return int(n);
}
bool esp_http_client_is_complete_data_received(void *) { return cursor == image.size(); }
void *memmem(const void *hay, size_t n, const void *needle, size_t m) {
  auto h = static_cast<const uint8_t *>(hay);
  for (size_t i = 0; i + m <= n; ++i)
    if (!memcmp(h + i, needle, m)) return const_cast<uint8_t *>(h + i);
  return nullptr;
}
struct FakeUpdate {
  bool begin(size_t, int) { return true; }
  size_t write(const uint8_t *, size_t n) { written += n; return write_ok ? n : 0; }
  bool end() { finalized = true; return end_ok; }
  void abort() { aborted = true; }
} Update;
struct mbedtls_sha256_context {};
void mbedtls_sha256_init(mbedtls_sha256_context *) {}
int mbedtls_sha256_starts(mbedtls_sha256_context *, int) { return 0; }
int mbedtls_sha256_update(mbedtls_sha256_context *, const uint8_t *, size_t) { return 0; }
int mbedtls_sha256_finish(mbedtls_sha256_context *, uint8_t *hash) { memset(hash, 0, 32); return 0; }
void mbedtls_sha256_free(mbedtls_sha256_context *) {}

// PRODUCTION_FETCH

Release reset(const char *version = "3.4.2", size_t marker_offset = 128) {
  image.assign(12000, 0);
  image[0] = 0xe9;
  std::string marker = std::string(PANEL_OTA_MARKER) + version + "|";
  memcpy(image.data() + marker_offset, marker.data(), marker.size());
  cursor = written = ticks = 0;
  g_upd_pct = 0;
  busy = aborted = finalized = false;
  write_ok = end_ok = download_ok = true;
  Release r;
  r.bytes = image.size();
  memset(r.digest, '0', 64);
  return r;
}
int main() {
  auto r = reset();
  assert(fetch_image(r, "3.4.2") == nullptr);
  assert(finalized && !aborted && written == r.bytes && g_upd_pct == 99);
  r = reset("3.4.2", 4090); // identity crosses a read boundary
  assert(fetch_image(r, "3.4.2") == nullptr && finalized);
  r = reset("3.4.0"); // exact original publication mistake
  assert(strstr(fetch_image(r, "3.4.2"), "version mismatch"));
  assert(aborted && !finalized && g_upd_pct < 100);
  r = reset(); r.digest[0] = '1';
  assert(strstr(fetch_image(r, "3.4.2"), "checksum mismatch"));
  assert(aborted && !finalized);
  r = reset(); r.bytes += 1;
  assert(strstr(fetch_image(r, "3.4.2"), "size"));
  assert(!finalized);
  r = reset(); image[0] = 0;
  assert(strstr(fetch_image(r, "3.4.2"), "Invalid"));
  assert(aborted && !finalized);
  r = reset(); busy = true;
  assert(strstr(fetch_image(r, "3.4.2"), "home"));
  assert(written == 0 && !finalized);
  r = reset(); write_ok = false;
  assert(strstr(fetch_image(r, "3.4.2"), "write failed"));
  assert(aborted && !finalized);
  r = reset(); end_ok = false;
  assert(strstr(fetch_image(r, "3.4.2"), "rejected"));
  assert(aborted && finalized && g_upd_pct < 100);
  r = reset(); download_ok = false;
  assert(strstr(fetch_image(r, "3.4.2"), "Download failed"));
  assert(written == 0 && !finalized);
  puts("PASS: 10 production OTA fetch scenarios (mock network/flash/SHA)");
}
