#include "screen_preferences.h"
#include "wallpaper.h"
#include <cassert>
#include <cstdio>
#include <initializer_list>
int main() {
  using namespace screen_prefs;
  assert(saver(99) == Saver::Motion && theme(99) == Theme::Espresso);
  assert(should_show(Saver::Motion, false, false, false));
  assert(should_show(Saver::Still, false, false, true));
  assert(should_show(Saver::Photo, false, false, false));
  assert(!should_show(Saver::Clock, false, false, false));
  assert(should_show(Saver::Clock, true, false, false));
  for (auto mode : {Saver::Motion, Saver::Still, Saver::Clock, Saver::Photo}) {
    assert(!should_show(mode, true, true, true));
    assert(should_show(mode, true, true, false));
  }
  assert(!should_show(Saver::Off, true, false, false));
  uint8_t header[] = {'X','B','G','1',32,3,224,1};
  assert(wallpaper::valid_header(header, sizeof header));
  for (size_t size = 0; size < sizeof header; ++size) assert(!wallpaper::valid_header(header, size));
  header[4] = 0; assert(!wallpaper::valid_header(header, sizeof header));
  header[4] = 32; header[0] = 'Q'; assert(!wallpaper::valid_header(header, sizeof header));
  assert(welcome_ms < 3000 && animation_step_ms >= 150);
  puts("PASS screen preferences: offline art, clock readiness, night mode, invalid values, photo format");
}
