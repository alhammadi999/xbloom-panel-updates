const assert = require('node:assert/strict');
const {panelCallback} = require('../scripts/spotify-web/callback.js');
const nonce='a'.repeat(32);
assert.equal(panelCallback('?state=192.168.0.128~'+nonce+'&code=a%2Bb'), 'http://192.168.0.128/spotify/callback?state=192.168.0.128%7E'+nonce+'&code=a%2Bb');
for(const ip of ['127.0.0.1','8.8.8.8','169.254.169.254','192.168.0.1.evil.com','192.168.000.1','10.0.0.256','172.32.0.1']) assert.throws(()=>panelCallback('?state='+ip+'~'+nonce+'&code=x'));
for(const tail of ['&state=10.0.0.1~'+nonce,'&code=other','&extra=1']) assert.throws(()=>panelCallback('?state=10.0.0.1~'+nonce+'&code=x'+tail));
assert.throws(()=>panelCallback('?error=access_denied'));
console.log('PASS: OAuth return address, query validation, private networks and cancellation');
