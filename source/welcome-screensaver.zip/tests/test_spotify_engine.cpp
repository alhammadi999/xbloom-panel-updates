#include "spotify_engine.h"
#include "spotify_login.h"
#include "spotify_online_login.h"
#include <cassert>
#include <deque>
#include <cstdio>
#include <vector>
using namespace spotify;
const std::string CLIENT(32, 'a');
const char *TOKEN = R"({"access_token":"access-1","expires_in":3600})";
const char *PLAYER = R"({"is_playing":true,"device":{"id":"phone-id","name":"My phone","is_restricted":false},"item":{"name":"Song","artists":[{"name":"Artist"}]},"actions":{"disallows":{"skipping_prev":true}}})";
struct Fake : Backend {
  std::deque<Response> responses;
  struct Request { bool accounts; std::string method, path, token, body; };
  std::vector<Request> calls;
  bool save_ok = true;
  std::string saved_client, saved_refresh;
  Response request(bool accounts, const char *method, const std::string &path,
                   const std::string &token, const std::string &body) override {
    calls.push_back({accounts, method, path, token, body});
    assert(!responses.empty()); auto r = responses.front(); responses.pop_front(); return r;
  }
  bool save(const std::string &client, const std::string &refresh) override {
    if (!save_ok) return false;
    saved_client = client; saved_refresh = refresh; return true;
  }
};
void connected(Engine &e, Fake &f) {
  f.responses.push_back({200, 0, TOKEN});
  assert(e.link(CLIENT, "refresh-1", 100));
  f.responses.push_back({200, 0, PLAYER}); e.poll(100, true);
  assert(e.state().linked && e.state().controls && e.state().playing);
  assert(std::string(e.state().title) == "Song" && std::string(e.state().artist) == "Artist");
}
int main() {
  {
    OnlineLogin session;
    session.start(std::string(64,'a'),std::string(64,'b'),std::string(64,'c'),std::string(43,'d'),100);
    assert(session.active(100) && session.url().empty());
    session.registered=true;
    assert(session.url().find("https://")==0 && session.url().find("192.168")==std::string::npos);
    const auto state="r2."+std::string(64,'a')+"."+std::string(64,'e');
    assert(session.matches(state,101));assert(!session.matches(state+"x",101));
    assert(!session.matches("r2."+std::string(64,'b')+"."+std::string(64,'e'),101));
    assert(!session.active(300100)); session.clear(); assert(!session.active(100));
  }
  {
    LoginSession s;
    const std::string state="192.168.0.128~"+std::string(32,'a');
    s.start("192.168.0.128", std::string(32,'a'), std::string(64,'b'), std::string(43,'c'), 100);
    assert(s.authorize("wrong",101).empty());
    assert(s.authorize(state,101).find("code_challenge_method=S256")!=std::string::npos);
    assert(s.authorize(state,300101).empty());
    assert(s.consume(state,102)==std::string(64,'b'));
    assert(s.consume(state,103).empty()); // one-use, no replay
    s.start("127.0.0.1",std::string(32,'a'),std::string(64,'b'),std::string(43,'c'),0);
    assert(s.url().empty());
  }
  {
    Fake f; Engine e(f); connected(e,f);
    auto n=f.calls.size(); e.control(Command::Volume,"phone-id",101,60); assert(f.calls.size()==n);
    const char *v=R"({"is_playing":true,"device":{"id":"phone-id","name":"Speaker","is_restricted":false,"supports_volume":true,"volume_percent":35}})";
    f.responses.push_back({200,0,v}); e.poll(4200,true); assert(e.state().can_volume && e.state().volume==35);
    n=f.calls.size();
    e.control(Command::Volume,"phone-id",4201,-1); e.control(Command::Volume,"phone-id",4201,101);
    e.control(Command::Volume,"other",4201,40); assert(f.calls.size()==n);
    f.responses.push_back({204,0,""}); e.control(Command::Volume,"phone-id",4201,40);
    assert(f.calls.back().method=="PUT" && f.calls.back().path=="/v1/me/player/volume?device_id=phone-id&volume_percent=40");
    assert(e.state().volume==40);
    f.responses.push_back({200,0,R"({"is_playing":true,"device":{"id":"phone-id","is_restricted":false,"supports_volume":true,"volume_percent":40},"actions":{"disallows":{"setting_volume":true}}})"});
    e.poll(4202,true); assert(!e.state().can_volume);
  }
  {
    Fake f; Engine e(f);
    f.responses.push_back({200,0,R"({"refresh_token":"new-refresh"})"});
    f.responses.push_back({200,0,TOKEN});
    assert(e.exchange_code("one-use-code",std::string(64,'b'),100));
    assert(f.saved_refresh=="new-refresh");
    assert(f.calls.front().accounts && f.calls.front().body.find("grant_type=authorization_code")!=std::string::npos);
    assert(f.calls.front().body.find("code_verifier="+std::string(64,'b'))!=std::string::npos);
  }
  assert(form_encode("x y&+/=") == "x%20y%26%2B%2F%3D");
  assert(valid_client(CLIENT) && !valid_client("https://open.spotify.com/user/id"));
  assert(!valid_token("bad\r\nheader"));
  {
    Fake f; Engine e(f); e.restore(CLIENT, "refresh"); e.poll(100, false); assert(f.calls.empty());
    e.restore("invalid", "refresh"); e.poll(200, true); assert(f.calls.empty());
  }
  {
    Fake f; Engine e(f); connected(e, f);
    assert(f.saved_client == CLIENT && f.saved_refresh == "refresh-1");
    const auto n = f.calls.size();
    e.control(Command::Previous, "phone-id", 101); assert(f.calls.size() == n); // Disallowed.
    e.control(Command::Pause, "other-device", 101); assert(f.calls.size() == n);
    f.responses.push_back({204, 0, ""}); e.control(Command::Pause, "phone-id", 101);
    assert(!e.state().playing && f.calls.back().method == "PUT");
    assert(f.calls.back().path == "/v1/me/player/pause?device_id=phone-id");
    const auto paused = f.calls.size(); e.control(Command::Next, "phone-id", 20000); assert(f.calls.size() == paused);
    f.save_ok = false; e.forget(); assert(e.state().linked); // Deletion failure remains retryable.
    f.save_ok = true; e.forget(); assert(!e.state().linked && f.saved_refresh.empty());
  }
  {
    Fake f; Engine e(f); connected(e, f);
    f.responses.push_back({401, 0, ""}); f.responses.push_back({200, 0, TOKEN}); f.responses.push_back({204, 0, ""});
    e.control(Command::Next, "phone-id", 200);
    assert(f.calls[f.calls.size()-2].accounts && f.calls.back().method == "POST");
    assert(f.calls.back().path == "/v1/me/player/next?device_id=phone-id");
  }
  {
    Fake f; Engine e(f); connected(e, f);
    f.responses.push_back({429, 60, ""}); e.control(Command::Next, "phone-id", 200);
    auto n = f.calls.size(); e.poll(4000, true); e.control(Command::Next, "phone-id", 4000); assert(f.calls.size() == n);
    f.responses.push_back({200, 0, PLAYER}); e.poll(60200, true); assert(e.state().controls);
  }
  {
    Fake f; Engine e(f); connected(e, f);
    f.responses.push_back({0, 0, ""}); e.control(Command::Next, "phone-id", 200);
    assert(f.responses.empty() && !e.state().controls); // An uncertain skip is never replayed.
  }
  {
    Fake f; Engine e(f); connected(e, f);
    f.responses.push_back({204, 0, ""}); e.poll(4200, true);
    assert(!e.state().controls && !e.state().title[0] && !e.state().device_id[0]);
    auto n = f.calls.size(); e.control(Command::Play, "phone-id", 4201); assert(f.calls.size() == n);
  }
  {
    Fake f; Engine e(f); f.responses.push_back({200, 0, R"({"access_token":"a","expires_in":3600,"refresh_token":"rotated"})"});
    assert(e.link(CLIENT, "old", 100)); assert(f.saved_refresh == "rotated");
    Engine rebooted(f); rebooted.restore(f.saved_client, f.saved_refresh);
    f.responses.push_back({200, 0, TOKEN}); f.responses.push_back({200, 0, PLAYER}); rebooted.poll(100, true);
    assert(f.calls[f.calls.size()-2].body.find("refresh_token=rotated") != std::string::npos);
  }
  {
    Fake f; Engine e(f); f.save_ok = false; f.responses.push_back({200, 0, TOKEN});
    assert(!e.link(CLIENT, "refresh", 100) && !e.state().linked);
  }
  {
    Fake f; Engine e(f); connected(e, f);
    f.responses.push_back({200, 0, "not JSON"}); e.poll(4200, true); assert(!e.state().controls);
    f.responses.push_back({403, 0, ""}); e.poll(8400, true); assert(!e.state().controls);
  }
  puts("PASS: Spotify playback parsing, targeted commands, capability checks, no autoplay, token refresh/rotation, rate limits, persistence and failures");
}
