import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location("spotify_link", Path(__file__).resolve().parents[1]/"scripts/spotify_link.py")
link = importlib.util.module_from_spec(spec)
spec.loader.exec_module(link)

class LinkingTests(unittest.TestCase):
    def test_pkce_rfc7636_vector(self):
        self.assertEqual(link.pkce("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk"), "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM")
    def test_callback_state_and_path(self):
        self.assertEqual(link.callback_result("/callback?code=abc&state=random", "random"), "abc")
        self.assertIsNone(link.callback_result("/other?code=abc&state=random", "random"))
        for path in ("/callback?code=abc&state=wrong", "/callback?state=random", "/callback?state=random&error=access_denied"):
            with self.assertRaises(ValueError): link.callback_result(path, "random")
    def test_local_panel_only(self):
        self.assertEqual(link.panel_url("192.168.1.50"), "http://192.168.1.50")
        for host in ("https://example.com", "127.0.0.1", "0.0.0.0", "8.8.8.8", "224.0.0.1", "::1"):
            with self.assertRaises(ValueError): link.panel_url(host)

if __name__ == "__main__": unittest.main()
