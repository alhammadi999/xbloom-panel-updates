#include "update_policy.h"
#if PANEL_PILOT_ACCESS
static_assert(update_policy::selected_pilot(true), "Owner may choose Pilot");
static_assert(!update_policy::selected_pilot(false), "Owner may choose Customers");
#else
static_assert(!update_policy::selected_pilot(true), "Saved Pilot preference must be ignored for customers");
static_assert(!update_policy::selected_pilot(false), "Customers always use stable");
#endif
