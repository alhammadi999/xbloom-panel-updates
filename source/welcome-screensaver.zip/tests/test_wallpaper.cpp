#include "wallpaper.h"
#include <LittleFS.h>
#include <esp_heap_caps.h>
#include <algorithm>
#include <cassert>
#include <cstdio>
#include <vector>
std::vector<uint8_t> encoded(uint8_t pixel) {
  std::vector<uint8_t> result(wallpaper::pixel_bytes + 8, pixel);
  const uint8_t header[] = {'X','B','G','1',32,3,224,1};
  std::copy(header,header+8,result.begin()); return result;
}
void upload(const std::vector<uint8_t> &data) {
  assert(wallpaper::start_upload());
  for (size_t i=0;i<data.size();) { const auto n=std::min(size_t(4093),data.size()-i); assert(wallpaper::write_upload(data.data()+i,n)); i+=n; }
  assert(wallpaper::finish_upload());
}
int main() {
  wallpaper::begin(); assert(!wallpaper::current());
  auto first=encoded(0x13); upload(first);
  auto snapshot=wallpaper::current(); assert(snapshot && snapshot->pixels[0]==0x13);
  const auto original=*LittleFS.files.at("/wallpaper.rgb");
  assert(wallpaper::start_upload()); assert(wallpaper::write_upload(first.data(),7)); assert(!wallpaper::finish_upload());
  assert(*LittleFS.files.at("/wallpaper.rgb")==original && wallpaper::current()==snapshot);
  auto invalid=first; invalid[4]=0;
  assert(wallpaper::start_upload()); assert(!wallpaper::write_upload(invalid.data(),10)); assert(wallpaper::current()==snapshot);
  assert(wallpaper::start_upload()); assert(!wallpaper::write_upload(first.data(),first.size()+1)); assert(wallpaper::current()==snapshot);
  assert(wallpaper::start_upload()); assert(wallpaper::write_upload(first.data(),4096)); wallpaper::abort_upload(); assert(wallpaper::current()==snapshot);
  fail_photo_alloc=true; assert(wallpaper::start_upload()); assert(!wallpaper::write_upload(first.data(),4096)); fail_photo_alloc=false;
  assert(wallpaper::current()==snapshot);
  fail_storage_write=true; assert(wallpaper::start_upload()); assert(!wallpaper::write_upload(first.data(),4096)); fail_storage_write=false;
  assert(wallpaper::current()==snapshot);
  LittleFS.fail_rename=true;
  assert(wallpaper::start_upload()); assert(wallpaper::write_upload(first.data(),first.size())); assert(!wallpaper::finish_upload());
  assert(wallpaper::current()==snapshot && *LittleFS.files.at("/wallpaper.rgb")==original);
  LittleFS.fail_rename=false;
  assert(wallpaper::start_upload());
  assert(wallpaper::write_upload(first.data(),3));
  assert(wallpaper::write_upload(first.data()+3,4));
  assert(wallpaper::write_upload(first.data()+7,first.size()-7));
  assert(wallpaper::finish_upload());
  auto second=encoded(0x77); upload(second);
  assert(wallpaper::current()->pixels[0]==0x77 && snapshot->pixels[0]==0x13); // old draw snapshot stays alive
  LittleFS.files["/wallpaper.tmp"] = std::make_shared<std::vector<uint8_t>>(100,0);
  wallpaper::begin(); assert(wallpaper::current()->pixels[0]==0x77); // restart persistence
  assert(!LittleFS.files.count("/wallpaper.tmp")); // interrupted power-loss upload is reclaimed
  LittleFS.capacity=LittleFS.usedBytes(); assert(!wallpaper::start_upload());
  puts("PASS wallpaper: chunk boundaries, persistence, immutable snapshots, invalid/truncated/oversize/aborted uploads, low memory, low storage, rename failure");
}
