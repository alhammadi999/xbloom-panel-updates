const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(require('path').join(__dirname,'../src/wallpaper_web.inc'),'utf8');
const script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const nodes={photo:{files:[]},preview:{},save:{disabled:true},status:{}};
const rgba=new Uint8ClampedArray(800*480*4);
rgba.set([255,0,0,255,0,255,0,255,0,0,255,255,255,255,255,255]);
let drawArgs,bitmap={width:1600,height:960,close(){}},calls=0,captured;
const context={fillRect(){},drawImage(...args){drawArgs=args},getImageData(){return {data:rgba}}};
nodes.preview.getContext=()=>context;
vm.runInNewContext(script,{document:{getElementById:id=>nodes[id]},createImageBitmap:async()=>bitmap,Uint8Array,Blob,FormData,Error,Math,
 fetch:async(url,options)=>{calls++;captured=options.body.get('photo');assert.equal(url,'/wallpaper');assert.equal(options.method,'POST');return {ok:true,json:async()=>({ok:true})}}});
(async()=>{
 nodes.photo.files=[{size:1024}];await nodes.photo.onchange();assert.equal(nodes.save.disabled,false);
 assert.deepEqual(drawArgs.slice(1),[0,0,1600,960,0,0,800,480]);
 await nodes.save.onclick();assert.equal(calls,1);assert(nodes.status.textContent.includes('Saved'));
 const data=new Uint8Array(await captured.arrayBuffer());assert.equal(data.length,768008);
 assert.deepEqual([...data.slice(0,8)],[88,66,71,49,32,3,224,1]);
 assert.deepEqual([...data.slice(8,16)],[0,248,224,7,31,0,255,255]);
 bitmap={width:800,height:1600,close(){}};await nodes.photo.onchange();assert.deepEqual(drawArgs.slice(1),[0,560,800,480,0,0,800,480]);
 nodes.photo.files=[{size:13*1024*1024}];await nodes.photo.onchange();assert.equal(nodes.save.disabled,true);assert(nodes.status.textContent.includes('12 MB'));
 console.log('PASS actual photo page: centre crop, exact format/size, RGB565 colours, local upload, oversized input rejection.');
})().catch(error=>{console.error(error);process.exitCode=1});
