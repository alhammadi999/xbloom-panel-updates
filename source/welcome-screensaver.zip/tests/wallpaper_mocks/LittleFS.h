#pragma once
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <memory>
#include <map>
#include <string>
#include <vector>
#include <algorithm>
inline bool fail_storage_write = false;
struct File {
  std::shared_ptr<std::vector<uint8_t>> bytes;
  size_t cursor = 0;
  explicit operator bool() const { return bool(bytes); }
  size_t size() const { return bytes ? bytes->size() : 0; }
  size_t read(uint8_t *data, size_t count) { if (!bytes) return 0; count = std::min(count, bytes->size() - cursor); memcpy(data, bytes->data() + cursor, count); cursor += count; return count; }
  size_t write(const uint8_t *data, size_t count) { if (!bytes || fail_storage_write) return 0; bytes->insert(bytes->end(), data, data+count); return count; }
  void close() { bytes.reset(); }
};
struct MockFS {
  std::map<std::string,std::shared_ptr<std::vector<uint8_t>>> files;
  bool fail_rename = false;
  size_t capacity = 0x3e0000;
  size_t totalBytes() const { return capacity; }
  size_t usedBytes() const { size_t count=0; for (const auto &item:files) count+=item.second->size(); return count; }
  File open(const char *name, const char *mode) {
    if (*mode == 'w') files[name] = std::make_shared<std::vector<uint8_t>>();
    auto it=files.find(name); if (it==files.end()) return {};
    return File{it->second,0};
  }
  void remove(const char *name) { files.erase(name); }
  bool rename(const char *from, const char *to) { auto it=files.find(from); if (fail_rename||it==files.end()) return false; files[to]=it->second; files.erase(it); return true; }
};
inline MockFS LittleFS;
