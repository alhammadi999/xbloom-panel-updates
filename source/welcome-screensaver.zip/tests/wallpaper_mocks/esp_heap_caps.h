#pragma once
#include <cstdlib>
constexpr int MALLOC_CAP_SPIRAM = 1, MALLOC_CAP_8BIT = 2;
inline bool fail_photo_alloc = false;
inline void *heap_caps_malloc(size_t bytes, int) { return fail_photo_alloc ? nullptr : malloc(bytes); }
inline void heap_caps_free(void *data) { free(data); }
