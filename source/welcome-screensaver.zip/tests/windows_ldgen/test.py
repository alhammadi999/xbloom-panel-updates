"""Exercise the Windows linker spawn with a command larger than cmd.exe allows."""
import os
from pathlib import Path
import runpy
import subprocess
import sys
import tempfile

if os.name != "nt":
    print("SKIP: Windows-only command-line regression")
    raise SystemExit(0)


class FakeEnv(dict):
    def Replace(self, **values):
        self.update(values)


fallback_calls = []


def fallback(*args):
    fallback_calls.append(args)
    return 23


env = FakeEnv(SPAWN=fallback)
root = Path(__file__).resolve().parents[2]
runpy.run_path(str(root / "scripts/windows_ldgen.py"), init_globals={"env": env, "Import": lambda _: None})
with tempfile.TemporaryDirectory(prefix="ldgen test ") as directory:
    script = Path(directory) / "ldgen.py"
    script.write_text(
        "import sys\nassert sys.argv[1] == 'value with spaces'\n"
        "assert sys.argv[2] == 'x' * 9000\nprint('PASS: long Windows command and quoted spaces')\n",
        encoding="utf-8",
    )
    args = [subprocess.list2cmdline([item]) for item in [sys.executable, str(script), "value with spaces", "x" * 9000]]
    assert len(" ".join(args)) > 8191
    assert env["SPAWN"](None, None, sys.executable, args, os.environ.copy()) == 0
assert not fallback_calls
assert env["SPAWN"](None, None, "other.exe", ["other.exe"], {}) == 23
assert len(fallback_calls) == 1
print("PASS: unrelated build commands keep the original spawn behavior")

from unittest.mock import patch
with patch("subprocess.call", return_value=0) as launch:
    args = ['"C:\\tools venv\\Scripts\\pio.exe"', "run", "-e", "crowpanel-advance-43"]
    assert env["SPAWN"](None, None, args[0], args, os.environ.copy()) == 0
    command = launch.call_args.args[0]
    assert command.startswith(subprocess.list2cmdline([sys.executable]) + " -m platformio run ")
    assert launch.call_args.kwargs["shell"] is False
print("PASS: SDK child build keeps the parent PlatformIO Core")
